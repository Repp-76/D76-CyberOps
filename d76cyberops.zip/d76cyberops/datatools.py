"""Profiles tabular data (CSV, TSV, JSON array of objects). Everything stays in memory."""
import csv
import io
import json
import re
import statistics
from collections import Counter
from datetime import datetime

MAX_BYTES = 50 * 1024 * 1024
MAX_ROWS = 200_000
EMAIL = re.compile(r"^[\w.+-]+@[\w-]+(\.[\w-]+)+$")
PII_NAME = re.compile(r"e-?mail|phone|mobile|tel\b|passport|\bic\b|nric|mykad|ssn|password|passwd|secret|token|address|dob|birth|card", re.I)
DATE_FORMATS = ("%Y-%m-%d", "%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%d/%m/%Y", "%m/%d/%Y", "%d-%m-%Y", "%Y/%m/%d")


def load_rows(raw, filename=""):
    if len(raw) > MAX_BYTES:
        raise ValueError("The file is larger than the 50 MB limit.")
    text = raw.decode("utf-8-sig", "replace")
    if not text.strip():
        raise ValueError("The file is empty.")
    stripped = text.lstrip()
    if stripped[0] in "[{" or filename.lower().endswith(".json"):
        try:
            data = json.loads(text)
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON at line {e.lineno}, column {e.colno}: {e.msg}.") from None
        if isinstance(data, dict):
            data = next((v for v in data.values() if isinstance(v, list)), [data])
        if not isinstance(data, list) or not all(isinstance(r, dict) for r in data):
            raise ValueError("JSON must be an array of objects, such as [{\"a\": 1}, {\"a\": 2}].")
        cols = []
        for r in data[:MAX_ROWS]:
            for k in r:
                if k not in cols:
                    cols.append(k)
        rows = [[_cell(r.get(c)) for c in cols] for r in data[:MAX_ROWS]]
        return cols, rows, "json", len(data) > MAX_ROWS
    sample = text[:20000]
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=",;\t|")
        delim = dialect.delimiter
    except csv.Error:
        delim = "\t" if filename.lower().endswith(".tsv") else ","
    reader = csv.reader(io.StringIO(text), delimiter=delim)
    try:
        header = next(reader)
    except StopIteration:
        raise ValueError("No rows found.") from None
    cols, seen = [], Counter()
    for i, name in enumerate(header):
        name = name.strip() or f"column_{i + 1}"
        seen[name] += 1
        cols.append(name if seen[name] == 1 else f"{name}_{seen[name]}")
    rows, truncated = [], False
    for r in reader:
        if not r:
            continue
        if len(rows) >= MAX_ROWS:
            truncated = True
            break
        r = (r + [""] * len(cols))[:len(cols)]
        rows.append([c.strip() for c in r])
    return cols, rows, {",": "csv", ";": "csv (semicolon)", "\t": "tsv", "|": "csv (pipe)"}[delim], truncated


def _cell(v):
    if v is None:
        return ""
    if isinstance(v, (dict, list)):
        return json.dumps(v, ensure_ascii=False)
    return str(v)


def _kind(values):
    vals = [v for v in values if v != ""]
    if not vals:
        return "empty"
    if all(re.fullmatch(r"[-+]?\d+", v) for v in vals):
        return "integer"
    if all(re.fullmatch(r"[-+]?(\d+\.?\d*|\.\d+)([eE][-+]?\d+)?", v) for v in vals):
        return "number"
    if all(v.lower() in ("true", "false", "yes", "no", "0", "1") for v in vals):
        return "boolean"
    for fmt in DATE_FORMATS:
        try:
            for v in vals[:200]:
                datetime.strptime(v, fmt)
            return "date"
        except ValueError:
            continue
    return "text"


def profile(raw, filename=""):
    cols, rows, fmt, truncated = load_rows(raw, filename)
    n = len(rows)
    columns, notes = [], []
    for i, name in enumerate(cols):
        values = [r[i] for r in rows]
        non_null = [v for v in values if v != ""]
        kind = _kind(values)
        counts = Counter(non_null)
        info = {"name": name, "type": kind, "filled": len(non_null), "missing": n - len(non_null), "unique": len(counts),
                "top": [[v[:60], c] for v, c in counts.most_common(5)]}
        if kind in ("integer", "number") and non_null:
            nums = [float(v) for v in non_null]
            info.update(min=min(nums), max=max(nums), mean=round(statistics.fmean(nums), 4), median=statistics.median(nums))
        elif non_null:
            lens = [len(v) for v in non_null]
            info.update(min_length=min(lens), max_length=max(lens))
        if n and info["missing"] / n > 0.5:
            notes.append(f"'{name}' is more than half empty ({info['missing']:,} of {n:,}).")
        if n > 1 and len(counts) == 1:
            notes.append(f"'{name}' has the same value in every filled row.")
        if PII_NAME.search(name) or (non_null and sum(bool(EMAIL.match(v)) for v in non_null[:200]) > len(non_null[:200]) / 2):
            notes.append(f"'{name}' looks like it may hold personal or sensitive data. Review before sharing.")
        columns.append(info)
    dupes = n - len({tuple(r) for r in rows})
    if dupes:
        notes.append(f"{dupes:,} row(s) are exact duplicates of another row.")
    ids = [c["name"] for c in columns if n > 1 and c["unique"] == n and c["missing"] == 0 and c["type"] in ("integer", "text")]
    if ids:
        notes.append("Every value is unique in: " + ", ".join(ids) + ". These look like identifiers.")
    if truncated:
        notes.append(f"Only the first {MAX_ROWS:,} rows were read.")
    return {"format": fmt, "rows": n, "columns": columns, "duplicates": dupes, "notes": notes, "preview_columns": cols, "preview": rows[:500],
            "truncated": truncated}


def convert(raw, filename, target):
    cols, rows, _, _ = load_rows(raw, filename)
    if target == "json":
        return json.dumps([dict(zip(cols, r)) for r in rows], indent=2, ensure_ascii=False), "application/json", "json"
    if target == "csv":
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(cols)
        for r in rows:
            w.writerow([c if not re.match(r"^[=+\-@\t\r]", c) else "'" + c for c in r])
        return buf.getvalue(), "text/csv", "csv"
    raise ValueError("Unknown target format.")
