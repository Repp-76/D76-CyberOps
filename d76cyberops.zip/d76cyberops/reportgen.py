"""Builds a report model from selected sources and renders it as HTML, Markdown, JSON or PDF."""
import json
import os
import re
from datetime import datetime, timezone

import checklist
import db
import netwatch
import pdfdoc
import resources

DISCLAIMER = ("This report summarizes information entered by the author and results produced by D76 CyberOps tools at the time shown. "
              "Automated checks have limits: they can miss problems and can flag things that turn out to be harmless, so findings should be confirmed before action is taken. "
              "It is not legal advice or a guarantee of security. Use these methods only on systems you own or are authorized to assess.")
LOGO = "https://files.catbox.moe/f0npdt.jpg"


def reports_dir():
    d = db.DATA_DIR / "reports"
    d.mkdir(parents=True, exist_ok=True)
    return d


def table(head, rows):
    return {"head": head, "rows": [[("" if c is None else str(c)) for c in r] for r in rows]}


def case_sections(case_id):
    d = resources.case_bundle(case_id)
    if not d:
        raise ValueError(f"Case {case_id} no longer exists.")
    c = d["case"]
    kind = "Research case" if c["kind"] == "research" else "Case"
    sec = [{"title": f"{kind}: {c['title']}", "paragraphs": [f"Status: {c['status']}. Investigator: {c['investigator'] or 'not set'}. Created {c['created']}, updated {c['updated']}.", c["description"] or "No description was recorded."], "subsections": []}]
    sub = sec[0]["subsections"]
    if d["evidence"]:
        sub.append({"title": "Evidence", "table": table(["Title", "File or reference", "Size (bytes)", "SHA-256", "Status", "Integrity"], [[e["title"], e["file_name"] or e["file_ref"], e["file_size"], e["sha256"] or "none", e["status"],
                    f"{e['last_result']} on {e['last_check']}" if e["last_result"] else "not checked"] for e in d["evidence"]])})
    if d["entities"]:
        names = {e["id"]: e["label"] for e in d["entities"]}
        sub.append({"title": "Entities", "table": table(["Type", "Label", "Value", "Source", "Evidence reference"], [[e["kind"], e["label"], e["value"], e["source_url"], e["evidence"]] for e in d["entities"]])})
        if d["relations"]:
            sub.append({"title": "Relationships", "items": [f"{names.get(r['src'], '?')} - {r['label'] or 'related to'} - {names.get(r['dst'], '?')}" for r in d["relations"]]})
    if d["notes"]:
        sub.append({"title": "Notes", "items": [f"{n['title']} ({n['created'][:10]}): {n['body']}".strip() for n in d["notes"]]})
    return sec, f"{kind} #{case_id}: {c['title']}"


def checklist_sections(cid):
    rows = db.query("SELECT * FROM checklists WHERE id = ?", (cid,))
    if not rows:
        raise ValueError(f"Checklist {cid} no longer exists.")
    r = rows[0]
    return checklist.report_sections(r["name"], r["target"], json.loads(r["answers"] or "{}")), f"Security checklist #{cid}: {r['name']}"


def saved_sections(sid):
    rows = db.query("SELECT * FROM saved_results WHERE id = ?", (sid,))
    if not rows:
        raise ValueError(f"Saved result {sid} no longer exists.")
    r = rows[0]
    d = json.loads(r["data"])
    t, kind = r["title"], r["kind"]
    ref = f"Saved {kind} result #{sid}: {t}"
    if kind == "domain":
        sec = [{"title": f"Domain inspection: {d.get('target', t)}", "paragraphs": [f"Inspected at {d.get('generated', r['created'])}."], "subsections": []}]
        sub = sec[0]["subsections"]
        dns = d.get("dns")
        if dns and dns.get("ok"):
            rows_ = [[x["type"], rec["data"], rec["ttl"]] for x in dns["results"] for rec in x["records"]]
            sub.append({"title": "DNS records", "table": table(["Type", "Value", "TTL"], rows_)} if rows_ else {"title": "DNS records", "paragraphs": ["No records were returned."]})
        elif dns:
            sub.append({"title": "DNS records", "paragraphs": [f"Not available: {dns.get('error')}"]})
        tls = d.get("tls")
        if tls and tls.get("ok"):
            c = tls.get("certificate") or {}
            sub.append({"title": "TLS", "items": [f"Protocol {tls.get('version')}, cipher {tls.get('cipher')}", f"Certificate verified: {'yes' if tls.get('verified') else 'no (' + str(tls.get('error')) + ')'}", f"Subject: {c.get('subject', 'unknown')}", f"Issuer: {c.get('issuer', 'unknown')}", f"Valid until {c.get('not_after', 'unknown')} ({c.get('days_left', '?')} days left)"]})
        elif tls:
            sub.append({"title": "TLS", "paragraphs": [f"Not available: {tls.get('error')}"]})
        http = d.get("http")
        if http and http.get("ok") and http.get("final"):
            sub.append({"title": "HTTP", "items": [f"{c['url']} answered {c['status']}" for c in http["chain"]] + [f"{s['header']}: {'present' if s['present'] else 'missing'}" for s in http["final"]["security"]]})
        rd = d.get("rdap")
        if rd and rd.get("ok"):
            sub.append({"title": "Registration", "items": [f"Registrar: {rd.get('registrar')}", f"Registered: {rd.get('registered')}", f"Expires: {rd.get('expires')}", f"Status: {', '.join(rd.get('status', []))}"]})
        return sec, ref
    if kind == "log":
        sec = [{"title": f"Log analysis: {t}", "paragraphs": [f"{d.get('lines', 0):,} lines analysed between {d.get('first') or 'unknown'} and {d.get('last') or 'unknown'}. Formats: {', '.join(f'{k} ({v})' for k, v in d.get('formats', {}).items())}.",
                "Anomalies below are patterns that deserve a look; none is proof of malicious activity."], "subsections": []}]
        if d.get("anomalies"):
            sec[0]["subsections"].append({"title": "Potential anomalies", "table": table(["Finding", "Source", "Count", "Detail"], [[a["title"], a.get("ip") or "", a["count"], a["detail"]] for a in d["anomalies"]])})
        else:
            sec[0]["subsections"].append({"title": "Potential anomalies", "paragraphs": ["None of the checks flagged anything."]})
        if d.get("top_ips"):
            sec[0]["subsections"].append({"title": "Busiest addresses", "table": table(["Address", "Lines"], [[i["ip"], i["count"]] for i in d["top_ips"]])})
        return sec, ref
    if kind == "filehash":
        return [{"title": f"File hashes: {t}", "table": table(["File", "Size (bytes)", "Algorithm", "Digest"], [[f["name"], f["size"], a, h] for f in d.get("results", []) for a, h in f["hashes"].items()])}], ref
    return [{"title": t, "paragraphs": [json.dumps(d)[:2000]]}], ref


def netwatch_sections():
    targets = db.query("SELECT * FROM watch_targets ORDER BY name")
    if not targets:
        raise ValueError("NetWatch has no targets to report on.")
    rows = []
    for t in targets:
        s = netwatch.stats(t["id"], 24)
        rows.append([t["name"], f"{t['kind']} {t['host']}" + (f":{t['port']}" if t["port"] else ""), s["checks"], f"{s['up_pct']}%" if s["up_pct"] is not None else "no data", f"{s['avg_ms']} ms" if s["avg_ms"] is not None else "", f"{s['max_ms']} ms" if s["max_ms"] is not None else ""])
    sec = [{"title": "Network monitoring (last 24 hours)", "paragraphs": ["Results come from checks D76 NetWatch ran against targets the author configured."], "subsections": [{"title": "Targets", "table": table(["Name", "Check", "Checks run", "Availability", "Average latency", "Worst latency"], rows)}]}]
    alerts = db.query("SELECT a.ts, a.kind, a.message, t.name FROM watch_alerts a JOIN watch_targets t ON t.id = a.target_id ORDER BY a.id DESC LIMIT 25")
    if alerts:
        sec[0]["subsections"].append({"title": "Recent alerts", "table": table(["Time (UTC)", "Target", "Type", "Message"], [[a["ts"], a["name"], a["kind"], a["message"]] for a in alerts])})
    return sec, "NetWatch summary"


def build(opts):
    title = str(opts.get("title", "")).strip()
    if not title:
        raise ValueError("Give the report a title.")
    sections, refs = [], []
    for src in opts.get("sources", []):
        kind = src.get("type")
        try:
            if kind == "case":
                s, r = case_sections(int(src["id"]))
            elif kind == "checklist":
                s, r = checklist_sections(int(src["id"]))
            elif kind == "saved":
                s, r = saved_sections(int(src["id"]))
            elif kind == "netwatch":
                s, r = netwatch_sections()
            else:
                raise ValueError("Unknown source type.")
        except (KeyError, TypeError):
            raise ValueError("A selected source is malformed.") from None
        sections += s
        refs.append(r)
    text = lambda k: str(opts.get(k, "")).strip()
    return {"title": title, "generated": datetime.now(timezone.utc).isoformat(timespec="seconds"), "author": text("author"), "scope": text("scope") or "Not stated.",
            "methodology": text("methodology") or "Not stated.", "findings": sections, "evidence_refs": refs, "notes": text("notes"), "conclusion": text("conclusion") or "Not stated.", "disclaimer": DISCLAIMER}


def walk(sections, level=2):
    for s in sections:
        yield s, level
        yield from walk(s.get("subsections", []), level + 1)


def to_markdown(m):
    out = [f"# {m['title']}", "", f"Generated: {m['generated']} UTC" + (f"  \nAuthor: {m['author']}" if m["author"] else ""), "", "## Scope", "", m["scope"], "", "## Methodology", "", m["methodology"], "", "## Findings", ""]
    if not m["findings"]:
        out += ["No sources were included.", ""]
    for s, lv in walk(m["findings"], 3):
        out += ["#" * min(lv, 6) + " " + s["title"], ""]
        out += [p + "\n" for p in s.get("paragraphs", [])]
        if s.get("items"):
            out += [f"- {i}" for i in s["items"]] + [""]
        if s.get("table"):
            t = s["table"]
            cell = lambda c: str(c).replace("|", "\\|").replace("\n", " ")
            out += ["| " + " | ".join(cell(h) for h in t["head"]) + " |", "|" + "---|" * len(t["head"])] + ["| " + " | ".join(cell(c) for c in r) + " |" for r in t["rows"]] + [""]
    out += ["## Evidence references", ""] + ([f"- {r}" for r in m["evidence_refs"]] or ["- None"]) + [""]
    if m["notes"]:
        out += ["## Notes", "", m["notes"], ""]
    out += ["## Conclusion", "", m["conclusion"], "", "## Disclaimer", "", m["disclaimer"], ""]
    return "\n".join(out)


def to_pdf(m):
    pdf = pdfdoc.Pdf(m["title"], "D76 CyberOps report")
    pdf.text(pdfdoc.MARGIN, pdfdoc.PAGE_H - pdfdoc.MARGIN + 8, "D76 CyberOps", "F2", 9, 0.35)
    pdf.heading(m["title"], 0)
    pdf.para(f"Generated {m['generated'].replace('T', ' ')} UTC" + (f"   Author: {m['author']}" if m["author"] else ""), 9, gray=0.35)
    for title, body in (("Scope", m["scope"]), ("Methodology", m["methodology"])):
        pdf.heading(title, 1)
        pdf.para(body)
    pdf.heading("Findings", 1)
    if not m["findings"]:
        pdf.para("No sources were included.")
    for s, lv in walk(m["findings"], 2):
        pdf.heading(s["title"], min(lv, 3))
        for p in s.get("paragraphs", []):
            pdf.para(p)
        if s.get("items"):
            pdf.bullets(s["items"])
        if s.get("table"):
            pdf.table(s["table"]["head"], s["table"]["rows"])
    pdf.heading("Evidence references", 1)
    pdf.bullets(m["evidence_refs"] or ["None"])
    if m["notes"]:
        pdf.heading("Notes", 1)
        pdf.para(m["notes"])
    pdf.heading("Conclusion", 1)
    pdf.para(m["conclusion"])
    pdf.heading("Disclaimer", 1)
    pdf.para(m["disclaimer"], 9, gray=0.3)
    return pdf.build()
