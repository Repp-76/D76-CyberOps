"""API routes for the phase 3 tools. Each route is a thin wrapper over a pure module."""
import os
import re
import time
import urllib.parse

from flask import Blueprint, Response, jsonify, request

import certs
import datatools
import db
import forensics
import netutil
import sysutil
import webtools

bp = Blueprint("tools3", __name__)
TOKEN = re.compile(r"^[!#$%&'*+.^_`|~0-9A-Za-z-]+$")
BLOCKED_HEADERS = {"host", "content-length", "connection", "transfer-encoding", "upgrade", "te"}
BODY_LIMIT = 1024 * 1024


def err(message, code=400):
    return jsonify(error=message), code


def respond(tool, event, fn, *args):
    try:
        result = fn(*args)
    except ValueError as e:
        return err(str(e))
    db.log(tool, event)
    return jsonify(result)


def text_body(limit=2_000_000):
    data = request.get_json(silent=True) or {}
    value = data.get("text", "")
    if not isinstance(value, str) or len(value) > limit:
        raise ValueError(f"Send text of at most {limit // 1000} KB.")
    return data, value


def upload(limit=forensics.MAX_FILE):
    f = request.files.get("file")
    if not f:
        raise ValueError("Choose a file first.")
    data = f.stream.read(limit + 1)
    if len(data) > limit:
        raise ValueError(f"The file is larger than the {limit // (1024 * 1024)} MB limit for this tool.")
    return f.filename or "", data


# ------------------------------------------------------------------ web security

@bp.post("/api/web/analyze")
def web_analyze():
    try:
        data, text = text_body()
    except ValueError as e:
        return err(str(e))
    kind = data.get("kind")
    if kind == "headers":
        return respond("HeaderLab", "Headers analyzed", webtools.analyze_headers, text)
    if kind == "csp":
        return respond("HeaderLab", "CSP analyzed", lambda t: webtools.analyze_csp(t.strip()) if t.strip() else (_ for _ in ()).throw(ValueError("Paste a Content-Security-Policy value.")), text)
    if kind == "cookies":
        def cookies(t):
            lines = [l for l in t.splitlines() if l.strip()]
            if not lines:
                raise ValueError("Paste one or more Set-Cookie lines.")
            return {"cookies": [webtools.analyze_cookie(l) for l in lines[:50]]}
        return respond("HeaderLab", "Cookies analyzed", cookies, text)
    return err("Unknown analysis type.")


@bp.post("/api/web/jwt")
def web_jwt():
    data = request.get_json(silent=True) or {}
    return respond("JWT Inspector", "Token inspected", webtools.inspect_jwt, str(data.get("token", "")), str(data.get("secret", "")) or None)


@bp.post("/api/web/openapi")
def web_openapi():
    try:
        _, text = text_body(5_000_000)
    except ValueError as e:
        return err(str(e))
    return respond("OpenAPI Auditor", "Document reviewed", webtools.audit_openapi, text)


@bp.post("/api/apiwb/send")
def apiwb_send():
    b = request.get_json(silent=True) or {}
    if not b.get("authorized"):
        return err("Confirm that you own this API or have permission to test it.")
    method = str(b.get("method", "GET")).upper()
    if method not in ("GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"):
        return err("Unsupported HTTP method.")
    url = str(b.get("url", "")).strip()
    if not url:
        return err("Enter a URL.")
    headers = {}
    pairs = b.get("headers") or []
    if not isinstance(pairs, list) or len(pairs) > 50:
        return err("Send at most 50 headers.")
    for pair in pairs:
        if not (isinstance(pair, list) and len(pair) == 2):
            return err("Headers must be name and value pairs.")
        name, value = str(pair[0]).strip(), str(pair[1]).strip()
        if not name:
            continue
        if not TOKEN.match(name) or "\r" in value or "\n" in value:
            return err(f"The header '{name[:40]}' is not valid.")
        if name.lower() in BLOCKED_HEADERS:
            return err(f"{name} is set automatically and cannot be overridden.")
        headers[name] = value
    body = str(b.get("body", ""))
    payload = body.encode("utf-8") if body else None
    if payload and len(payload) > BODY_LIMIT:
        return err("The request body is larger than 1 MB.")
    if payload and method in ("GET", "HEAD"):
        return err("GET and HEAD requests cannot carry a body here.")
    try:
        timeout = max(1, min(30, int(b.get("timeout", 10))))
    except (TypeError, ValueError):
        timeout = 10
    follow, verify, private = bool(b.get("follow")), b.get("verify", True) is not False, bool(b.get("allow_private"))
    chain, current, started = [], url, time.perf_counter()
    try:
        for hop in range(6):
            r = netutil.request(current, method, headers, payload, private, timeout, verify, BODY_LIMIT)
            chain.append({"url": current, "status": r["status"], "ip": r["ip"]})
            loc = netutil.header(r["headers"], "location")
            if follow and r["status"] in netutil.REDIRECTS and loc and hop < 5:
                current = urllib.parse.urljoin(current, loc)
                if r["status"] == 303 or (r["status"] in (301, 302) and method == "POST"):
                    method, payload = "GET", None
                continue
            break
    except netutil.NetError as e:
        return err(str(e))
    data = r["body"]
    truncated = len(data) > BODY_LIMIT
    data = data[:BODY_LIMIT]
    try:
        text, binary = data.decode("utf-8"), False
    except UnicodeDecodeError:
        text, binary = None, True
    db.log("API Workbench", "Request sent")
    return jsonify(status=r["status"], reason=r["reason"], http_version=r["http_version"], headers=r["headers"], body=text, binary=binary,
                   truncated=truncated, size=len(data), ms=round((time.perf_counter() - started) * 1000), ip=r["ip"], tls=r["tls"],
                   final_url=current, chain=chain)


# --------------------------------------------------------------------- forensics

@bp.post("/api/forensics/file")
def forensics_file():
    try:
        name, data = upload()
        result = forensics.inspect_file(data, name)
    except ValueError as e:
        return err(str(e))
    db.log("File Inspector", "File inspected")
    return jsonify(result)


@bp.post("/api/forensics/metadata")
def forensics_metadata():
    try:
        name, data = upload()
        result = forensics.read_metadata(data, name)
    except ValueError as e:
        return err(str(e))
    db.log("Metadata Inspector", "File inspected")
    return jsonify(result)


@bp.post("/api/forensics/metadata/clean")
def forensics_clean():
    try:
        name, data = upload()
        cleaned, ext = forensics.strip_metadata(data)
    except ValueError as e:
        return err(str(e))
    base = re.sub(r"[^\w.-]+", "_", name.rsplit(".", 1)[0])[:60] or "file"
    db.log("Metadata Inspector", "Copy cleaned")
    return Response(cleaned, mimetype="application/octet-stream", headers={"Content-Disposition": f'attachment; filename="{base}-clean.{ext}"'})


@bp.post("/api/forensics/mail")
def forensics_mail():
    try:
        _, text = text_body()
    except ValueError as e:
        return err(str(e))
    return respond("Mail Header Analyzer", "Headers analyzed", forensics.analyze_mail_headers, text)


@bp.post("/api/forensics/ioc")
def forensics_ioc():
    try:
        data, text = text_body(5_000_000)
    except ValueError as e:
        return err(str(e))
    return respond("IOC Extractor", "Text scanned", forensics.extract_iocs, text, data.get("refang", True) is not False, bool(data.get("include_private")))


@bp.post("/api/forensics/timestamp")
def forensics_timestamp():
    data = request.get_json(silent=True) or {}
    return respond("Timestamp Decoder", "Value decoded", forensics.decode_timestamp, str(data.get("value", "")))


# ------------------------------------------------------------ crypto, net, system

@bp.post("/api/crypto/pem")
def crypto_pem():
    try:
        _, text = text_body(200_000)
    except ValueError as e:
        return err(str(e))
    return respond("Certificate Inspector", "PEM decoded", certs.inspect_pem, text)


@bp.post("/api/net/subnet")
def net_subnet():
    return respond("Subnet Calculator", "Calculation run", sysutil.subnet_action, request.get_json(silent=True) or {})


@bp.get("/api/system/info")
def system_info():
    return jsonify(sysutil.host_info())


@bp.post("/api/admin/cron")
def admin_cron():
    data = request.get_json(silent=True) or {}
    try:
        count = max(1, min(20, int(data.get("count", 8))))
    except (TypeError, ValueError):
        count = 8
    return respond("Admin Toolbox", "Cron explained", sysutil.explain_cron, str(data.get("expr", "")), None, count)


@bp.post("/api/admin/permissions")
def admin_permissions():
    return respond("Admin Toolbox", "Permissions calculated", sysutil.permissions, request.get_json(silent=True) or {})


# -------------------------------------------------------------------------- data

@bp.post("/api/data/profile")
def data_profile():
    try:
        name, raw = upload(datatools.MAX_BYTES)
        result = datatools.profile(raw, name)
    except ValueError as e:
        return err(str(e))
    db.log("DataLens", "Data profiled")
    return jsonify(result)


@bp.post("/api/data/convert")
def data_convert():
    try:
        name, raw = upload(datatools.MAX_BYTES)
        body, mime, ext = datatools.convert(raw, name, request.form.get("target", ""))
    except ValueError as e:
        return err(str(e))
    base = re.sub(r"[^\w.-]+", "_", name.rsplit(".", 1)[0])[:60] or "data"
    db.log("DataLens", "Data converted")
    return Response(body, mimetype=mime, headers={"Content-Disposition": f'attachment; filename="{base}.{ext}"'})
