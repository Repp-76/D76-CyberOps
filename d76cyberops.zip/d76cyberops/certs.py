"""Decodes PEM certificates, CSRs and public keys with a small DER reader. No private key material is ever read or shown."""
import base64
import hashlib
import re
from datetime import datetime, timezone

OIDS = {
    "2.5.4.3": "CN", "2.5.4.6": "C", "2.5.4.7": "L", "2.5.4.8": "ST", "2.5.4.10": "O", "2.5.4.11": "OU", "2.5.4.5": "serialNumber",
    "1.2.840.113549.1.9.1": "emailAddress", "2.5.4.9": "street", "2.5.4.97": "organizationIdentifier",
    "1.2.840.113549.1.1.1": "RSA", "1.2.840.113549.1.1.5": "sha1WithRSAEncryption", "1.2.840.113549.1.1.4": "md5WithRSAEncryption",
    "1.2.840.113549.1.1.11": "sha256WithRSAEncryption", "1.2.840.113549.1.1.12": "sha384WithRSAEncryption", "1.2.840.113549.1.1.13": "sha512WithRSAEncryption",
    "1.2.840.113549.1.1.10": "RSASSA-PSS", "1.2.840.10045.2.1": "EC", "1.2.840.10045.4.1": "ecdsa-with-SHA1", "1.2.840.10045.4.3.2": "ecdsa-with-SHA256",
    "1.2.840.10045.4.3.3": "ecdsa-with-SHA384", "1.2.840.10045.4.3.4": "ecdsa-with-SHA512", "1.3.101.112": "Ed25519", "1.3.101.113": "Ed448",
    "1.2.840.10045.3.1.7": "P-256", "1.3.132.0.34": "P-384", "1.3.132.0.35": "P-521",
    "2.5.29.17": "subjectAltName", "2.5.29.19": "basicConstraints", "2.5.29.15": "keyUsage", "2.5.29.37": "extendedKeyUsage",
    "2.5.29.14": "subjectKeyIdentifier", "2.5.29.35": "authorityKeyIdentifier", "2.5.29.31": "cRLDistributionPoints",
    "1.3.6.1.5.5.7.1.1": "authorityInfoAccess", "2.5.29.32": "certificatePolicies", "1.3.6.1.4.1.11129.2.4.2": "signedCertificateTimestamps",
    "1.3.6.1.5.5.7.3.1": "serverAuth", "1.3.6.1.5.5.7.3.2": "clientAuth", "1.3.6.1.5.5.7.3.3": "codeSigning", "1.3.6.1.5.5.7.3.4": "emailProtection",
    "1.3.6.1.5.5.7.3.8": "timeStamping", "2.5.29.30": "nameConstraints", "1.2.840.113549.1.9.14": "extensionRequest",
}
KEY_USAGE = ["digitalSignature", "contentCommitment", "keyEncipherment", "dataEncipherment", "keyAgreement", "keyCertSign", "cRLSign", "encipherOnly", "decipherOnly"]


class DerError(ValueError):
    pass


def tlv(data, off=0):
    if off + 2 > len(data):
        raise DerError("The data ends unexpectedly.")
    tag, ln = data[off], data[off + 1]
    pos = off + 2
    if ln & 0x80:
        n = ln & 0x7F
        if n == 0 or n > 4 or pos + n > len(data):
            raise DerError("Unsupported or truncated length encoding.")
        ln = int.from_bytes(data[pos:pos + n], "big")
        pos += n
    if pos + ln > len(data):
        raise DerError("A field is longer than the data.")
    return tag, data[pos:pos + ln], pos + ln


def children(value):
    out, off = [], 0
    while off < len(value):
        tag, val, off = tlv(value, off)
        out.append((tag, val))
    return out


def oid(value):
    first = value[0]
    parts = [first // 40, first % 40]
    n = 0
    for b in value[1:]:
        n = (n << 7) | (b & 0x7F)
        if not b & 0x80:
            parts.append(n)
            n = 0
    return ".".join(map(str, parts))


def text(tag, val):
    if tag == 0x1E:
        return val.decode("utf-16-be", "replace")
    return val.decode("utf-8", "replace") if tag == 0x0C else val.decode("latin-1")


def parse_time(tag, val):
    s = val.decode("ascii")
    if tag == 0x17:
        year = int(s[:2])
        s = ("20" if year < 50 else "19") + s
    return datetime.strptime(s[:14], "%Y%m%d%H%M%S").replace(tzinfo=timezone.utc)


def parse_name(value):
    parts = []
    for _, rdn in children(value):
        for _, atv in children(rdn):
            (_, o), (t, v) = children(atv)[:2]
            parts.append((OIDS.get(oid(o), oid(o)), text(t, v)))
    return parts


def name_str(parts):
    return ", ".join(f"{k}={v}" for k, v in parts)


def algo_name(seq):
    ch = children(seq)
    return OIDS.get(oid(ch[0][1]), oid(ch[0][1])), (ch[1] if len(ch) > 1 else None)


def parse_spki(value):
    alg_seq, bits = children(value)[:2]
    name, params = algo_name(alg_seq[1])
    info = {"algorithm": name}
    key = bits[1][1:]
    if name == "RSA":
        mod = children(children(key)[0][1])[0][1]
        n = int.from_bytes(mod, "big")
        info["bits"] = n.bit_length()
        info["exponent"] = int.from_bytes(children(children(key)[0][1])[1][1], "big")
    elif name == "EC" and params and params[0] == 0x06:
        info["curve"] = OIDS.get(oid(params[1]), oid(params[1]))
        info["bits"] = {"P-256": 256, "P-384": 384, "P-521": 521}.get(info["curve"])
    elif name in ("Ed25519", "Ed448"):
        info["bits"] = 256 if name == "Ed25519" else 456
    return info


def fingerprint(der):
    out = {}
    for n, fn in (("sha256", hashlib.sha256), ("sha1", hashlib.sha1)):
        h = fn(der).hexdigest().upper()
        out[n] = ":".join(h[i:i + 2] for i in range(0, len(h), 2))
    return out


def general_names(value):
    names = []
    for tag, v in children(value):
        t = tag & 0x1F
        if t == 2:
            names.append(("DNS", v.decode("ascii", "replace")))
        elif t == 1:
            names.append(("Email", v.decode("ascii", "replace")))
        elif t == 6:
            names.append(("URI", v.decode("ascii", "replace")))
        elif t == 7:
            import ipaddress
            names.append(("IP", str(ipaddress.ip_address(v))))
    return names


def parse_extensions(value):
    out = []
    for _, ext in children(children(value)[0][1]):
        ch = children(ext)
        o = oid(ch[0][1])
        critical = len(ch) == 3 and ch[1][1] == b"\xff"
        raw = ch[-1][1]
        name = OIDS.get(o, o)
        inner = tlv(raw)[1] if raw else b""  # the extension value is itself a DER structure
        item = {"name": name, "critical": critical}
        try:
            if o == "2.5.29.17":
                item["value"] = [f"{k}: {v}" for k, v in general_names(inner)]
            elif o == "2.5.29.19":
                seq = children(inner)
                ca = bool(seq and seq[0][0] == 0x01 and seq[0][1] != b"\x00")
                item["value"] = [f"CA: {'yes' if ca else 'no'}"] + ([f"Path length: {int.from_bytes(seq[-1][1], 'big')}"] if len(seq) > 1 else [])
                item["ca"] = ca
            elif o == "2.5.29.15":
                tag, bits, _ = tlv(raw)
                unused, data = bits[0], int.from_bytes(bits[1:], "big")
                total = (len(bits) - 1) * 8 - unused
                item["value"] = [KEY_USAGE[i] for i in range(min(total, 9)) if data >> ((len(bits) - 1) * 8 - 1 - i) & 1]
            elif o == "2.5.29.37":
                item["value"] = [OIDS.get(oid(v), oid(v)) for _, v in children(inner)]
            elif o == "1.3.6.1.5.5.7.1.1":
                item["value"] = [f"{OIDS.get(oid(children(d)[0][1]), oid(children(d)[0][1]))}: {children(d)[1][1].decode('ascii', 'replace')}" for _, d in children(inner)]
        except (DerError, IndexError, ValueError):
            item["value"] = ["(could not decode)"]
        out.append(item)
    return out


def finding(severity, message):
    return {"severity": severity, "message": message}


def parse_certificate(der, now=None):
    now = now or datetime.now(timezone.utc)
    _, cert, _ = tlv(der)
    tbs_raw, sig_alg, _sig = [v for _, v in children(cert)[:3]]
    fields = children(tbs_raw)
    i = 1 if fields[0][0] == 0xA0 else 0
    version = (fields[0][1][2] + 1) if i else 1
    serial = int.from_bytes(fields[i][1], "big")
    sig_name, _ = algo_name(fields[i + 1][1])
    issuer = parse_name(fields[i + 2][1])
    nb, na = [parse_time(t, v) for t, v in children(fields[i + 3][1])]
    subject = parse_name(fields[i + 4][1])
    key = parse_spki(fields[i + 5][1])
    exts = []
    for tag, v in fields[i + 6:]:
        if tag == 0xA3:
            exts = parse_extensions(v)
    f = []
    days = (na - now).days
    if now > na:
        f.append(finding("bad", f"Expired on {na.date()}."))
    elif now < nb:
        f.append(finding("warn", f"Not valid until {nb.date()}."))
    elif days < 30:
        f.append(finding("warn", f"Expires in {days} day(s) on {na.date()}."))
    else:
        f.append(finding("good", f"Valid until {na.date()} ({days} days left)."))
    life = (na - nb).days
    sans = next((e["value"] for e in exts if e["name"] == "subjectAltName"), [])
    ca = next((e.get("ca") for e in exts if e["name"] == "basicConstraints"), False)
    if not ca and life > 398:
        f.append(finding("info", f"Validity period is {life} days. Publicly trusted TLS certificates are limited to 398 days."))
    if "sha1" in sig_name.lower() or "md5" in sig_name.lower():
        f.append(finding("bad", f"Signed with {sig_name}, which is no longer considered secure."))
    if key["algorithm"] == "RSA" and key["bits"] < 2048:
        f.append(finding("bad", f"RSA key is only {key['bits']} bits. Use at least 2048."))
    if not sans and not ca:
        f.append(finding("warn", "No subjectAltName. Modern browsers ignore the common name and require SAN entries."))
    if subject == issuer:
        f.append(finding("info", "Subject and issuer are identical: this is self-signed or a root certificate."))
    if ca:
        f.append(finding("info", "This certificate can issue other certificates (CA:TRUE)."))
    if any(v.startswith("DNS: *.") for v in sans):
        f.append(finding("info", "Includes a wildcard name."))
    return {"kind": "Certificate", "version": version, "serial": f"{serial:X}", "subject": name_str(subject), "issuer": name_str(issuer),
            "subject_parts": subject, "not_before": nb.isoformat(timespec="seconds"), "not_after": na.isoformat(timespec="seconds"),
            "days_left": days, "signature_algorithm": sig_name, "public_key": key, "extensions": exts, "san": sans,
            "fingerprints": fingerprint(der), "findings": f}


def parse_csr(der):
    _, csr, _ = tlv(der)
    info_raw, sig_alg, _ = [v for _, v in children(csr)[:3]]
    fields = children(info_raw)
    subject = parse_name(fields[1][1])
    key = parse_spki(fields[2][1])
    sig_name, _ = algo_name(sig_alg)
    f = []
    if key["algorithm"] == "RSA" and key["bits"] < 2048:
        f.append(finding("bad", f"RSA key is only {key['bits']} bits."))
    if "sha1" in sig_name.lower():
        f.append(finding("bad", "Signed with SHA-1."))
    if not f:
        f.append(finding("good", "No problems found in the request."))
    return {"kind": "Certificate request", "subject": name_str(subject), "subject_parts": subject, "public_key": key,
            "signature_algorithm": sig_name, "fingerprints": fingerprint(der), "findings": f}


def parse_public_key(der):
    _, spki, _ = tlv(der)
    key = parse_spki(spki)
    f = [finding("bad", f"RSA key is only {key['bits']} bits.")] if key["algorithm"] == "RSA" and key["bits"] < 2048 else [finding("good", "Key size is acceptable.")]
    return {"kind": "Public key", "public_key": key, "fingerprints": fingerprint(der), "findings": f}


PEM = re.compile(r"-----BEGIN ([A-Z0-9 ]+)-----(.*?)-----END \1-----", re.S)


def inspect_pem(text):
    blocks = PEM.findall(text)
    if not blocks:
        raise ValueError("No PEM block found. Paste text that starts with -----BEGIN CERTIFICATE-----.")
    if len(blocks) > 10:
        raise ValueError("Too many PEM blocks (limit 10).")
    results = []
    for label, body in blocks:
        if "PRIVATE KEY" in label:
            results.append({"kind": "Private key", "private": True, "findings": [finding("bad", "A private key was pasted. It was not decoded or stored. A private key should never leave the system that owns it; if this one has been shared, treat it as compromised and replace it.")]})
            continue
        try:
            der = base64.b64decode(re.sub(r"\s+", "", body), validate=True)
            if label in ("CERTIFICATE", "TRUSTED CERTIFICATE"):
                results.append(parse_certificate(der))
            elif label in ("CERTIFICATE REQUEST", "NEW CERTIFICATE REQUEST"):
                results.append(parse_csr(der))
            elif label == "PUBLIC KEY":
                results.append(parse_public_key(der))
            else:
                results.append({"kind": label.title(), "findings": [finding("info", f"A {label} block was found but this type is not decoded.")]})
        except (DerError, ValueError, IndexError):
            results.append({"kind": label.title(), "findings": [finding("bad", "This block could not be decoded. It may be damaged or truncated.")]})
    return {"blocks": results}
