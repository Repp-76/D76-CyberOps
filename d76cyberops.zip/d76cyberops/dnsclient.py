"""A small DNS client over UDP with TCP fallback. Reads the system resolvers, or D76_DNS_SERVERS if set."""
import ipaddress
import os
import random
import socket
import struct

TYPES = {"A": 1, "NS": 2, "CNAME": 5, "SOA": 6, "MX": 15, "TXT": 16, "AAAA": 28, "CAA": 257}
NAMES = {v: k for k, v in TYPES.items()}


class DnsError(Exception):
    pass


def system_resolvers():
    env = os.environ.get("D76_DNS_SERVERS", "")
    if env.strip():
        return [s.strip() for s in env.split(",") if s.strip()]
    servers = []
    try:
        with open("/etc/resolv.conf") as fh:
            for line in fh:
                parts = line.split()
                if len(parts) >= 2 and parts[0] == "nameserver":
                    servers.append(parts[1].split("%")[0])
    except OSError:
        pass
    return servers


def encode_name(name):
    name = name.rstrip(".")
    try:
        name = name.encode("idna").decode("ascii")
    except UnicodeError:
        raise DnsError("That name cannot be encoded for DNS.") from None
    out = b""
    for label in name.split(".") if name else []:
        if not 0 < len(label) <= 63:
            raise DnsError("A DNS label must be 1 to 63 characters.")
        out += bytes([len(label)]) + label.encode("ascii")
    if len(out) > 253:
        raise DnsError("The name is longer than 253 characters.")
    return out + b"\0"


def read_name(buf, off):
    labels, end, hops = [], None, 0
    while True:
        if off >= len(buf):
            raise DnsError("The response is malformed.")
        n = buf[off]
        if n == 0:
            off += 1
            break
        if n & 0xC0 == 0xC0:
            if off + 1 >= len(buf):
                raise DnsError("The response is malformed.")
            ptr = ((n & 0x3F) << 8) | buf[off + 1]
            if end is None:
                end = off + 2
            hops += 1
            if hops > 20 or ptr >= len(buf):
                raise DnsError("The response is malformed.")
            off = ptr
            continue
        if n & 0xC0 or off + 1 + n > len(buf):
            raise DnsError("The response is malformed.")
        labels.append(buf[off + 1:off + 1 + n].decode("ascii", "replace"))
        off += 1 + n
    return ".".join(labels) or ".", (end if end is not None else off)


def build_query(name, rtype):
    qid = random.randint(0, 0xFFFF)
    return qid, struct.pack(">HHHHHH", qid, 0x0100, 1, 0, 0, 0) + encode_name(name) + struct.pack(">HH", TYPES[rtype], 1)


def parse_rdata(rtype, buf, off, ln):
    end = off + ln
    if end > len(buf):
        raise DnsError("The response is malformed.")
    if rtype == 1 and ln == 4:
        return str(ipaddress.IPv4Address(buf[off:end]))
    if rtype == 28 and ln == 16:
        return str(ipaddress.IPv6Address(buf[off:end]))
    if rtype in (2, 5):
        return read_name(buf, off)[0]
    if rtype == 15:
        return f"{struct.unpack_from('>H', buf, off)[0]} {read_name(buf, off + 2)[0]}"
    if rtype == 16:
        parts, p = [], off
        while p < end:
            n = buf[p]
            parts.append(buf[p + 1:p + 1 + n].decode("utf-8", "replace"))
            p += 1 + n
        return "".join(parts)
    if rtype == 6:
        mname, p = read_name(buf, off)
        rname, p = read_name(buf, p)
        serial, refresh, retry, expire, minimum = struct.unpack_from(">IIIII", buf, p)
        return f"{mname} {rname} serial {serial} refresh {refresh} retry {retry} expire {expire} minimum {minimum}"
    if rtype == 257:
        flags, tl = buf[off], buf[off + 1]
        return f"{flags} {buf[off + 2:off + 2 + tl].decode('ascii', 'replace')} \"{buf[off + 2 + tl:end].decode('utf-8', 'replace')}\""
    return f"(type {rtype}, {ln} bytes)"


def parse_response(data, qid):
    if len(data) < 12:
        raise DnsError("The response is too short.")
    rid, flags, qd, an, _, _ = struct.unpack_from(">HHHHHH", data, 0)
    if rid != qid:
        raise DnsError("The response does not match the query.")
    off = 12
    for _ in range(qd):
        _, off = read_name(data, off)
        off += 4
    answers = []
    for _ in range(an):
        name, off = read_name(data, off)
        rtype, _, ttl, ln = struct.unpack_from(">HHIH", data, off)
        off += 10
        answers.append({"name": name, "type": NAMES.get(rtype, str(rtype)), "ttl": ttl, "data": parse_rdata(rtype, data, off, ln)})
        off += ln
    return {"rcode": flags & 0xF, "truncated": bool(flags & 0x200), "answers": answers}


def _tcp(server, port, payload, timeout):
    with socket.create_connection((server, port), timeout) as s:
        s.sendall(struct.pack(">H", len(payload)) + payload)
        head = s.recv(2)
        if len(head) < 2:
            raise DnsError("The server closed the connection.")
        need, buf = struct.unpack(">H", head)[0], b""
        while len(buf) < need:
            chunk = s.recv(need - len(buf))
            if not chunk:
                raise DnsError("The response was cut short.")
            buf += chunk
        return buf


def query(name, rtype, servers=None, timeout=4, port=53):
    if rtype not in TYPES:
        raise DnsError("Unsupported record type.")
    servers = servers or system_resolvers()
    if not servers:
        raise DnsError("No DNS resolver is configured on this system. Set D76_DNS_SERVERS, for example 192.168.1.1.")
    qid, payload = build_query(name, rtype)
    last = "No DNS server answered."
    for server in servers:
        try:
            family = socket.AF_INET6 if ":" in server else socket.AF_INET
            with socket.socket(family, socket.SOCK_DGRAM) as s:
                s.settimeout(timeout)
                s.sendto(payload, (server, port))
                while True:
                    data, addr = s.recvfrom(4096)
                    if addr[0] == server and len(data) >= 2 and struct.unpack(">H", data[:2])[0] == qid:
                        break
            res = parse_response(data, qid)
            if res["truncated"]:
                res = parse_response(_tcp(server, port, payload, timeout), qid)
            res["resolver"] = server
            return res
        except socket.timeout:
            last = f"The resolver {server} did not answer within {timeout} seconds."
        except DnsError as e:
            last = str(e)
        except OSError as e:
            last = f"Could not reach resolver {server}: {e.strerror or e}"
    raise DnsError(last)
