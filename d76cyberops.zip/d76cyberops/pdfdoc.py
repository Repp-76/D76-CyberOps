"""A small PDF writer for text reports: headings, paragraphs, bullets and tables on A4 pages, using the
standard Helvetica and Courier fonts. Text is encoded as Windows-1252; anything outside it becomes '?'."""
import re
import zlib

PAGE_W, PAGE_H, MARGIN = 595.0, 842.0, 54.0
# Helvetica advance widths per 1000 em for ASCII 32..126
HW = [278, 278, 355, 556, 556, 889, 667, 191, 333, 333, 389, 584, 278, 333, 278, 278] + [556] * 10 + [278, 278, 584, 584, 584, 556, 1015,
      667, 667, 722, 722, 667, 611, 778, 722, 278, 500, 667, 556, 833, 722, 778, 667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611, 278, 278, 278, 469, 556, 333,
      556, 556, 500, 556, 556, 278, 556, 556, 222, 222, 500, 222, 833, 556, 556, 556, 556, 333, 500, 278, 556, 500, 722, 500, 500, 500, 334, 260, 334, 584]


def width(text, size, bold=False):
    total = 0
    for ch in text:
        o = ord(ch)
        total += HW[o - 32] if 32 <= o <= 126 else 556
    return total * size / 1000 * (1.07 if bold else 1.0)


def esc(text):
    b = text.encode("cp1252", "replace").decode("cp1252")
    return b.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")


def wrap(text, size, max_w, bold=False):
    lines = []
    for para in str(text).replace("\r", "").split("\n"):
        words, cur = para.split(" "), ""
        for w in words:
            while width(w, size, bold) > max_w:  # a single very long token
                cut = len(w)
                while cut > 1 and width(w[:cut], size, bold) > max_w:
                    cut -= 1
                if cur:
                    lines.append(cur)
                    cur = ""
                lines.append(w[:cut])
                w = w[cut:]
            trial = (cur + " " + w).strip() if cur else w
            if width(trial, size, bold) <= max_w:
                cur = trial
            else:
                lines.append(cur)
                cur = w
        lines.append(cur)
    return lines or [""]


class Pdf:
    FONTS = {"F1": "Helvetica", "F2": "Helvetica-Bold", "F3": "Courier", "F4": "Courier-Bold"}

    def __init__(self, title, footer):
        self.title, self.footer = title, footer
        self.pages, self.cur, self.y = [], [], PAGE_H - MARGIN
        self.new_page()

    def new_page(self):
        if self.cur:
            self.pages.append(self.cur)
        self.cur, self.y = [], PAGE_H - MARGIN

    def need(self, h):
        if self.y - h < MARGIN + 20:
            self.new_page()

    def text(self, x, y, s, font="F1", size=10, gray=0.0):
        self.cur.append(f"BT /{font} {size} Tf {gray} g {x:.1f} {y:.1f} Td ({esc(s)}) Tj ET")

    def rule(self, x1, x2, y, gray=0.8, w=0.5):
        self.cur.append(f"{gray} G {w} w {x1:.1f} {y:.1f} m {x2:.1f} {y:.1f} l S")

    def spacer(self, n=6):
        self.y -= n

    def heading(self, s, level=1):
        size = {0: 20, 1: 14, 2: 11.5, 3: 10.5}[level]
        lines = wrap(s, size, PAGE_W - 2 * MARGIN, True)
        self.need(size * 1.4 * len(lines) + 14)
        self.y -= 8 if level else 0
        for ln in lines:
            self.y -= size * 1.25
            self.text(MARGIN, self.y, ln, "F2", size)
        if level == 1:
            self.y -= 3
            self.rule(MARGIN, PAGE_W - MARGIN, self.y)
        self.y -= 4

    def para(self, s, size=10, indent=0, gray=0.0, font="F1"):
        for ln in wrap(s, size, PAGE_W - 2 * MARGIN - indent, font == "F2"):
            self.need(size * 1.4)
            self.y -= size * 1.35
            self.text(MARGIN + indent, self.y, ln, font, size, gray)
        self.y -= 3

    def bullets(self, items, size=10):
        for it in items:
            lines = wrap(it, size, PAGE_W - 2 * MARGIN - 14)
            for i, ln in enumerate(lines):
                self.need(size * 1.4)
                self.y -= size * 1.35
                if i == 0:
                    self.text(MARGIN + 2, self.y, "-", "F1", size)
                self.text(MARGIN + 14, self.y, ln, "F1", size)
        self.y -= 3

    def table(self, head, rows, size=8):
        cw = 0.6 * size  # Courier character width
        usable = PAGE_W - 2 * MARGIN
        ncols = len(head)
        pad = 2
        maxc = int(usable // cw) - len(head) * pad
        words = lambda i: [len(w) for w in str(head[i]).split()] + [len(w) for r in rows if i < len(r) for w in str(r[i]).split()]
        floor = [min(max(words(i) or [1]), 24) for i in range(ncols)]  # never split a column's longest word
        want = [max(floor[i], min(max([len(str(head[i]))] + [len(str(r[i])) for r in rows if i < len(r)]), 60)) for i in range(ncols)]
        if sum(want) > maxc:
            spare = max(0, maxc - sum(floor))
            extra = [w - f for w, f in zip(want, floor)]
            scale = spare / sum(extra) if sum(extra) else 0
            want = [f + int(e * scale) for f, e in zip(floor, extra)]
            if sum(want) > maxc:  # very many columns: shrink evenly as a last resort
                want = [max(4, int(w * maxc / sum(want))) for w in want]
        xs, x = [], MARGIN
        for w in want:
            xs.append(x)
            x += (w + pad) * cw

        def row(cells, font, gray):
            cols = [wrap_mono(str(c), want[i]) for i, c in enumerate(cells[:ncols])]
            lines = max(len(c) for c in cols)
            self.need(lines * size * 1.3 + 4)
            for ln in range(lines):
                self.y -= size * 1.3
                for i, c in enumerate(cols):
                    if ln < len(c):
                        self.text(xs[i], self.y, c[ln], font, size, gray)
            self.y -= 2

        row(head, "F4", 0.0)
        self.rule(MARGIN, PAGE_W - MARGIN, self.y, 0.4, 0.8)
        self.y -= 2
        for r in rows:
            row(list(r) + [""] * (ncols - len(r)), "F3", 0.1)
            self.rule(MARGIN, PAGE_W - MARGIN, self.y, 0.9, 0.3)
        self.y -= 6

    def build(self):
        if self.cur:
            self.pages.append(self.cur)
            self.cur = []
        n = len(self.pages)
        objs = [b"", b"", b""]  # placeholders for catalog, pages, info
        font_ids = {}
        for key, base in self.FONTS.items():
            objs.append(f"<< /Type /Font /Subtype /Type1 /BaseFont /{base} /Encoding /WinAnsiEncoding >>".encode())
            font_ids[key] = len(objs)
        page_ids = []
        for i, ops in enumerate(self.pages, 1):
            ops = ops + [f"BT /F1 8 Tf 0.45 g {MARGIN:.1f} 30 Td ({esc(self.footer)}) Tj ET", f"BT /F1 8 Tf 0.45 g {PAGE_W - MARGIN - 50:.1f} 30 Td ({esc(f'Page {i} of {n}')}) Tj ET"]
            stream = zlib.compress("\n".join(ops).encode("cp1252", "replace"))
            objs.append(b"<< /Length %d /Filter /FlateDecode >>\nstream\n" % len(stream) + stream + b"\nendstream")
            cid = len(objs)
            res = " ".join(f"/{k} {v} 0 R" for k, v in font_ids.items())
            objs.append(f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {PAGE_W:.0f} {PAGE_H:.0f}] /Resources << /Font << {res} >> >> /Contents {cid} 0 R >>".encode())
            page_ids.append(len(objs))
        objs[0] = b"<< /Type /Catalog /Pages 2 0 R >>"
        objs[1] = f"<< /Type /Pages /Kids [{' '.join(f'{p} 0 R' for p in page_ids)}] /Count {n} >>".encode()
        objs[2] = f"<< /Title ({esc(self.title)}) /Creator (D76 CyberOps) /Producer (D76 CyberOps) >>".encode()
        out, offsets = bytearray(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n"), []
        for i, body in enumerate(objs, 1):
            offsets.append(len(out))
            out += f"{i} 0 obj\n".encode() + body + b"\nendobj\n"
        xref = len(out)
        out += f"xref\n0 {len(objs) + 1}\n0000000000 65535 f \n".encode()
        for off in offsets:
            out += f"{off:010d} 00000 n \n".encode()
        out += f"trailer\n<< /Size {len(objs) + 1} /Root 1 0 R /Info 3 0 R >>\nstartxref\n{xref}\n%%EOF\n".encode()
        return bytes(out)


def wrap_mono(text, cols):
    text = text.replace("\r", "")
    out = []
    for para in text.split("\n"):
        while len(para) > cols:
            cut = para.rfind(" ", 0, cols + 1)
            cut = cut if cut > 0 else cols  # break at the last space; split a word only when it has no space
            out.append(para[:cut].rstrip())
            para = para[cut:].lstrip()
        out.append(para)
    return out or [""]
