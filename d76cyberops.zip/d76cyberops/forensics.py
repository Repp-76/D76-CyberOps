"""Static, read-only forensic helpers. Files are parsed as bytes and never executed or written to disk."""
import email
import email.policy
import io
import ipaddress
import math
import re
import struct
import zipfile
from datetime import datetime, timedelta, timezone
from email.utils import parseaddr, parsedate_to_datetime
from xml.etree import ElementTree

MAX_FILE = 64 * 1024 * 1024
UTC = timezone.utc

# ----------------------------------------------------------------- file inspector

SIGNATURES = [
    (b"\x89PNG\r\n\x1a\n", 0, "PNG image", "png"), (b"\xff\xd8\xff", 0, "JPEG image", "jpg"), (b"GIF8", 0, "GIF image", "gif"),
    (b"%PDF-", 0, "PDF document", "pdf"), (b"PK\x03\x04", 0, "ZIP container (also docx, xlsx, jar, apk)", "zip"),
    (b"\x1f\x8b", 0, "GZIP archive", "gz"), (b"BZh", 0, "BZip2 archive", "bz2"), (b"\xfd7zXZ\x00", 0, "XZ archive", "xz"),
    (b"7z\xbc\xaf\x27\x1c", 0, "7-Zip archive", "7z"), (b"Rar!\x1a\x07", 0, "RAR archive", "rar"),
    (b"\x7fELF", 0, "ELF executable or library", "elf"), (b"MZ", 0, "Windows PE executable or DLL", "exe"),
    (b"\xcf\xfa\xed\xfe", 0, "Mach-O executable (64-bit)", "macho"), (b"\xce\xfa\xed\xfe", 0, "Mach-O executable (32-bit)", "macho"),
    (b"\xca\xfe\xba\xbe", 0, "Java class or Mach-O universal binary", "class"), (b"SQLite format 3\x00", 0, "SQLite database", "sqlite"),
    (b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1", 0, "OLE2 compound file (legacy Office)", "doc"), (b"{\\rtf", 0, "RTF document", "rtf"),
    (b"ID3", 0, "MP3 audio", "mp3"), (b"OggS", 0, "Ogg media", "ogg"), (b"fLaC", 0, "FLAC audio", "flac"),
    (b"II*\x00", 0, "TIFF image", "tif"), (b"MM\x00*", 0, "TIFF image", "tif"), (b"BM", 0, "BMP image", "bmp"),
    (b"\x00\x00\x01\x00", 0, "Windows icon", "ico"), (b"%!PS", 0, "PostScript", "ps"), (b"#!", 0, "Script with interpreter line", "sh"),
    (b"<?xml", 0, "XML document", "xml"), (b"<!DOCTYPE html", 0, "HTML document", "html"), (b"<html", 0, "HTML document", "html"),
    (b"\x00asm", 0, "WebAssembly module", "wasm"), (b"dex\n", 0, "Android Dalvik executable", "dex"),
]
EXT_GROUPS = {"jpg": {"jpg", "jpeg"}, "tif": {"tif", "tiff"}, "zip": {"zip", "docx", "xlsx", "pptx", "jar", "apk", "odt", "ods", "epub"},
              "exe": {"exe", "dll", "sys", "scr", "ocx"}, "doc": {"doc", "xls", "ppt", "msi"}, "html": {"html", "htm"},
              "sh": {"sh", "bash", "py", "pl", "rb"}, "class": {"class"}, "gz": {"gz", "tgz"}, "xml": {"xml", "svg", "xhtml"}}


def identify(data, filename=""):
    kind = ext = None
    head = data[:64]
    for sig, off, name, e in SIGNATURES:
        if head[off:off + len(sig)] == sig:
            kind, ext = name, e
            break
    if head[:4] == b"RIFF" and len(data) >= 12:
        sub = data[8:12]
        kind, ext = {b"WAVE": ("WAV audio", "wav"), b"AVI ": ("AVI video", "avi"), b"WEBP": ("WebP image", "webp")}.get(sub, ("RIFF container", "riff"))
    if len(data) >= 12 and data[4:8] == b"ftyp":
        kind, ext = "MP4/MOV media", "mp4"
    if kind is None:
        sample = data[:4096]
        if sample and all(c in b"\t\n\r" or 32 <= c < 127 or c >= 128 for c in sample) and sample.count(0) == 0:
            kind, ext = "Text (no binary signature)", "txt"
        else:
            kind, ext = "Unknown binary data", None
    note = None
    suffix = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    if ext and suffix:
        allowed = EXT_GROUPS.get(ext, {ext})
        if suffix not in allowed and ext != "txt":
            note = f"The name ends in .{suffix} but the content looks like {kind}."
    return {"type": kind, "extension_note": note}


def entropy_of(counts, total):
    if not total:
        return 0.0
    return -sum((c / total) * math.log2(c / total) for c in counts if c)


def extract_strings(data, minimum=6, limit=400):
    ascii_found = [m.group().decode("ascii") for m in re.finditer(rb"[\x20-\x7e]{%d,}" % minimum, data)]
    wide = [m.group().decode("utf-16-le", "ignore") for m in re.finditer(rb"(?:[\x20-\x7e]\x00){%d,}" % minimum, data)]
    return ascii_found[:limit], wide[:limit], len(ascii_found), len(wide)


def hexdump(data, base=0):
    rows = []
    for i in range(0, len(data), 16):
        chunk = data[i:i + 16]
        rows.append({"offset": f"{base + i:08x}", "hex": " ".join(f"{b:02x}" for b in chunk),
                     "ascii": "".join(chr(b) if 32 <= b < 127 else "." for b in chunk)})
    return rows


def parse_pe(data):
    if len(data) < 64 or data[:2] != b"MZ":
        return None
    off = struct.unpack_from("<I", data, 0x3C)[0]
    if off + 24 > len(data) or data[off:off + 4] != b"PE\0\0":
        return {"error": "MZ header present but no valid PE signature."}
    machine, nsec, stamp, _, _, optsize, chars = struct.unpack_from("<HHIIIHH", data, off + 4)
    machines = {0x14c: "x86", 0x8664: "x64", 0x1c0: "ARM", 0xaa64: "ARM64", 0x200: "IA-64"}
    out = {"machine": machines.get(machine, hex(machine)), "sections_declared": nsec, "dll": bool(chars & 0x2000),
           "executable": bool(chars & 0x2), "timestamp": datetime.fromtimestamp(stamp, UTC).isoformat(timespec="seconds") if stamp else None,
           "timestamp_note": "The compile timestamp is set by the linker and is easily forged or zeroed."}
    opt = off + 24
    if opt + 2 <= len(data):
        magic = struct.unpack_from("<H", data, opt)[0]
        out["format"] = {0x10b: "PE32", 0x20b: "PE32+"}.get(magic, hex(magic))
        if opt + 20 <= len(data):
            out["entry_point_rva"] = hex(struct.unpack_from("<I", data, opt + 16)[0])
        sub_off = opt + 68
        if sub_off + 2 <= len(data):
            out["subsystem"] = {1: "native", 2: "GUI", 3: "console", 9: "Windows CE"}.get(struct.unpack_from("<H", data, sub_off)[0], "other")
    secs, sec_off = [], opt + optsize
    for i in range(min(nsec, 96)):
        p = sec_off + i * 40
        if p + 40 > len(data):
            break
        name = data[p:p + 8].rstrip(b"\0").decode("ascii", "replace")
        vsize, vaddr, rsize, rptr = struct.unpack_from("<IIII", data, p + 8)
        flags = struct.unpack_from("<I", data, p + 36)[0]
        raw = data[rptr:rptr + rsize] if rsize else b""
        counts = [0] * 256
        for b in raw:
            counts[b] += 1
        ent = entropy_of(counts, len(raw))
        secs.append({"name": name, "virtual_size": vsize, "raw_size": rsize, "entropy": round(ent, 2),
                     "flags": "".join(c for c, bit in (("R", 0x40000000), ("W", 0x80000000), ("X", 0x20000000)) if flags & bit),
                     "note": "High entropy (packed or encrypted data is common here)" if ent >= 7.2 and raw else ""})
    out["sections"] = secs
    return out


def parse_elf(data):
    if len(data) < 20 or data[:4] != b"\x7fELF":
        return None
    cls, endian = data[4], data[5]
    e = "<" if endian == 1 else ">"
    etype, machine = struct.unpack_from(e + "HH", data, 16)
    machines = {3: "x86", 62: "x86-64", 40: "ARM", 183: "AArch64", 8: "MIPS", 243: "RISC-V"}
    types = {1: "relocatable", 2: "executable", 3: "shared object or PIE", 4: "core dump"}
    entry = struct.unpack_from(e + ("I" if cls == 1 else "Q"), data, 24)[0] if len(data) >= 32 else None
    return {"class": "64-bit" if cls == 2 else "32-bit", "endianness": "little" if endian == 1 else "big",
            "type": types.get(etype, str(etype)), "machine": machines.get(machine, str(machine)), "entry_point": hex(entry) if entry is not None else None}


def inspect_file(data, filename=""):
    if len(data) > MAX_FILE:
        raise ValueError(f"The file is larger than the {MAX_FILE // (1024 * 1024)} MB limit for this tool.")
    counts = [0] * 256
    for b in data:
        counts[b] += 1
    total_ent = entropy_of(counts, len(data))
    block = max(256, math.ceil(len(data) / 96)) if data else 256
    blocks = []
    for i in range(0, len(data), block):
        chunk = data[i:i + block]
        c = [0] * 256
        for b in chunk:
            c[b] += 1
        blocks.append(round(entropy_of(c, len(chunk)), 2))
    if total_ent >= 7.5:
        reading = "Very high: typical of compressed or encrypted content."
    elif total_ent >= 6.5:
        reading = "High: compressed data or dense binary content."
    elif total_ent >= 4.0:
        reading = "Medium: typical of code, documents or mixed content."
    else:
        reading = "Low: repetitive or plain text data."
    a, w, a_total, w_total = extract_strings(data)
    joined = "\n".join(a + w)
    interesting = {
        "urls": sorted(set(re.findall(r"https?://[^\s\"'<>]{4,}", joined)))[:50],
        "emails": sorted(set(re.findall(r"[\w.+-]+@[\w-]+\.[\w.-]+", joined)))[:50],
        "ipv4": sorted({m for m in re.findall(r"\b(?:\d{1,3}\.){3}\d{1,3}\b", joined) if _valid_ip(m)})[:50],
    }
    ident = identify(data, filename)
    return {"filename": filename, "size": len(data), **ident, "entropy": round(total_ent, 3), "entropy_reading": reading,
            "block_size": block, "entropy_blocks": blocks, "pe": parse_pe(data), "elf": parse_elf(data),
            "strings": {"ascii": a, "utf16": w, "ascii_total": a_total, "utf16_total": w_total, "interesting": interesting},
            "hex_head": hexdump(data[:512]), "hex_tail": hexdump(data[-160:], max(0, len(data) - 160)) if len(data) > 512 else [],
            "note": "Static inspection only. The file was parsed as bytes and never executed or saved."}


def _valid_ip(s):
    try:
        ipaddress.ip_address(s)
        return True
    except ValueError:
        return False


# ----------------------------------------------------------------------- metadata

EXIF_TAGS = {0x010F: "Make", 0x0110: "Model", 0x0131: "Software", 0x0132: "DateTime", 0x013B: "Artist", 0x8298: "Copyright", 0x010E: "ImageDescription"}
EXIF_SUB = {0x9003: "DateTimeOriginal", 0x9004: "DateTimeDigitized", 0xA430: "CameraOwnerName", 0xA431: "BodySerialNumber", 0xA434: "LensModel",
            0xA435: "LensSerialNumber", 0x927C: None, 0x9286: "UserComment"}
TYPE_SIZE = {1: 1, 2: 1, 3: 2, 4: 4, 5: 8, 7: 1, 9: 4, 10: 8}


def parse_tiff(buf, base=0):
    """Reads EXIF-style IFDs. Returns {'ifd0': {...}, 'exif': {...}, 'gps': {...}}."""
    if len(buf) < base + 8:
        return {}
    order = buf[base:base + 2]
    e = "<" if order == b"II" else ">" if order == b"MM" else None
    if not e:
        return {}

    def u(fmt, off):
        return struct.unpack_from(e + fmt, buf, off)

    def read_ifd(off):
        out = {}
        try:
            n = u("H", base + off)[0]
            for i in range(min(n, 200)):
                p = base + off + 2 + i * 12
                tag, typ, count = u("HHI", p)
                size = TYPE_SIZE.get(typ, 1) * count
                data_off = p + 8 if size <= 4 else base + u("I", p + 8)[0]
                if data_off + size > len(buf):
                    continue
                if typ == 2:
                    val = buf[data_off:data_off + count].split(b"\0")[0].decode("utf-8", "replace").strip()
                elif typ == 3:
                    val = [u("H", data_off + 2 * k)[0] for k in range(min(count, 8))]
                elif typ == 4:
                    val = [u("I", data_off + 4 * k)[0] for k in range(min(count, 8))]
                elif typ in (5, 10):
                    fmt = "II" if typ == 5 else "ii"
                    val = [u(fmt, data_off + 8 * k) for k in range(min(count, 8))]
                elif typ == 7:
                    val = buf[data_off:data_off + min(count, 64)]
                else:
                    continue
                out[tag] = val
        except struct.error:
            pass
        return out

    first = u("I", base + 4)[0]
    result = {"ifd0": read_ifd(first)}
    if 0x8769 in result["ifd0"]:
        result["exif"] = read_ifd(result["ifd0"][0x8769][0])
    if 0x8825 in result["ifd0"]:
        result["gps"] = read_ifd(result["ifd0"][0x8825][0])
    return result


def _gps(gps):
    def deg(v):
        if not v or len(v) < 3 or any(d == 0 for _, d in v[:3]):
            return None
        return v[0][0] / v[0][1] + v[1][0] / v[1][1] / 60 + v[2][0] / v[2][1] / 3600
    lat, lon = deg(gps.get(2)), deg(gps.get(4))
    if lat is None or lon is None:
        return None
    if gps.get(1) in ("S", b"S"):
        lat = -lat
    if gps.get(3) in ("W", b"W"):
        lon = -lon
    return round(lat, 6), round(lon, 6)


def exif_items(tiff):
    items, flags = [], []
    for tag, val in tiff.get("ifd0", {}).items():
        if tag in EXIF_TAGS and isinstance(val, str) and val:
            items.append(("Camera and software" if tag in (0x010F, 0x0110, 0x0131) else "Authorship and dates", EXIF_TAGS[tag], val))
    for tag, val in tiff.get("exif", {}).items():
        name = EXIF_SUB.get(tag)
        if name and isinstance(val, str) and val:
            items.append(("Authorship and dates" if "Date" in name else "Device identifiers" if "Serial" in name or "Owner" in name else "Camera and software", name, val))
    pos = _gps(tiff["gps"]) if "gps" in tiff else None
    if pos:
        items.append(("Location", "GPS position", f"{pos[0]}, {pos[1]}"))
        flags.append("Contains a GPS location. Anyone with this file can see where the photo was taken.")
    if any(i[1] in ("BodySerialNumber", "LensSerialNumber", "CameraOwnerName") for i in items):
        flags.append("Contains a camera serial number or owner name that can identify the device or person.")
    if any(i[1] == "Artist" for i in items):
        flags.append("Contains an artist or author name.")
    return items, flags


def jpeg_segments(data):
    i, segs = 2, []
    while i + 4 <= len(data) and data[i] == 0xFF:
        marker = data[i + 1]
        if marker == 0xDA:
            break
        if marker == 0xFF:
            i += 1
            continue
        length = struct.unpack_from(">H", data, i + 2)[0]
        segs.append((marker, i, i + 2 + length))
        i += 2 + length
    return segs


def read_jpeg(data):
    items, flags = [], []
    for marker, start, end in jpeg_segments(data):
        body = data[start + 4:end]
        if marker == 0xE1 and body.startswith(b"Exif\0\0"):
            it, fl = exif_items(parse_tiff(body[6:], 0))
            items += it
            flags += fl
        elif marker == 0xE1 and b"ns.adobe.com/xap" in body[:40]:
            xmp = body.decode("utf-8", "ignore")
            for key in ("CreatorTool", "creator", "Creator", "Author"):
                m = re.search(rf"{key}[^>]*>\s*(?:<[^>]+>\s*)*([^<]{{2,100}})", xmp)
                if m:
                    items.append(("Authorship and dates", f"XMP {key}", m.group(1).strip()))
            flags.append("Contains an XMP metadata packet.")
        elif marker == 0xED and body.startswith(b"Photoshop"):
            flags.append("Contains Photoshop (IPTC) metadata, which can hold captions, credits and keywords.")
        elif marker == 0xFE:
            items.append(("Other", "Comment", body.decode("utf-8", "replace")[:200]))
    return items, flags


def png_chunks(data):
    i = 8
    while i + 12 <= len(data):
        length = struct.unpack_from(">I", data, i)[0]
        yield data[i + 4:i + 8].decode("latin-1"), i, i + 12 + length
        i += 12 + length


def read_png(data):
    import zlib
    items, flags = [], []
    for kind, start, end in png_chunks(data):
        body = data[start + 8:end - 4]
        if kind == "tEXt" and b"\0" in body:
            k, v = body.split(b"\0", 1)
            items.append(("Embedded text", k.decode("latin-1"), v.decode("latin-1")[:300]))
        elif kind == "iTXt" and b"\0" in body:
            k = body.split(b"\0", 1)[0].decode("utf-8", "replace")
            items.append(("Embedded text", k, "(international text chunk)"))
        elif kind == "zTXt" and b"\0" in body:
            k, rest = body.split(b"\0", 1)
            try:
                items.append(("Embedded text", k.decode("latin-1"), zlib.decompress(rest[1:], 15, 4096).decode("utf-8", "replace")[:300]))
            except Exception:
                items.append(("Embedded text", k.decode("latin-1"), "(compressed, unreadable)"))
        elif kind == "eXIf":
            it, fl = exif_items(parse_tiff(body, 0))
            items += it
            flags += fl
        elif kind == "tIME" and len(body) == 7:
            y, mo, d, h, mi, s = struct.unpack(">HBBBBB", body)
            items.append(("Authorship and dates", "Last modified", f"{y:04d}-{mo:02d}-{d:02d} {h:02d}:{mi:02d}:{s:02d}"))
    return items, flags


def read_pdf(data):
    items, flags = [], []
    text = data.decode("latin-1")
    for key in ("Title", "Author", "Subject", "Creator", "Producer", "CreationDate", "ModDate"):
        m = re.search(rf"/{key}\s*\(((?:\\.|[^\\)])*)\)", text)
        if m:
            items.append(("Document properties", key, m.group(1).replace("\\(", "(").replace("\\)", ")")[:200]))
    if re.search(rb"/Encrypt\b", data):
        flags.append("The PDF is encrypted; some properties may be hidden.")
    if b"ns.adobe.com/xap" in data:
        flags.append("Contains an XMP metadata packet.")
    if any(i[1] == "Author" for i in items):
        flags.append("Contains an author name.")
    return items, flags


def _xml_text(zf, name, limit=1_000_000):
    try:
        info = zf.getinfo(name)
    except KeyError:
        return None
    if info.file_size > limit:
        return None
    raw = zf.read(name)
    if b"<!ENTITY" in raw or b"<!DOCTYPE" in raw[:200].upper():
        return None
    try:
        return ElementTree.fromstring(raw)
    except ElementTree.ParseError:
        return None


def read_office(data):
    items, flags = [], []
    try:
        zf = zipfile.ZipFile(io.BytesIO(data))
    except zipfile.BadZipFile:
        return items, flags
    tag = lambda el: el.tag.rsplit("}", 1)[-1]
    labels = {"creator": "Creator", "lastModifiedBy": "Last modified by", "created": "Created", "modified": "Modified", "title": "Title",
              "revision": "Revision", "subject": "Subject", "keywords": "Keywords", "description": "Description",
              "Application": "Application", "Company": "Company", "AppVersion": "Application version", "TotalTime": "Editing time (min)", "Manager": "Manager",
              "initial-creator": "Initial creator", "date": "Modified", "generator": "Generator"}
    for part in ("docProps/core.xml", "docProps/app.xml", "meta.xml"):
        root = _xml_text(zf, part)
        if root is None:
            continue
        for el in root.iter():
            t = tag(el)
            if t in labels and el.text and el.text.strip():
                group = "Authorship and dates" if t in ("creator", "lastModifiedBy", "created", "modified", "initial-creator", "date", "Manager") else "Application"
                items.append((group, labels[t], el.text.strip()[:200]))
    if any(i[1] in ("Creator", "Last modified by", "Initial creator", "Manager", "Company") for i in items):
        flags.append("Contains the names of people or organizations who created or edited the document.")
    names = zf.namelist()
    if any("comments" in n.lower() for n in names):
        flags.append("Contains comments, which may include reviewer names and discussion.")
    return items, flags


def read_metadata(data, filename=""):
    if len(data) > MAX_FILE:
        raise ValueError("The file is larger than the 64 MB limit for this tool.")
    if data[:3] == b"\xff\xd8\xff":
        kind, (items, flags) = "JPEG", read_jpeg(data)
    elif data[:8] == b"\x89PNG\r\n\x1a\n":
        kind, (items, flags) = "PNG", read_png(data)
    elif data[:5] == b"%PDF-":
        kind, (items, flags) = "PDF", read_pdf(data)
    elif data[:4] == b"PK\x03\x04":
        kind, (items, flags) = "Office or OpenDocument", read_office(data)
    else:
        raise ValueError("This format is not supported. Supported: JPEG, PNG, PDF, docx/xlsx/pptx and OpenDocument files.")
    return {"filename": filename, "type": kind, "strippable": kind in ("JPEG", "PNG"),
            "items": [{"group": g, "key": k, "value": v} for g, k, v in items], "flags": flags,
            "note": "No metadata found." if not items and not flags else None}


def strip_metadata(data):
    """Returns (cleaned_bytes, extension) for a JPEG or PNG. The original is never modified."""
    if data[:3] == b"\xff\xd8\xff":
        out, last = bytearray(data[:2]), 2
        for marker, start, end in jpeg_segments(data):
            out += data[last:start]
            last = end
            if marker in (0xE1, 0xED, 0xFE):
                continue
            out += data[start:end]
        out += data[last:]
        return bytes(out), "jpg"
    if data[:8] == b"\x89PNG\r\n\x1a\n":
        out = bytearray(data[:8])
        for kind, start, end in png_chunks(data):
            if kind not in ("tEXt", "iTXt", "zTXt", "eXIf", "tIME"):
                out += data[start:end]
        return bytes(out), "png"
    raise ValueError("Only JPEG and PNG files can be cleaned.")


# ------------------------------------------------------------------ mail headers

def _domain(addr):
    return addr.rsplit("@", 1)[-1].lower().strip(" >") if "@" in addr else ""


def analyze_mail_headers(raw):
    raw = raw.strip()
    if not raw:
        raise ValueError("Paste the full message headers.")
    msg = email.message_from_string(raw.replace("\r\n", "\n"), policy=email.policy.compat32)
    if not msg.keys():
        raise ValueError("No headers found. Paste the raw headers (Show original or View source in your mail client).")
    get = lambda n: " ".join(str(msg.get(n, "")).split())
    f = []
    from_name, from_addr = parseaddr(get("From"))
    rp = parseaddr(get("Return-Path"))[1]
    reply = parseaddr(get("Reply-To"))[1]
    fd, rpd, rd = _domain(from_addr), _domain(rp), _domain(reply)
    auth = " ".join(" ".join(str(v).split()) for v in msg.get_all("Authentication-Results", []))
    results = {}
    for mech in ("spf", "dkim", "dmarc"):
        m = re.search(rf"\b{mech}=(\w+)", auth, re.I) or (re.search(r"^(\w+)", get("Received-SPF"), re.I) if mech == "spf" else None)
        results[mech] = m.group(1).lower() if m else None
    for mech, res in results.items():
        if res is None:
            f.append(finding("info", f"No {mech.upper()} result found in the headers."))
        elif res == "pass":
            f.append(finding("good", f"{mech.upper()} passed."))
        elif res in ("fail", "softfail", "permerror", "temperror", "none", "neutral"):
            f.append(finding("bad" if res in ("fail", "permerror") else "warn", f"{mech.upper()} result: {res}."))
    if fd and rpd and fd != rpd and not (fd.endswith("." + rpd) or rpd.endswith("." + fd)):
        f.append(finding("warn", f"The From domain ({fd}) differs from the Return-Path domain ({rpd}). Legitimate bulk senders do this too, so check the other signals."))
    if fd and rd and fd != rd:
        f.append(finding("warn", f"Replies would go to {rd}, not the From domain {fd}."))
    if from_name and "@" in from_name and _domain(from_name) != fd:
        f.append(finding("bad", "The display name contains an email address from a different domain than the real sender."))
    if not msg.get("Message-ID"):
        f.append(finding("warn", "There is no Message-ID header."))
    hops = []
    for raw_hop in reversed(msg.get_all("Received", [])):
        text = " ".join(str(raw_hop).split())
        body, _, stamp = text.rpartition(";")
        when = None
        try:
            when = parsedate_to_datetime(stamp.strip()).astimezone(UTC)
        except (TypeError, ValueError):
            pass
        ips = [i for i in re.findall(r"\[?((?:\d{1,3}\.){3}\d{1,3})\]?", body) if _valid_ip(i)]
        hops.append({"from": (re.search(r"\bfrom\s+(\S+)", body, re.I) or [None, ""])[1], "by": (re.search(r"\bby\s+(\S+)", body, re.I) or [None, ""])[1],
                     "with": (re.search(r"\bwith\s+(\S+)", body, re.I) or [None, ""])[1], "ips": ips, "time": when.isoformat(timespec="seconds") if when else None, "_t": when})
    prev = None
    for h in hops:
        h["delay_seconds"] = int((h["_t"] - prev).total_seconds()) if h["_t"] and prev else None
        prev = h["_t"] or prev
        h.pop("_t")
    public = [ip for h in hops for ip in h["ips"] if not ipaddress.ip_address(ip).is_private]
    origin = public[0] if public else None
    try:
        sent = parsedate_to_datetime(get("Date")).astimezone(UTC)
        first = next((h["time"] for h in hops if h["time"]), None)
        if first and abs((datetime.fromisoformat(first) - sent).total_seconds()) > 86400:
            f.append(finding("warn", "The Date header differs from the first Received time by more than a day."))
    except (TypeError, ValueError):
        if get("Date"):
            f.append(finding("info", "The Date header could not be parsed."))
    if any(h["delay_seconds"] and h["delay_seconds"] > 3600 for h in hops):
        f.append(finding("info", "At least one hop took over an hour. That can be normal queueing or a sign of a relay delay."))
    dkim = [{"domain": (re.search(r"\bd=([^;\s]+)", str(s)) or [None, ""])[1], "selector": (re.search(r"\bs=([^;\s]+)", str(s)) or [None, ""])[1]} for s in msg.get_all("DKIM-Signature", [])]
    return {"summary": {"from": get("From"), "to": get("To"), "subject": get("Subject"), "date": get("Date"), "message_id": get("Message-ID"),
                        "return_path": get("Return-Path"), "reply_to": get("Reply-To"), "mailer": get("X-Mailer") or get("User-Agent")},
            "authentication": results, "dkim_signatures": dkim, "hops": hops, "first_public_ip": origin, "findings": f,
            "note": "Only the headers added by servers you trust can be relied on. Anything below the first trusted hop can be forged. D76 does not look up any address or domain."}


def finding(severity, message):
    return {"severity": severity, "message": message}


# ----------------------------------------------------------------------- IOCs

REFANG = [(r"hxxp", "http"), (r"\[\.\]|\(\.\)|\{\.\}|\[dot\]|\(dot\)", "."), (r"\[:\]", ":"), (r"\[@\]|\(at\)|\[at\]", "@"), (r"\[://\]", "://")]
FILE_EXT = {"exe", "dll", "txt", "png", "jpg", "jpeg", "gif", "js", "py", "php", "html", "htm", "css", "zip", "pdf", "doc", "docx", "xls", "xlsx", "csv",
            "json", "xml", "log", "sh", "bat", "ps1", "md", "ini", "cfg", "tmp", "bin", "so", "jar", "class", "svg", "ico", "mp3", "mp4", "gz", "tar", "bak", "sys", "lnk"}
URL_RE = re.compile(r"\b(?:https?|ftp)://[^\s<>\"'\\)\]}]+", re.I)
EMAIL_RE = re.compile(r"\b[\w.+-]+@(?:[A-Za-z0-9-]+\.)+[A-Za-z]{2,}\b")
DOMAIN_RE = re.compile(r"\b(?:[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?\.)+[A-Za-z]{2,24}\b")
IPV4_RE = re.compile(r"(?<![\w.])(?:\d{1,3}\.){3}\d{1,3}(?![\w.]\d)")
IPV6_RE = re.compile(r"(?<![\w:])(?:[0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{0,4}(?![\w:])")
HASH_RES = [("sha256", re.compile(r"\b[a-fA-F0-9]{64}\b")), ("sha1", re.compile(r"\b[a-fA-F0-9]{40}\b")), ("md5", re.compile(r"\b[a-fA-F0-9]{32}\b"))]
CVE_RE = re.compile(r"\bCVE-\d{4}-\d{4,7}\b", re.I)
ATTACK_RE = re.compile(r"\bT\d{4}(?:\.\d{3})?\b")


def refang(text):
    for pat, rep in REFANG:
        text = re.sub(pat, rep, text, flags=re.I)
    return text


def defang(value, kind):
    if kind == "url":
        m = re.match(r"(?i)https?(://)([^/?#]+)(.*)$", value)
        if not m:
            return value
        scheme = "hxxps" if value.lower().startswith("https") else "hxxp"
        return f"{scheme}{m.group(1)}{m.group(2).replace('.', '[.]')}{m.group(3)}"
    if kind in ("domain", "ipv4", "ipv6"):
        return value.replace(".", "[.]") if kind != "ipv6" else value.replace(":", "[:]")
    if kind == "email":
        return value.replace("@", "[@]").replace(".", "[.]")
    return value


def extract_iocs(text, do_refang=True, include_private=False):
    if len(text) > 5_000_000:
        raise ValueError("The text is larger than the 5 MB limit.")
    t = refang(text) if do_refang else text
    found = {}

    def put(kind, values):
        uniq = sorted(set(values), key=lambda v: (v.lower(), v))
        if uniq:
            found[kind] = [{"value": v, "defanged": defang(v, kind), "count": t.count(v)} for v in uniq]

    urls = [u.rstrip(".,;:") for u in URL_RE.findall(t)]
    put("url", urls)
    put("email", EMAIL_RE.findall(t))
    ips = []
    for m in IPV4_RE.findall(t):
        try:
            a = ipaddress.ip_address(m)
        except ValueError:
            continue
        if include_private or a.is_global:
            ips.append(m)
    put("ipv4", ips)
    v6 = []
    for m in IPV6_RE.findall(t):
        try:
            a = ipaddress.ip_address(m)
        except ValueError:
            continue
        if include_private or a.is_global:
            v6.append(m)
    put("ipv6", v6)
    mails = {e.rsplit("@", 1)[-1].lower() for e in EMAIL_RE.findall(t)}
    domains = set()
    for d in DOMAIN_RE.findall(re.sub(r"https?://[^\s/]+@", "", t)):
        low = d.lower()
        if low.rsplit(".", 1)[-1] in FILE_EXT or _valid_ip(low) or re.fullmatch(r"[\d.]+", low):
            continue
        domains.add(low)
    put("domain", sorted(domains - set()))
    seen_hash = set()
    for name, rx in HASH_RES:
        vals = [h for h in rx.findall(t) if h.lower() not in seen_hash]
        seen_hash.update(h.lower() for h in vals)
        put(name, [h.lower() for h in vals])
    put("cve", [c.upper() for c in CVE_RE.findall(t)])
    put("attack", ATTACK_RE.findall(t))
    return {"iocs": found, "total": sum(len(v) for v in found.values()),
            "note": "Extracted by pattern matching. Domains and addresses found in text are not verified, and an indicator in a document is not proof of compromise."}


# ------------------------------------------------------------------- timestamps

EPOCHS = [
    ("Unix seconds", lambda n: datetime(1970, 1, 1, tzinfo=UTC) + timedelta(seconds=n)),
    ("Unix milliseconds", lambda n: datetime(1970, 1, 1, tzinfo=UTC) + timedelta(milliseconds=n)),
    ("Unix microseconds", lambda n: datetime(1970, 1, 1, tzinfo=UTC) + timedelta(microseconds=n)),
    ("Unix nanoseconds", lambda n: datetime(1970, 1, 1, tzinfo=UTC) + timedelta(microseconds=n / 1000)),
    ("Windows FILETIME (100 ns since 1601)", lambda n: datetime(1601, 1, 1, tzinfo=UTC) + timedelta(microseconds=n / 10)),
    ("WebKit or Chrome (microseconds since 1601)", lambda n: datetime(1601, 1, 1, tzinfo=UTC) + timedelta(microseconds=n)),
    ("Mac absolute time (seconds since 2001)", lambda n: datetime(2001, 1, 1, tzinfo=UTC) + timedelta(seconds=n)),
    ("HFS+ (seconds since 1904)", lambda n: datetime(1904, 1, 1, tzinfo=UTC) + timedelta(seconds=n)),
    ("Excel serial date (days since 1899-12-30)", lambda n: datetime(1899, 12, 30, tzinfo=UTC) + timedelta(days=n)),
    (".NET ticks (100 ns since year 1)", lambda n: datetime(1, 1, 1, tzinfo=UTC) + timedelta(microseconds=n / 10)),
]
ENCODERS = [
    ("Unix seconds", lambda d: int((d - datetime(1970, 1, 1, tzinfo=UTC)).total_seconds())),
    ("Unix milliseconds", lambda d: int((d - datetime(1970, 1, 1, tzinfo=UTC)).total_seconds() * 1000)),
    ("Windows FILETIME", lambda d: int((d - datetime(1601, 1, 1, tzinfo=UTC)).total_seconds() * 10_000_000)),
    ("WebKit or Chrome", lambda d: int((d - datetime(1601, 1, 1, tzinfo=UTC)).total_seconds() * 1_000_000)),
    ("Mac absolute time", lambda d: int((d - datetime(2001, 1, 1, tzinfo=UTC)).total_seconds())),
    ("Excel serial date", lambda d: round((d - datetime(1899, 12, 30, tzinfo=UTC)).total_seconds() / 86400, 6)),
]


def decode_timestamp(value):
    value = value.strip()
    if not value:
        raise ValueError("Enter a number, a hex value or a date.")
    iso = None
    try:
        iso = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if iso.tzinfo is None:
            iso = iso.replace(tzinfo=UTC)
    except ValueError:
        pass
    if iso is not None and not re.fullmatch(r"-?\d+(\.\d+)?", value):
        return {"mode": "date", "interpretation": iso.astimezone(UTC).isoformat(timespec="seconds"),
                "encodings": [{"format": n, "value": str(fn(iso.astimezone(UTC)))} for n, fn in ENCODERS]}
    try:
        num = int(value, 16) if re.fullmatch(r"0[xX][0-9a-fA-F]+", value) else float(value)
    except ValueError:
        raise ValueError("Could not read that as a number, hex value or ISO date (for example 2026-10-03T14:30:00Z).") from None
    results = []
    for name, fn in EPOCHS:
        try:
            d = fn(num)
            results.append({"format": name, "utc": d.isoformat(timespec="seconds"), "plausible": 1995 <= d.year <= 2100})
        except (OverflowError, ValueError):
            results.append({"format": name, "utc": None, "plausible": False})
    return {"mode": "number", "input": str(num), "results": results,
            "note": "Several formats can produce a believable date for the same number. Plausible means the year falls between 1995 and 2100; context decides which is right."}
