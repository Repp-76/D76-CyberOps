"""Subnet maths, local host diagnostics, cron parsing and permission calculators."""
import ipaddress
import os
import platform
import re
import shutil
import socket
import sys
import threading
import time
from datetime import datetime, timedelta


# ------------------------------------------------------------------- subnets

def _net(text, strict=False):
    try:
        return ipaddress.ip_network(text.strip(), strict=strict)
    except ValueError as e:
        raise ValueError(f"'{text.strip()}' is not a valid address or CIDR block ({e}).") from None


def describe_network(text):
    n = _net(text)
    v4 = n.version == 4
    first, last = n.network_address, n.broadcast_address
    hosts = n.num_addresses - 2 if v4 and n.prefixlen < 31 else n.num_addresses
    out = {"version": n.version, "cidr": str(n), "network": str(first), "netmask": str(n.netmask), "prefix": n.prefixlen,
           "addresses": str(n.num_addresses), "usable_hosts": str(max(hosts, 0))}
    if v4:
        out.update(wildcard=str(n.hostmask), broadcast=str(last) if n.prefixlen < 31 else None,
                   first_host=str(first + 1) if n.prefixlen < 31 else str(first), last_host=str(last - 1) if n.prefixlen < 31 else str(last),
                   netmask_binary=".".join(f"{b:08b}" for b in n.netmask.packed))
    else:
        out.update(first_host=str(first), last_host=str(last))
    probe = first
    out["scope"] = ("private" if probe.is_private and not probe.is_global else "global" if probe.is_global else "reserved")
    if probe.is_loopback:
        out["scope"] = "loopback"
    elif probe.is_link_local:
        out["scope"] = "link-local"
    elif probe.is_multicast:
        out["scope"] = "multicast"
    if v4:
        shared = ipaddress.ip_network("100.64.0.0/10")
        if first in shared:
            out["scope"] = "carrier-grade NAT (shared address space)"
    return out


def describe_ip(text):
    try:
        ip = ipaddress.ip_address(text.strip())
    except ValueError:
        raise ValueError(f"'{text.strip()}' is not a valid IP address.") from None
    out = {"version": ip.version, "address": str(ip), "compressed": ip.compressed, "exploded": ip.exploded, "reverse_pointer": ip.reverse_pointer,
           "integer": str(int(ip)), "hex": hex(int(ip)),
           "private": ip.is_private, "global": ip.is_global, "loopback": ip.is_loopback, "link_local": ip.is_link_local, "multicast": ip.is_multicast}
    if ip.version == 4:
        out["binary"] = ".".join(f"{b:08b}" for b in ip.packed)
        out["ipv4_mapped_ipv6"] = str(ipaddress.IPv6Address("::ffff:" + str(ip)))
    elif ip.ipv4_mapped:
        out["ipv4_mapped"] = str(ip.ipv4_mapped)
    return out


def subnet_action(body):
    action = body.get("action")
    if action == "describe":
        text = str(body.get("value", "")).strip()
        return describe_network(text) if "/" in text else describe_ip(text)
    if action == "ip":
        return describe_ip(str(body.get("value", "")))
    if action == "split":
        n = _net(str(body.get("value", "")))
        try:
            new = int(body.get("prefix"))
        except (TypeError, ValueError):
            raise ValueError("Enter the new prefix length as a number.") from None
        if new <= n.prefixlen or new > n.max_prefixlen:
            raise ValueError(f"The new prefix must be larger than /{n.prefixlen} and at most /{n.max_prefixlen}.")
        count = 2 ** (new - n.prefixlen)
        if count > 1024:
            raise ValueError(f"That would create {count:,} subnets. Choose a prefix that gives at most 1,024.")
        return {"parent": str(n), "count": count, "subnets": [describe_network(str(s)) for s in n.subnets(new_prefix=new)]}
    if action == "contains":
        n = _net(str(body.get("value", "")))
        results = []
        for token in re.split(r"[\s,]+", str(body.get("addresses", "")).strip()):
            if not token:
                continue
            try:
                ip = ipaddress.ip_address(token)
                results.append({"address": token, "inside": ip.version == n.version and ip in n})
            except ValueError:
                results.append({"address": token, "inside": None, "error": "not a valid address"})
        if not results:
            raise ValueError("Enter at least one IP address to test.")
        return {"network": str(n), "results": results[:500]}
    if action == "summarize":
        nets = []
        for token in re.split(r"[\s,]+", str(body.get("value", "")).strip()):
            if token:
                nets.append(_net(token))
        if not nets:
            raise ValueError("Enter at least one CIDR block.")
        v4 = [n for n in nets if n.version == 4]
        v6 = [n for n in nets if n.version == 6]
        merged = [str(n) for n in ipaddress.collapse_addresses(v4)] + [str(n) for n in ipaddress.collapse_addresses(v6)]
        return {"input_count": len(nets), "result": merged}
    if action == "range":
        try:
            a, b = ipaddress.ip_address(str(body.get("start", "")).strip()), ipaddress.ip_address(str(body.get("end", "")).strip())
        except ValueError:
            raise ValueError("Enter a valid start and end address.") from None
        if a.version != b.version or int(a) > int(b):
            raise ValueError("Start and end must be the same IP version, with start not after end.")
        return {"result": [str(n) for n in ipaddress.summarize_address_range(a, b)]}
    raise ValueError("Unknown action.")


# ------------------------------------------------------------ host diagnostics

_lock = threading.Lock()
_last_cpu = None


def _read(path):
    try:
        with open(path) as fh:
            return fh.read()
    except OSError:
        return None


def cpu_percent():
    """CPU use since the previous call. The first call returns None."""
    global _last_cpu
    text = _read("/proc/stat")
    if not text:
        return None
    vals = list(map(int, text.splitlines()[0].split()[1:8]))
    idle, total = vals[3] + vals[4], sum(vals)
    with _lock:
        prev, _last_cpu = _last_cpu, (idle, total, time.time())
    if not prev or total == prev[1]:
        return None
    return round(100 * (1 - (idle - prev[0]) / (total - prev[1])), 1)


def meminfo():
    text = _read("/proc/meminfo")
    if not text:
        return None
    kb = {k: int(v.split()[0]) * 1024 for k, v in (line.split(":", 1) for line in text.splitlines() if ":" in line)}
    total, avail = kb.get("MemTotal", 0), kb.get("MemAvailable", kb.get("MemFree", 0))
    return {"total": total, "available": avail, "used": total - avail, "percent": round(100 * (total - avail) / total, 1) if total else None,
            "swap_total": kb.get("SwapTotal", 0), "swap_used": kb.get("SwapTotal", 0) - kb.get("SwapFree", 0)}


def uptime():
    text = _read("/proc/uptime")
    if not text:
        return None
    s = float(text.split()[0])
    return {"seconds": int(s), "since": (datetime.now() - timedelta(seconds=s)).isoformat(timespec="seconds")}


def top_processes(limit=8):
    procs = []
    try:
        pids = [p for p in os.listdir("/proc") if p.isdigit()]
    except OSError:
        return None
    for pid in pids:
        status = _read(f"/proc/{pid}/status")
        if not status:
            continue
        info = dict(line.split(":", 1) for line in status.splitlines() if ":" in line)
        rss = int(info.get("VmRSS", "0 kB").split()[0]) * 1024 if "VmRSS" in info else 0
        procs.append({"pid": int(pid), "name": info.get("Name", "").strip(), "rss": rss, "state": info.get("State", "").strip()[:1]})
    procs.sort(key=lambda p: p["rss"], reverse=True)
    return procs[:limit]


def listening_ports():
    """TCP sockets in LISTEN state, from /proc. Local information only; nothing is probed."""
    owners = {}
    try:
        for pid in (p for p in os.listdir("/proc") if p.isdigit()):
            try:
                for fd in os.listdir(f"/proc/{pid}/fd"):
                    link = os.readlink(f"/proc/{pid}/fd/{fd}")
                    if link.startswith("socket:["):
                        owners[link[8:-1]] = (int(pid), (_read(f"/proc/{pid}/comm") or "").strip())
            except OSError:
                continue
    except OSError:
        pass
    out, seen = [], False
    for path, v6 in (("/proc/net/tcp", False), ("/proc/net/tcp6", True)):
        text = _read(path)
        if text is None:
            continue
        seen = True
        for line in text.splitlines()[1:]:
            parts = line.split()
            if len(parts) < 10 or parts[3] != "0A":
                continue
            addr_hex, port_hex = parts[1].split(":")
            raw = bytes.fromhex(addr_hex)
            if v6:
                raw = b"".join(raw[i:i + 4][::-1] for i in range(0, 16, 4))
                addr = str(ipaddress.IPv6Address(raw))
            else:
                addr = str(ipaddress.IPv4Address(raw[::-1]))
            owner = owners.get(parts[9])
            local_only = addr in ("127.0.0.1", "::1")
            out.append({"address": addr, "port": int(port_hex, 16), "pid": owner[0] if owner else None, "process": owner[1] if owner else "",
                        "exposure": "this machine only" if local_only else "all interfaces" if addr in ("0.0.0.0", "::") else "a specific interface"})
    if not seen:
        return None
    out.sort(key=lambda r: r["port"])
    return out


def host_info():
    disks = []
    for label, path in (("Root", os.path.abspath(os.sep)), ("Working folder", os.getcwd())):
        try:
            u = shutil.disk_usage(path)
            if not any(d["path"] == path for d in disks):
                disks.append({"label": label, "path": path, "total": u.total, "used": u.used, "percent": round(100 * u.used / u.total, 1) if u.total else None})
        except OSError:
            pass
    load = None
    if hasattr(os, "getloadavg"):
        try:
            load = [round(x, 2) for x in os.getloadavg()]
        except OSError:
            pass
    return {"system": {"os": f"{platform.system()} {platform.release()}", "machine": platform.machine(), "hostname": socket.gethostname(),
                       "python": sys.version.split()[0], "cpu_count": os.cpu_count()},
            "load": load, "memory": meminfo(), "uptime": uptime(), "disks": disks, "cpu": cpu_percent(),
            "processes": top_processes(), "listening": listening_ports()}


# ----------------------------------------------------------------------- cron

MONTHS = {m: i for i, m in enumerate(["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"], 1)}
DAYS = {d: i for i, d in enumerate(["sun", "mon", "tue", "wed", "thu", "fri", "sat"])}
ALIASES = {"@yearly": "0 0 1 1 *", "@annually": "0 0 1 1 *", "@monthly": "0 0 1 * *", "@weekly": "0 0 * * 0", "@daily": "0 0 * * *", "@midnight": "0 0 * * *", "@hourly": "0 * * * *"}
FIELDS = [("minute", 0, 59, {}), ("hour", 0, 23, {}), ("day of month", 1, 31, {}), ("month", 1, 12, MONTHS), ("day of week", 0, 7, DAYS)]


def _field(text, lo, hi, names, label):
    values = set()
    for part in text.split(","):
        if not part:
            raise ValueError(f"Empty list item in the {label} field.")
        step = 1
        if "/" in part:
            part, _, s = part.partition("/")
            if not s.isdigit() or int(s) == 0:
                raise ValueError(f"Invalid step '/{s}' in the {label} field.")
            step = int(s)
        if part == "*":
            a, b = lo, (6 if label == "day of week" else hi)
        else:
            def num(tok):
                tok = tok.lower()
                if tok in names:
                    return names[tok]
                if not tok.isdigit():
                    raise ValueError(f"'{tok}' is not valid in the {label} field.")
                return int(tok)
            if "-" in part:
                x, _, y = part.partition("-")
                a, b = num(x), num(y)
            else:
                a = b = num(part)
        if not (lo <= a <= hi and lo <= b <= hi) or a > b:
            raise ValueError(f"The {label} field must be between {lo} and {hi} (got {part}).")
        values.update(range(a, b + 1, step))
    if label == "day of week" and 7 in values:
        values = (values - {7}) | {0}
    return values


def parse_cron(expr):
    expr = " ".join(expr.strip().split())
    if not expr:
        raise ValueError("Enter a cron expression with five fields, for example */15 9-17 * * mon-fri.")
    expr = ALIASES.get(expr.lower(), expr)
    parts = expr.split(" ")
    if len(parts) != 5:
        raise ValueError(f"A cron expression has five fields (minute hour day-of-month month day-of-week); this has {len(parts)}.")
    sets = [_field(p, lo, hi, names, label) for p, (label, lo, hi, names) in zip(parts, FIELDS)]
    return parts, sets


def next_runs(sets, parts, start, count=8):
    minute, hour, dom, month, dow = sets
    dom_star, dow_star = parts[2].startswith("*"), parts[4].startswith("*")
    t = start.replace(second=0, microsecond=0) + timedelta(minutes=1)
    out, limit = [], t + timedelta(days=366 * 5)
    while t < limit and len(out) < count:
        if t.month not in month:
            t = (t.replace(day=1, hour=0, minute=0) + timedelta(days=32)).replace(day=1)
            continue
        dm, dw = t.day in dom, (t.weekday() + 1) % 7 in dow
        if not dom_star and not dow_star:
            day_ok = dm or dw  # standard cron: either field may match
        elif not dom_star:
            day_ok = dm
        elif not dow_star:
            day_ok = dw
        else:
            day_ok = True
        if not day_ok:
            t = t.replace(hour=0, minute=0) + timedelta(days=1)
            continue
        if t.hour not in hour:
            t = t.replace(minute=0) + timedelta(hours=1)
            continue
        if t.minute not in minute:
            t += timedelta(minutes=1)
            continue
        out.append(t)
        t += timedelta(minutes=1)
    return out


def _list(values, names=None):
    v = sorted(values)
    return ", ".join(str(names[x] if names else x) for x in v)


def explain_cron(expr, start=None, count=8):
    parts, sets = parse_cron(expr)
    day_names = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
    month_names = {i: m.title() for m, i in MONTHS.items()}
    pieces = []
    m, h = sets[0], sets[1]
    if parts[0] == "*" and parts[1] == "*":
        pieces.append("every minute")
    elif parts[0].startswith("*/") and parts[1] == "*":
        pieces.append(f"every {parts[0][2:]} minutes")
    elif len(m) == 1 and len(h) == 1:
        pieces.append(f"at {min(h):02d}:{min(m):02d}")
    else:
        pieces.append(f"at minute {_list(m)} past hour {_list(h)}" if parts[1] != "*" else f"at minute {_list(m)} of every hour")
    if parts[2] != "*":
        pieces.append(f"on day {_list(sets[2])} of the month")
    if parts[4] != "*":
        pieces.append("on " + _list(sets[4], day_names))
    if parts[3] != "*":
        pieces.append("in " + _list(sets[3], month_names))
    notes = []
    if parts[2] != "*" and parts[4] != "*":
        notes.append("When both day-of-month and day-of-week are set, standard cron runs the job when either one matches.")
    notes.append("Times use the clock of the machine that runs cron; check its timezone.")
    start = start or datetime.now()
    return {"fields": dict(zip([f[0] for f in FIELDS], parts)), "summary": (lambda t: t[0].upper() + t[1:] + ".")(", ".join(pieces)),
            "next_runs": [t.isoformat(sep=" ", timespec="minutes") for t in next_runs(sets, parts, start, count)], "notes": notes,
            "from": start.isoformat(sep=" ", timespec="minutes")}


# ---------------------------------------------------------------- permissions

def mode_to_symbolic(mode):
    bits = ""
    for shift, special, ch in ((6, 0o4000, "s"), (3, 0o2000, "s"), (0, 0o1000, "t")):
        r, w, x = (mode >> shift + 2) & 1, (mode >> shift + 1) & 1, (mode >> shift) & 1
        xc = ("x" if x else "-")
        if mode & special:
            xc = ch if x else ch.upper()
        bits += ("r" if r else "-") + ("w" if w else "-") + xc
    return bits


def symbolic_to_mode(text):
    text = text.strip()
    m = re.fullmatch(r"[-dl]?([rwxsStT-]{9})", text)
    if not m:
        raise ValueError("Use nine symbolic characters such as rwxr-xr-x.")
    s, mode = m.group(1), 0
    for who in range(3):
        r, w, x = s[who * 3:who * 3 + 3]
        shift = 6 - who * 3
        mode |= ((r == "r") << (shift + 2)) | ((w == "w") << (shift + 1)) | ((x in "xst") << shift)
        if x in "sS" and who < 2:
            mode |= 0o4000 if who == 0 else 0o2000
        if x in "tT" and who == 2:
            mode |= 0o1000
    return mode


def apply_chmod(expr, start):
    mode = start
    for clause in expr.split(","):
        m = re.fullmatch(r"([ugoa]*)([-+=])([rwxXst]*)", clause.strip())
        if not m:
            raise ValueError(f"Cannot read '{clause.strip()}'. Use forms like u+x, go-w or a=r.")
        who, op, perms = m.groups()
        who = who or "a"
        who = "ugo" if "a" in who else who
        bits = 0
        for w in who:
            shift = {"u": 6, "g": 3, "o": 0}[w]
            for p in perms:
                if p in "rwx":
                    bits |= {"r": 4, "w": 2, "x": 1}[p] << shift
                elif p == "X" and (start & 0o111 or True):
                    bits |= 1 << shift
                elif p == "s" and w in "ug":
                    bits |= 0o4000 if w == "u" else 0o2000
                elif p == "t" and w == "o":
                    bits |= 0o1000
            mask = 7 << shift
            if op == "=":
                mode &= ~mask
        mode = mode | bits if op in "+=" else mode & ~bits
    return mode


def permissions(body):
    action = body.get("action")
    if action == "octal":
        text = str(body.get("value", "")).strip()
        if not re.fullmatch(r"[0-7]{3,4}", text):
            raise ValueError("Enter 3 or 4 octal digits, for example 755 or 4755.")
        mode = int(text, 8)
    elif action == "symbolic":
        mode = symbolic_to_mode(str(body.get("value", "")))
    elif action == "chmod":
        start = str(body.get("start", "644")).strip()
        if not re.fullmatch(r"[0-7]{3,4}", start):
            raise ValueError("The starting mode must be 3 or 4 octal digits.")
        mode = apply_chmod(str(body.get("value", "")), int(start, 8))
    elif action == "umask":
        text = str(body.get("value", "")).strip()
        if not re.fullmatch(r"[0-7]{3,4}", text):
            raise ValueError("Enter a umask such as 022 or 077.")
        um = int(text, 8)
        return {"umask": text, "files": f"{0o666 & ~um:03o}", "files_symbolic": mode_to_symbolic(0o666 & ~um),
                "directories": f"{0o777 & ~um:03o}", "directories_symbolic": mode_to_symbolic(0o777 & ~um)}
    else:
        raise ValueError("Unknown action.")
    notes = []
    if mode & 0o002:
        notes.append("World-writable: any user on the system can modify this.")
    if mode & 0o4000:
        notes.append("Setuid: the program runs with its owner's privileges. Only use this when you must.")
    if mode & 0o2000:
        notes.append("Setgid: the program runs with its group's privileges, or new files inherit the directory's group.")
    if mode & 0o1000:
        notes.append("Sticky bit: in a directory, only a file's owner can delete it.")
    if (mode & 0o007) == 0o007:
        notes.append("Everyone has read, write and execute.")
    return {"octal": f"{mode & 0o7777:04o}", "symbolic": mode_to_symbolic(mode), "notes": notes,
            "table": [{"who": w, "read": bool(mode >> s + 2 & 1), "write": bool(mode >> s + 1 & 1), "execute": bool(mode >> s & 1)} for w, s in (("Owner", 6), ("Group", 3), ("Others", 0))]}
