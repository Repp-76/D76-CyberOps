"""A controlled local command runner. No shell is ever involved: commands are split, checked against an
allowlist policy and started directly. Pipes between allowed commands are supported; redirects are not."""
import codecs
import json
import os
import queue
import re
import shlex
import shutil
import signal
import subprocess
import threading
import time

MAX_OUTPUT = 1_000_000
MAX_TIMEOUT = 120
POSIX = os.name == "posix"

DEFAULT_POLICY = {"timeout": 30, "commands": ({
    "ls": {}, "cat": {}, "head": {}, "tail": {}, "wc": {}, "grep": {}, "uniq": {}, "echo": {}, "stat": {}, "file": {}, "du": {}, "df": {},
    "sort": {"deny_args": [r"^-o", r"^--output"]}, "date": {"deny_args": [r"^-s", r"^--set"]}, "whoami": {}, "id": {}, "uname": {},
    "hostname": {"deny_args": [r"^[^-]"]}, "uptime": {}, "free": {}, "ps": {},
    "find": {"deny_args": [r"^-(exec|execdir|ok|okdir|delete|fprint|fprint0|fprintf|fls)$"]},
    "ping": {"deny_args": [r"^-f$", r"^--flood$", r"^-\w*f"]}, "dig": {}, "nslookup": {}, "host": {}, "traceroute": {},
    "ip": {"subcommands": ["addr", "address", "route", "link", "neigh"], "deny_args": [r"^(set|add|del|delete|flush|change|replace)$"]},
    "git": {"subcommands": ["status", "log", "diff", "show", "branch", "remote"], "deny_args": [r"^--output", r"^--ext-diff$", r"^-c$", r"^--exec-path"]},
} if POSIX else {
    "ping": {}, "ipconfig": {}, "hostname": {}, "whoami": {}, "systeminfo": {}, "tasklist": {}, "nslookup": {}, "tracert": {}, "netstat": {},
})}
BUILTINS = ("cd", "pwd", "help", "clear")
NAME_RE = re.compile(r"^[A-Za-z0-9._+-]{1,40}$")


class PolicyError(ValueError):
    pass


def validate_policy(policy):
    if not isinstance(policy, dict) or not isinstance(policy.get("commands"), dict):
        raise PolicyError("A policy needs a 'commands' object.")
    cmds = policy["commands"]
    if len(cmds) > 150:
        raise PolicyError("A policy can list at most 150 commands.")
    out = {}
    for name, rule in cmds.items():
        if not NAME_RE.match(name) or name in BUILTINS:
            raise PolicyError(f"'{name}' is not a valid command name.")
        rule = rule or {}
        deny = rule.get("deny_args", [])
        subs = rule.get("subcommands")
        if not isinstance(deny, list) or (subs is not None and not isinstance(subs, list)):
            raise PolicyError(f"The rule for '{name}' is malformed.")
        for rx in deny:
            try:
                re.compile(rx)
            except re.error:
                raise PolicyError(f"'{rx}' is not a valid pattern in the rule for {name}.") from None
        out[name] = {"deny_args": [str(x) for x in deny], **({"subcommands": [str(x) for x in subs]} if subs is not None else {})}
    try:
        timeout = max(1, min(MAX_TIMEOUT, int(policy.get("timeout", 30))))
    except (TypeError, ValueError):
        raise PolicyError("The timeout must be a number of seconds.") from None
    return {"timeout": timeout, "commands": out}


def split_pipeline(command):
    """Splits on unquoted pipes and refuses every other shell operator."""
    stages, cur, quote, i = [], [], None, 0
    while i < len(command):
        ch = command[i]
        if quote:
            cur.append(ch)
            if ch == "\\" and quote == '"' and i + 1 < len(command):
                cur.append(command[i + 1]); i += 1
            elif ch == quote:
                quote = None
        elif ch in "'\"":
            quote = ch; cur.append(ch)
        elif ch == "\\" and i + 1 < len(command):
            cur.append(ch); cur.append(command[i + 1]); i += 1
        elif ch == "|":
            if i + 1 < len(command) and command[i + 1] == "|":
                raise PolicyError("'||' is not supported. Run one command at a time.")
            stages.append("".join(cur)); cur = []
        elif ch in ";&<>`" or (ch == "$" and command[i + 1:i + 2] == "("):
            raise PolicyError(f"'{ch}' is not supported: there is no shell here, so no redirects, command chaining, background jobs or substitution.")
        else:
            cur.append(ch)
        i += 1
    if quote:
        raise PolicyError("A quote was opened but never closed.")
    stages.append("".join(cur))
    return stages


def parse(command, policy):
    """Returns ('builtin', argv) or ('run', [argv, ...]). Raises PolicyError with a human-readable reason."""
    command = command.strip()
    if not command:
        raise PolicyError("Type a command. Try help.")
    if len(command) > 2000:
        raise PolicyError("The command is too long.")
    if "\x00" in command:
        raise PolicyError("The command contains an invalid character.")
    stages = split_pipeline(command)
    argvs = []
    for s in stages:
        try:
            argv = shlex.split(s)
        except ValueError:
            raise PolicyError("The command could not be read; check your quotes.") from None
        if not argv:
            raise PolicyError("A pipe needs a command on both sides.")
        argvs.append(argv)
    if len(argvs) > 4:
        raise PolicyError("At most 4 commands can be piped together.")
    if len(argvs) == 1 and argvs[0][0] in BUILTINS:
        return "builtin", argvs[0]
    cmds = policy["commands"]
    for argv in argvs:
        name = argv[0]
        if "/" in name or "\\" in name:
            raise PolicyError("Commands are run by name only, not by path.")
        if name in BUILTINS:
            raise PolicyError(f"{name} cannot be used inside a pipe.")
        if name not in cmds:
            raise PolicyError(f"'{name}' is not on the allowlist. Type help to see what is allowed.")
        rule = cmds[name]
        subs = rule.get("subcommands")
        if subs is not None and (len(argv) < 2 or argv[1] not in subs):
            raise PolicyError(f"{name} is limited to these subcommands: {', '.join(subs)}.")
        for a in argv[1:]:
            for rx in rule.get("deny_args", []):
                if re.search(rx, a):
                    raise PolicyError(f"The argument '{a}' is not allowed for {name}.")
    return "run", argvs


def clean_env():
    home = os.path.expanduser("~")
    env = {"PATH": os.environ.get("PATH", "/usr/local/bin:/usr/bin:/bin"), "HOME": home, "LANG": "C.UTF-8", "TERM": "dumb"}
    if not POSIX:
        env["SYSTEMROOT"] = os.environ.get("SYSTEMROOT", "")
    return env


def change_dir(cwd, target):
    path = os.path.abspath(os.path.join(cwd, os.path.expanduser(target or "~")))
    if not os.path.isdir(path):
        raise PolicyError(f"cd: {target}: no such directory")
    if not os.access(path, os.R_OK | os.X_OK):
        raise PolicyError(f"cd: {target}: permission denied")
    return path


def kill(proc):
    try:
        if POSIX:
            os.killpg(proc.pid, signal.SIGKILL)
        else:
            proc.kill()
    except (ProcessLookupError, PermissionError, OSError):
        pass


def run(argvs, cwd, timeout):
    """Generator of event dicts: start, out, err, exit."""
    env = clean_env()
    started = time.time()
    procs, resolved = [], []
    for argv in argvs:
        exe = shutil.which(argv[0], path=env["PATH"])
        if not exe:
            yield {"t": "err", "d": f"{argv[0]}: command not found on this system\n"}
            yield {"t": "exit", "code": 127, "ms": 0, "timeout": False, "truncated": False}
            return
        resolved.append([exe, *argv[1:]])
    yield {"t": "start", "cwd": cwd, "commands": [a[0] for a in argvs]}
    q = queue.Queue()
    prev, threads = None, []

    def pump(stream, kind):
        dec = codecs.getincrementaldecoder("utf-8")("replace")
        try:
            while chunk := stream.read1(4096) if hasattr(stream, "read1") else stream.read(4096):
                q.put((kind, dec.decode(chunk)))
        except (ValueError, OSError):
            pass
        q.put((kind, None))

    try:
        for i, argv in enumerate(resolved):
            kw = {"start_new_session": True} if POSIX else {"creationflags": getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)}
            p = subprocess.Popen(argv, cwd=cwd, env=env, stdin=prev.stdout if prev else subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE, **kw)
            if prev:
                prev.stdout.close()
            procs.append(p)
            threads.append(threading.Thread(target=pump, args=(p.stderr, "err"), daemon=True))
            prev = p
        threads.append(threading.Thread(target=pump, args=(prev.stdout, "out"), daemon=True))
        for t in threads:
            t.start()
        pending, total, truncated, timed_out = len(threads), 0, False, False
        deadline = started + timeout
        while pending:
            try:
                kind, data = q.get(timeout=0.1)
            except queue.Empty:
                if time.time() > deadline:
                    timed_out = True
                    break
                continue
            if data is None:
                pending -= 1
                continue
            total += len(data)
            if total > MAX_OUTPUT:
                truncated = True
                break
            yield {"t": kind, "d": data}
            if time.time() > deadline:
                timed_out = True
                break
        if timed_out or truncated:
            for p in procs:
                kill(p)
        code = None
        for p in procs:
            try:
                code = p.wait(timeout=2)
            except subprocess.TimeoutExpired:
                kill(p)
                code = p.wait()
        yield {"t": "exit", "code": code, "ms": round((time.time() - started) * 1000), "timeout": timed_out, "truncated": truncated}
    finally:
        for p in procs:
            if p.poll() is None:
                kill(p)
