"""Threat intelligence feeds: fetch, normalise and cache advisories from public sources."""
import html
import json
import os
import re
import urllib.parse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone
from email.utils import parsedate_to_datetime
from xml.etree import ElementTree

import db
import netutil

DEFAULT_FEEDS = [
    ("CISA Known Exploited Vulnerabilities", "https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json", "kev"),
    ("CISA Cybersecurity Advisories", "https://www.cisa.gov/cybersecurity-advisories/all.xml", "rss"),
    ("NVD: CVEs published in the last 7 days", "https://services.nvd.nist.gov/rest/json/cves/2.0", "nvd"),
    ("Microsoft Security Response Center", "https://api.msrc.microsoft.com/update-guide/rss", "rss"),
    ("Ubuntu Security Notices", "https://ubuntu.com/security/notices/rss.xml", "rss"),
]
CVE_RE = re.compile(r"CVE-\d{4}-\d{4,7}", re.I)
TAG_RE = re.compile(r"<[^>]+>")
CACHE_MINUTES = 15
KEEP_PER_FEED = 500
MAX_BYTES = 8 * 1024 * 1024


def text(s, limit=600):
    return " ".join(html.unescape(TAG_RE.sub(" ", s or "")).split())[:limit]


def to_iso(value):
    if not value:
        return None
    value = value.strip()
    try:
        dt = parsedate_to_datetime(value)
    except (TypeError, ValueError):
        try:
            dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError:
            return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc).isoformat(timespec="seconds")


def local(tag):
    return tag.rsplit("}", 1)[-1]


def parse_rss(body):
    if b"<!ENTITY" in body:
        raise ValueError("The feed declares XML entities and was rejected for safety.")
    try:
        root = ElementTree.fromstring(body)
    except ElementTree.ParseError:
        raise ValueError("The response is not valid XML (is the URL really a feed?).") from None
    items = []
    for node in root.iter():
        if local(node.tag) not in ("item", "entry"):
            continue
        f = {}
        for ch in node:
            name = local(ch.tag)
            if name == "link":
                f.setdefault("link", ch.attrib.get("href") if ch.attrib.get("href") and ch.attrib.get("rel", "alternate") == "alternate" else (ch.text or "").strip())
            elif name in ("title", "description", "summary", "content", "pubDate", "published", "updated", "date", "guid", "id"):
                f.setdefault(name, "".join(ch.itertext()).strip())
        title = text(f.get("title"), 300)
        if not title:
            continue
        body_text = text(f.get("description") or f.get("summary") or f.get("content"))
        cve = (CVE_RE.search(title) or CVE_RE.search(body_text))
        items.append({"guid": f.get("guid") or f.get("id") or f.get("link") or title, "title": title, "link": (f.get("link") or "")[:1000], "summary": body_text,
                      "severity": "unrated", "exploited": 0, "cve": cve.group(0).upper() if cve else "",
                      "published": to_iso(f.get("pubDate") or f.get("published") or f.get("updated") or f.get("date"))})
    return items


def parse_kev(body):
    try:
        data = json.loads(body)
        vulns = data["vulnerabilities"]
    except (ValueError, KeyError, TypeError):
        raise ValueError("The response is not a CISA Known Exploited Vulnerabilities catalog.") from None
    vulns = sorted(vulns, key=lambda v: v.get("dateAdded", ""), reverse=True)[:400]
    out = []
    for v in vulns:
        cve = v.get("cveID", "")
        out.append({"guid": cve, "title": f"{cve}: {v.get('vulnerabilityName', '')}".strip(": "), "link": f"https://nvd.nist.gov/vuln/detail/{cve}",
                    "summary": text(f"{v.get('vendorProject', '')} {v.get('product', '')}. {v.get('shortDescription', '')} Required action: {v.get('requiredAction', '')} Due: {v.get('dueDate', '')}"),
                    "severity": "unrated", "exploited": 1, "cve": cve, "published": to_iso(v.get("dateAdded", "") + "T00:00:00+00:00") if v.get("dateAdded") else None})
    return out


def parse_nvd(body):
    try:
        vulns = json.loads(body)["vulnerabilities"]
    except (ValueError, KeyError, TypeError):
        raise ValueError("The response is not an NVD CVE API result.") from None
    out = []
    for v in vulns:
        c = v.get("cve", {})
        cid = c.get("id", "")
        desc = next((d.get("value", "") for d in c.get("descriptions", []) if d.get("lang") == "en"), "")
        sev = "unrated"
        for key in ("cvssMetricV40", "cvssMetricV31", "cvssMetricV30", "cvssMetricV2"):
            m = (c.get("metrics", {}).get(key) or [None])[0]
            if m:
                sev = str((m.get("cvssData", {}).get("baseSeverity") or m.get("baseSeverity") or "unrated")).lower()
                break
        out.append({"guid": cid, "title": f"{cid}: {text(desc, 110)}", "link": f"https://nvd.nist.gov/vuln/detail/{cid}", "summary": text(desc),
                    "severity": sev if sev in ("critical", "high", "medium", "low", "none") else "unrated", "exploited": 0, "cve": cid, "published": to_iso(c.get("published"))})
    return out


def fetch_feed(feed, allow_private=False):
    url, headers = feed["url"], {}
    if feed["kind"] == "nvd":
        if "pubStartDate" not in url:
            now = datetime.now(timezone.utc)
            q = {"pubStartDate": (now - timedelta(days=7)).strftime("%Y-%m-%dT%H:%M:%S.000"), "pubEndDate": now.strftime("%Y-%m-%dT%H:%M:%S.000"), "resultsPerPage": "200"}
            url += ("&" if "?" in url else "?") + urllib.parse.urlencode(q)
        key = os.environ.get("D76_NVD_API_KEY")
        if key:
            headers["apiKey"] = key
    for _ in range(4):
        r = netutil.request(url, "GET", headers, None, allow_private, 20, True, MAX_BYTES)
        loc = netutil.header(r["headers"], "location")
        if r["status"] in netutil.REDIRECTS and loc:
            url = urllib.parse.urljoin(url, loc)
            continue
        break
    else:
        raise netutil.NetError("Too many redirects.")
    if r["status"] == 403 and feed["kind"] == "nvd":
        raise ValueError("NVD refused the request (HTTP 403). It rate-limits requests without an API key; set D76_NVD_API_KEY and try again later.")
    if r["status"] != 200:
        raise ValueError(f"The server answered with HTTP {r['status']}.")
    if len(r["body"]) > MAX_BYTES:
        raise ValueError("The feed is larger than 8 MB.")
    return {"rss": parse_rss, "kev": parse_kev, "nvd": parse_nvd}[feed["kind"]](r["body"])


def store(feed_id, items):
    now = db.now()
    added = 0
    for it in items:
        exists = db.query("SELECT 1 FROM intel_items WHERE feed_id = ? AND guid = ?", (feed_id, it["guid"]))
        db.run("INSERT INTO intel_items (feed_id, guid, title, link, summary, severity, exploited, cve, published, fetched) VALUES (?,?,?,?,?,?,?,?,?,?) "
               "ON CONFLICT(feed_id, guid) DO UPDATE SET title=excluded.title, link=excluded.link, summary=excluded.summary, severity=excluded.severity, "
               "exploited=excluded.exploited, cve=excluded.cve, published=excluded.published, fetched=excluded.fetched",
               (feed_id, it["guid"][:500], it["title"], it["link"], it["summary"], it["severity"], it["exploited"], it["cve"], it["published"], now))
        added += 0 if exists else 1
    db.run("DELETE FROM intel_items WHERE feed_id = ? AND bookmarked = 0 AND id NOT IN "
           "(SELECT id FROM intel_items WHERE feed_id = ? ORDER BY published DESC, id DESC LIMIT ?)", (feed_id, feed_id, KEEP_PER_FEED))
    return added


def refresh_one(feed, force, allow_private):
    if not force and feed["last_fetch"]:
        age = datetime.now(timezone.utc) - datetime.fromisoformat(feed["last_fetch"])
        if age < timedelta(minutes=CACHE_MINUTES) and feed["last_status"] == "ok":
            return {"id": feed["id"], "name": feed["name"], "skipped": True, "ok": True, "added": 0}
    try:
        items = fetch_feed(feed, allow_private)
        added = store(feed["id"], items)
        db.run("UPDATE feeds SET last_fetch = ?, last_status = 'ok' WHERE id = ?", (db.now(), feed["id"]))
        return {"id": feed["id"], "name": feed["name"], "ok": True, "added": added, "total": len(items)}
    except (ValueError, netutil.NetError) as e:
        db.run("UPDATE feeds SET last_fetch = ?, last_status = ? WHERE id = ?", (db.now(), "error: " + str(e)[:300], feed["id"]))
        return {"id": feed["id"], "name": feed["name"], "ok": False, "error": str(e)}


def refresh(force=False, feed_id=None, allow_private=False):
    feeds = db.query("SELECT * FROM feeds WHERE enabled = 1" + (" AND id = ?" if feed_id else ""), (feed_id,) if feed_id else ())
    with ThreadPoolExecutor(max_workers=4) as pool:
        return list(pool.map(lambda f: refresh_one(f, force, allow_private), feeds))


def seed_feeds():
    if db.get_settings().get("feeds_seeded") == "1":
        return
    now = db.now()
    for name, url, kind in DEFAULT_FEEDS:
        db.run("INSERT INTO feeds (name, url, kind, created, updated) VALUES (?,?,?,?,?)", (name, url, kind, now, now))
    db.set_settings({"feeds_seeded": "1"})
