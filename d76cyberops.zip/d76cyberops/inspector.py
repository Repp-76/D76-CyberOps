"""Domain Inspector: DNS, TLS, HTTP and registration data for a host the user is authorized to inspect."""
import ipaddress
import json
import re
import time
import urllib.parse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone

import dnsclient
import netutil

HOST_RE = re.compile(r"^(?=.{1,253}$)([a-z0-9_]([a-z0-9_-]{0,61}[a-z0-9_])?)(\.[a-z0-9_]([a-z0-9_-]{0,61}[a-z0-9_])?)*$")
SECURITY_HEADERS = ["strict-transport-security", "content-security-policy", "x-content-type-options", "x-frame-options", "referrer-policy", "permissions-policy"]
DEFAULT_TYPES = ["A", "AAAA", "MX", "NS", "TXT", "CNAME", "SOA", "CAA"]


def clean_target(raw):
    """Returns (host, is_ip, port or None)."""
    t = raw.strip().lower()
    if not t:
        raise ValueError("Enter a domain, hostname or IP address.")
    if "://" in t:
        parts = urllib.parse.urlsplit(t)
        host, port = parts.hostname or "", parts.port
    else:
        t = t.split("/")[0]
        port = None
        m = re.fullmatch(r"(\[[0-9a-f:]+\]|[^:\[\]]+):(\d{1,5})", t)
        if m:
            t, port = m.group(1), int(m.group(2))
        host = t.strip("[]")
    if port is not None and not 1 <= port <= 65535:
        raise ValueError("The port must be between 1 and 65535.")
    try:
        ipaddress.ip_address(host)
        return host, True, port
    except ValueError:
        pass
    host = host.rstrip(".")
    try:
        host = host.encode("idna").decode("ascii")
    except UnicodeError:
        raise ValueError("That is not a valid hostname.") from None
    if not HOST_RE.match(host):
        raise ValueError("That is not a valid hostname. Use letters, digits, hyphens and dots.")
    return host, False, port


def dns_section(host, types):
    servers = dnsclient.system_resolvers()
    if not servers:
        return {"ok": False, "error": "No DNS resolver is configured on this system. Set the D76_DNS_SERVERS environment variable (for example 192.168.1.1) and restart D76."}

    def one(t):
        try:
            res = dnsclient.query(host, t, servers)
        except dnsclient.DnsError as e:
            return {"type": t, "status": "error", "error": str(e), "records": []}
        recs = [a for a in res["answers"] if a["type"] in (t, "CNAME")]
        status = {0: "ok" if recs else "empty", 3: "nxdomain", 2: "servfail", 5: "refused"}.get(res["rcode"], "error")
        return {"type": t, "status": status, "records": recs, "resolver": res["resolver"]}

    with ThreadPoolExecutor(max_workers=8) as pool:
        results = list(pool.map(one, types))
    return {"ok": True, "resolvers": servers, "results": results, "nxdomain": any(r["status"] == "nxdomain" for r in results)}


def tls_section(host, port, allow_private):
    try:
        return {"ok": True, **netutil.tls_probe(host, port or 443, allow_private)}
    except netutil.NetError as e:
        return {"ok": False, "error": str(e)}


def http_section(host, port, allow_private):
    if port is None:
        candidates = [f"https://{host}/", f"http://{host}/"]
    elif port == 443:
        candidates = [f"https://{host}/"]
    elif port == 80:
        candidates = [f"http://{host}/"]
    else:
        candidates = [f"https://{host}:{port}/", f"http://{host}:{port}/"]
    errors = []
    for start in candidates:
        chain, url, final = [], start, None
        try:
            for _ in range(10):
                t0 = time.perf_counter()
                r = netutil.request(url, "GET", None, None, allow_private, 8)
                ms = round((time.perf_counter() - t0) * 1000)
                loc = netutil.header(r["headers"], "location")
                chain.append({"url": url, "status": r["status"], "reason": r["reason"], "ip": r["ip"], "ms": ms, "location": loc, "tls": r["tls"]})
                final = r
                if r["status"] in netutil.REDIRECTS and loc:
                    nxt = urllib.parse.urljoin(url, loc)
                    if nxt in [c["url"] for c in chain]:
                        return {"ok": True, "chain": chain, "note": "The redirects form a loop.", "final": summarize(final), "url": url}
                    url = nxt
                    continue
                break
            else:
                return {"ok": True, "chain": chain, "note": "Stopped after 10 redirects.", "final": summarize(final), "url": url}
            return {"ok": True, "chain": chain, "final": summarize(final), "url": url}
        except netutil.NetError as e:
            if chain:
                return {"ok": True, "chain": chain, "note": f"The chain stopped: {e}", "final": summarize(final) if final else None, "url": url}
            errors.append(f"{start} - {e}")
    return {"ok": False, "error": " | ".join(errors)}


def summarize(r):
    headers = r["headers"]
    present = {k.lower(): v for k, v in headers}
    return {"status": r["status"], "reason": r["reason"], "http_version": r["http_version"], "headers": headers,
            "security": [{"header": h, "present": h in present, "value": present.get(h)} for h in SECURITY_HEADERS]}


def parse_rdap(data):
    events = {e.get("eventAction"): e.get("eventDate") for e in data.get("events", []) if isinstance(e, dict)}
    registrar = None
    for ent in data.get("entities", []):
        if "registrar" in ent.get("roles", []):
            for item in (ent.get("vcardArray") or [None, []])[1]:
                if item and item[0] == "fn":
                    registrar = item[3]
    return {"name": data.get("ldhName"), "status": data.get("status", []), "registrar": registrar, "registered": events.get("registration"),
            "expires": events.get("expiration"), "last_changed": events.get("last changed"),
            "nameservers": [n.get("ldhName") for n in data.get("nameservers", []) if isinstance(n, dict)]}


def rdap_section(host):
    if re.fullmatch(r"[\d.]+", host) or ":" in host or "." not in host:
        return {"ok": False, "error": "Registration data is only available for registered domain names."}
    try:
        status, body, _ = rdap_fetch(f"https://rdap.org/domain/{urllib.parse.quote(host)}")
    except netutil.NetError as e:
        return {"ok": False, "error": str(e)}
    if status == 404:
        return {"ok": False, "error": "No registration record was found. RDAP covers registered domains, so try the parent domain."}
    if status != 200:
        return {"ok": False, "error": f"The RDAP service answered with HTTP {status}."}
    try:
        return {"ok": True, **parse_rdap(json.loads(body))}
    except (ValueError, AttributeError):
        return {"ok": False, "error": "The RDAP response could not be read."}


def rdap_fetch(url):
    for _ in range(4):
        r = netutil.request(url, "GET", {"Accept": "application/rdap+json"}, None, False, 10, True, 1024 * 1024)
        loc = netutil.header(r["headers"], "location")
        if r["status"] in netutil.REDIRECTS and loc:
            url = urllib.parse.urljoin(url, loc)
            continue
        return r["status"], r["body"], url
    raise netutil.NetError("Too many redirects from the RDAP service.")


def inspect_target(opts):
    host, is_ip, port = clean_target(str(opts.get("target", "")))
    if not opts.get("authorized"):
        raise ValueError("Confirm that you own this target or are authorized to inspect it.")
    types = [t for t in opts.get("types", DEFAULT_TYPES) if t in dnsclient.TYPES] or DEFAULT_TYPES
    private = bool(opts.get("allow_private"))
    jobs = {}
    with ThreadPoolExecutor(max_workers=4) as pool:
        if opts.get("dns", True) and not is_ip:
            jobs["dns"] = pool.submit(dns_section, host, types)
        if opts.get("tls", True):
            jobs["tls"] = pool.submit(tls_section, host, port, private)
        if opts.get("http", True):
            jobs["http"] = pool.submit(http_section, host, port, private)
        if opts.get("rdap") and not is_ip:
            jobs["rdap"] = pool.submit(rdap_section, host)
        out = {k: f.result() for k, f in jobs.items()}
    return {"target": host, "port": port, "is_ip": is_ip, "generated": datetime.now(timezone.utc).isoformat(timespec="seconds"), **out}
