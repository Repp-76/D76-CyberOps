import hashlib
import hmac
import json
import re

from flask import Blueprint, Response, abort, jsonify, render_template, request

import db

bp = Blueprint("res", __name__)

CASE_STATUS = ("open", "in review", "closed")
EVIDENCE_STATUS = ("collected", "in analysis", "archived")
ENTITY_KINDS = ("person", "organization", "domain", "website", "username", "url", "note")
LANGS = ("html", "css", "javascript", "python", "json", "sql", "bash", "markdown", "text")
KB_CATEGORIES = ("Cybersecurity", "OSINT", "Networking", "Linux", "Programming", "Web Security",
                 "Digital Forensics", "Developer Tools", "Privacy", "Security Awareness")
TASK_STATUS = ("backlog", "progress", "review", "done")
TASK_LABEL = {"backlog": "Backlog", "progress": "In progress", "review": "Review", "done": "Completed"}
PRIORITIES = ("low", "normal", "high", "urgent")
HTTP_METHODS = ("GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS")
STEP_TYPES = ("trim", "remove_empty", "dedupe", "sort", "reverse", "case", "replace", "keep_matching", "remove_matching",
              "extract", "prefix_suffix", "number_lines", "head", "tail", "split", "join", "count_unique")
SENSITIVE_HEADERS = {"authorization", "proxy-authorization", "cookie", "x-api-key", "api-key", "x-auth-token", "x-csrf-token",
                     "x-xsrf-token", "x-access-token"}
SENSITIVE_PARAMS = re.compile(r"(?i)([?&])(api[_-]?key|key|token|access_token|auth|secret|password|sig|signature)=[^&#\s{]+")


def sanitize_request(values):
    """Saved requests never keep credentials: sensitive header values and URL parameters become {{placeholders}}."""
    if "headers" in values:
        lines = []
        for line in values["headers"].splitlines():
            name, sep, val = line.partition(":")
            if sep and name.strip().lower() in SENSITIVE_HEADERS and val.strip() and not re.fullmatch(r"\{\{[\w-]+\}\}", val.strip()):
                line = name.strip() + ": {{" + name.strip().lower() + "}}"
            lines.append(line)
        values["headers"] = "\n".join(lines)
    if "url" in values:
        values["url"] = SENSITIVE_PARAMS.sub(lambda m: m.group(1) + m.group(2) + "={{" + m.group(2).lower() + "}}", values["url"])


def pipeline_validate(values, old):
    if "steps" not in values:
        return None
    try:
        steps = json.loads(values["steps"])
    except json.JSONDecodeError:
        return "Steps must be valid JSON."
    if not isinstance(steps, list) or len(steps) > 60:
        return "A pipeline is a list of at most 60 steps."
    for st in steps:
        if not isinstance(st, dict) or st.get("type") not in STEP_TYPES:
            return "Unknown step type in the pipeline."

DATE = re.compile(r"\d{4}-\d{2}-\d{2}$")
URL = re.compile(r"https?://\S+$")
SHA256 = re.compile(r"[0-9a-f]{64}$")
QUIET = {"read", "bookmarked", "favorite"}  # toggles that should not flood the activity log


def err(message, code=400):
    return jsonify(error=message), code


def relation_validate(values, old):
    if old:
        return None
    if values["src"] == values["dst"]:
        return "An entity cannot be related to itself."
    rows = db.query("SELECT case_id FROM entities WHERE id IN (?, ?)", (values["src"], values["dst"]))
    if len(rows) != 2 or {r["case_id"] for r in rows} != {values["case_id"]}:
        return "Both entities must belong to this research case."


def task_hook(action, old, new):
    task = new or old
    if action == "create":
        event = f'Task created in {TASK_LABEL[new["status"]]}: {new["title"]}'
    elif action == "delete":
        event = f'Task deleted: {old["title"]}'
    elif old["status"] != new["status"]:
        event = f'Moved "{new["title"]}" from {TASK_LABEL[old["status"]]} to {TASK_LABEL[new["status"]]}'
    else:
        changed = [k for k in ("title", "priority", "due", "notes", "tags") if old[k] != new[k]]
        if not changed:
            return
        event = f'Edited "{new["title"]}" ({", ".join(changed)})'
    db.run("INSERT INTO task_history (project_id, task_id, ts, event) VALUES (?, ?, ?, ?)",
           (task["project_id"], task["id"], db.now(), event))


# field -> (type, param, required). Types: str(maxlen) choice(options) bool date url(maxlen) tags ref(table)
R = {
    "cases": dict(table="cases", tool="CaseVault", noun="Case", ts=("created", "updated"),
        order="updated DESC", filters=("kind", "status"), immutable=("kind",),
        search=("title", "description", "tags", "investigator"),
        fields={"title": ("str", 200, True), "description": ("str", 20000, False),
                "status": ("choice", CASE_STATUS, False), "tags": ("tags", None, False),
                "investigator": ("str", 120, False), "kind": ("choice", ("case", "research"), False)}),
    "notes": dict(table="notes", tool="CaseVault", noun="Note", ts=("created", "updated"),
        order="id DESC", filters=("case_id",), immutable=("case_id",), search=("title", "body"),
        fields={"case_id": ("ref", "cases", True), "title": ("str", 200, True),
                "body": ("str", 20000, False), "tags": ("tags", None, False)}),
    "evidence": dict(table="evidence", tool="CaseVault", noun="Evidence", ts=("created",),
        order="id DESC", filters=("case_id",), immutable=("case_id",), search=("title", "description"),
        fields={"case_id": ("ref", "cases", True), "title": ("str", 200, True),
                "description": ("str", 5000, False), "file_ref": ("str", 500, False),
                "collected_by": ("str", 120, False), "status": ("choice", EVIDENCE_STATUS, False),
                "tags": ("tags", None, False)}),
    "entities": dict(table="entities", tool="OSINT Explorer", noun="Entity", ts=("created", "updated"),
        order="id DESC", filters=("case_id", "kind"), immutable=("case_id",), search=("label", "value", "notes"),
        fields={"case_id": ("ref", "cases", True), "kind": ("choice", ENTITY_KINDS, True),
                "label": ("str", 300, True), "value": ("str", 1000, False), "source_url": ("url", 1000, False),
                "evidence": ("str", 1000, False), "notes": ("str", 10000, False),
                "tags": ("tags", None, False), "bookmarked": ("bool", None, False)}),
    "relations": dict(table="relations", tool="OSINT Explorer", noun="Relationship", ts=("created",),
        order="id DESC", filters=("case_id",), immutable=("case_id", "src", "dst"), search=("label",),
        validate=relation_validate,
        fields={"case_id": ("ref", "cases", True), "src": ("ref", "entities", True),
                "dst": ("ref", "entities", True), "label": ("str", 120, False)}),
    "recon": dict(table="recon", tool="ReconNote", noun="Recon note", ts=("created", "updated"),
        order="updated DESC", filters=(), immutable=(), search=("target", "observations"),
        fields={"target": ("str", 300, True), "scope": ("str", 5000, True), "assessed_on": ("date", None, False),
                "authorization": ("str", 500, True), "observations": ("str", 20000, False),
                "urls": ("str", 5000, False), "dns": ("str", 10000, False), "tech": ("str", 5000, False),
                "files": ("str", 2000, False), "notes": ("str", 10000, False)}),
    "snippets": dict(table="snippets", tool="CodeVault", noun="Snippet", ts=("created", "updated"),
        order="updated DESC", filters=("language", "category"), immutable=(), search=("title", "body", "tags"),
        fields={"title": ("str", 200, True), "language": ("choice", LANGS, False),
                "body": ("str", 200000, True), "tags": ("tags", None, False),
                "category": ("str", 60, False), "favorite": ("bool", None, False)}),
    "kb_articles": dict(table="kb_articles", tool="Knowledge Base", noun="Article", ts=("created", "updated"),
        order="title COLLATE NOCASE", filters=("category",), immutable=(), search=("title", "body", "tags"),
        fields={"title": ("str", 200, True), "category": ("choice", KB_CATEGORIES, True),
                "body": ("str", 100000, True), "tags": ("tags", None, False),
                "read": ("bool", None, False), "bookmarked": ("bool", None, False)}),
    "projects": dict(table="projects", tool="Operations Board", noun="Project", ts=("created", "updated"),
        order="name COLLATE NOCASE", filters=(), immutable=(), search=("name", "description"),
        fields={"name": ("str", 120, True), "description": ("str", 2000, False)}),
    "tasks": dict(table="tasks", tool="Operations Board", noun="Task", ts=("created", "updated"),
        order="id", filters=("project_id", "status"), immutable=("project_id",), search=("title", "notes"),
        hook=task_hook,
        fields={"project_id": ("ref", "projects", True), "title": ("str", 200, True),
                "notes": ("str", 5000, False), "status": ("choice", TASK_STATUS, False),
                "priority": ("choice", PRIORITIES, False), "tags": ("tags", None, False),
                "due": ("date", None, False)}),
    "task_history": dict(table="task_history", tool="Operations Board", noun="History", readonly=True,
        order="id DESC", filters=("project_id", "task_id"), search=("event",), fields={}),
}
R["api_requests"] = dict(table="api_requests", tool="API Workbench", noun="Saved request", ts=("created", "updated"),
    order="name COLLATE NOCASE", filters=("method",), immutable=(), search=("name", "url"), prepare=sanitize_request,
    fields={"name": ("str", 120, True), "method": ("choice", HTTP_METHODS, True), "url": ("url", 2000, True),
            "headers": ("str", 10000, False), "body": ("str", 100000, False)})
R["pipelines"] = dict(table="pipelines", tool="Text Pipelines", noun="Pipeline", ts=("created", "updated"),
    order="name COLLATE NOCASE", filters=(), immutable=(), search=("name", "description"), validate=pipeline_validate,
    fields={"name": ("str", 120, True), "description": ("str", 500, False), "steps": ("str", 100000, True)})
R["kb"] = R["kb_articles"]


def nice(name):
    return name.replace("_", " ").capitalize()


def clean(spec, data, creating):
    out = {}
    for name, (kind, param, required) in spec["fields"].items():
        if name not in data:
            if creating and required:
                return None, f"{nice(name)} is required."
            continue
        v = data[name]
        if kind == "bool":
            out[name] = 1 if v in (True, 1, "1", "true") else 0
            continue
        if kind == "ref":
            try:
                v = int(v)
            except (TypeError, ValueError):
                return None, f"{nice(name)} is invalid."
            if not db.query(f"SELECT 1 FROM {param} WHERE id = ?", (v,)):
                return None, "The linked item no longer exists."
            out[name] = v
            continue
        v = "" if v is None else str(v).strip()
        if required and not v:
            return None, f"{nice(name)} is required."
        if kind in ("str", "url") and len(v) > param:
            return None, f"{nice(name)} is too long (limit {param:,} characters)."
        if kind == "choice" and v not in param:
            return None, f"{nice(name)} must be one of: {', '.join(param)}."
        if kind == "date" and v and not DATE.match(v):
            return None, f"{nice(name)} must be a date (YYYY-MM-DD)."
        if kind == "url" and v and not URL.match(v):
            return None, f"{nice(name)} must start with http:// or https://."
        if kind == "tags":
            seen = []
            for t in v.split(","):
                t = t.strip()[:40]
                if t and t.lower() not in [s.lower() for s in seen]:
                    seen.append(t)
            v = ",".join(seen[:20])
        out[name] = v
    return out, None


def spec_for(res):
    spec = R.get(res)
    if not spec:
        abort(404)
    return spec


def fetch(spec, item_id):
    rows = db.query(f"SELECT * FROM {spec['table']} WHERE id = ?", (item_id,))
    return rows[0] if rows else None


def like(q):
    return "%" + q.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"


@bp.get("/api/<res>")
def list_items(res):
    spec = spec_for(res)
    where, args = [], []
    for f in spec.get("filters", ()):
        v = request.args.get(f)
        if v not in (None, ""):
            where.append(f"{f} = ?")
            args.append(v)
    q = request.args.get("q", "").strip()
    if q:
        where.append("(" + " OR ".join(f"{c} LIKE ? ESCAPE '\\'" for c in spec["search"]) + ")")
        args += [like(q)] * len(spec["search"])
    sql = f"SELECT * FROM {spec['table']}"
    if where:
        sql += " WHERE " + " AND ".join(where)
    return jsonify(items=db.query(sql + f" ORDER BY {spec['order']} LIMIT 2000", args))


@bp.get("/api/<res>/<int:item_id>")
def get_item(res, item_id):
    item = fetch(spec_for(res), item_id)
    return jsonify(item=item) if item else err("That item no longer exists.", 404)


@bp.post("/api/<res>")
def create_item(res):
    spec = spec_for(res)
    if spec.get("readonly"):
        abort(405)
    values, error = clean(spec, request.get_json(silent=True) or {}, True)
    if not error and spec.get("validate"):
        error = spec["validate"](values, None)
    if error:
        return err(error)
    if spec.get("prepare"):
        spec["prepare"](values)
    now = db.now()
    for col in spec.get("ts", ()):
        values[col] = now
    new_id = db.run(f"INSERT INTO {spec['table']} ({', '.join(values)}) VALUES ({', '.join('?' * len(values))})",
                    list(values.values()))
    item = fetch(spec, new_id)
    if spec.get("hook"):
        spec["hook"]("create", None, item)
    db.log(spec["tool"], f"{spec['noun']} created")
    return jsonify(item=item), 201


@bp.put("/api/<res>/<int:item_id>")
def update_item(res, item_id):
    spec = spec_for(res)
    if spec.get("readonly"):
        abort(405)
    old = fetch(spec, item_id)
    if not old:
        return err("That item no longer exists.", 404)
    data = {k: v for k, v in (request.get_json(silent=True) or {}).items() if k not in spec.get("immutable", ())}
    values, error = clean(spec, data, False)
    if not error and not values:
        error = "Nothing to update."
    if not error and spec.get("validate"):
        error = spec["validate"](values, old)
    if error:
        return err(error)
    if spec.get("prepare"):
        spec["prepare"](values)
    changed = set(values)
    if "updated" in spec.get("ts", ()):
        values["updated"] = db.now()
    db.run(f"UPDATE {spec['table']} SET {', '.join(f'{c} = ?' for c in values)} WHERE id = ?",
           [*values.values(), item_id])
    item = fetch(spec, item_id)
    if spec.get("hook"):
        spec["hook"]("update", old, item)
    if not changed <= QUIET:
        db.log(spec["tool"], f"{spec['noun']} updated")
    return jsonify(item=item)


@bp.delete("/api/<res>/<int:item_id>")
def delete_item(res, item_id):
    spec = spec_for(res)
    if spec.get("readonly"):
        abort(405)
    old = fetch(spec, item_id)
    if not old:
        return err("That item no longer exists.", 404)
    db.run(f"DELETE FROM {spec['table']} WHERE id = ?", (item_id,))
    if spec.get("hook"):
        spec["hook"]("delete", old, None)
    db.log(spec["tool"], f"{spec['noun']} deleted")
    return jsonify(ok=True)


def sha256_stream(stream):
    digest, size = hashlib.sha256(), 0
    while chunk := stream.read(1024 * 1024):
        digest.update(chunk)
        size += len(chunk)
    return digest.hexdigest(), size


@bp.post("/api/evidence")
def evidence_create():
    spec = R["evidence"]
    values, error = clean(spec, request.form.to_dict(), True)
    if error:
        return err(error)
    upload = request.files.get("file")
    manual = request.form.get("sha256", "").strip().lower()
    if upload and upload.filename:
        values["sha256"], values["file_size"] = sha256_stream(upload.stream)
        values["file_name"] = upload.filename.replace("\\", "/").rsplit("/", 1)[-1][:255]
    elif manual:
        if not SHA256.match(manual):
            return err("A SHA-256 hash is 64 hexadecimal characters.")
        values["sha256"] = manual
    values["created"] = db.now()
    new_id = db.run(f"INSERT INTO evidence ({', '.join(values)}) VALUES ({', '.join('?' * len(values))})",
                    list(values.values()))
    db.log("CaseVault", "Evidence added")
    return jsonify(item=fetch(spec, new_id)), 201


@bp.post("/api/evidence/<int:item_id>/verify")
def evidence_verify(item_id):
    row = fetch(R["evidence"], item_id)
    if not row:
        return err("That evidence record no longer exists.", 404)
    upload = request.files.get("file")
    if not upload:
        return err("Choose the file to verify.")
    if not row["sha256"]:
        return err("This record has no stored SHA-256, so there is nothing to compare against.")
    actual, size = sha256_stream(upload.stream)
    match = hmac.compare_digest(actual, row["sha256"].lower())
    checked = db.now()
    db.run("UPDATE evidence SET last_check = ?, last_result = ? WHERE id = ?",
           (checked, "match" if match else "mismatch", item_id))
    db.log("CaseVault", "Evidence verified")
    return jsonify(match=match, expected=row["sha256"], actual=actual, size=size, checked=checked)


def case_bundle(case_id):
    case = fetch(R["cases"], case_id)
    if not case:
        return None
    q = lambda t: db.query(f"SELECT * FROM {t} WHERE case_id = ? ORDER BY id", (case_id,))
    return dict(case=case, notes=q("notes"), evidence=q("evidence"), entities=q("entities"), relations=q("relations"))


def md_cell(v):
    return str(v if v is not None else "").replace("|", "\\|").replace("\n", " ")


def case_markdown(d):
    c = d["case"]
    kind = "Research case" if c["kind"] == "research" else "Case"
    lines = [f"# {c['title']}", "", f"- Type: {kind}", f"- Status: {c['status']}",
             f"- Investigator: {c['investigator'] or 'Not set'}", f"- Tags: {c['tags'] or 'None'}",
             f"- Created: {c['created']}", f"- Updated: {c['updated']}", "",
             "## Description and scope", "", c["description"] or "None recorded.", ""]
    if d["entities"]:
        names = {e["id"]: e["label"] for e in d["entities"]}
        lines += ["## Entities", "", "| Type | Label | Value | Source | Tags |", "|---|---|---|---|---|"]
        lines += [f"| {md_cell(e['kind'])} | {md_cell(e['label'])} | {md_cell(e['value'])} | "
                  f"{md_cell(e['source_url'])} | {md_cell(e['tags'])} |" for e in d["entities"]]
        if d["relations"]:
            lines += ["", "## Relationships", ""]
            lines += [f"- {names.get(r['src'], '?')} - {r['label'] or 'related to'} - {names.get(r['dst'], '?')}"
                      for r in d["relations"]]
        lines.append("")
    if d["evidence"]:
        lines += ["## Evidence", "", "| Title | File | Size (bytes) | SHA-256 | Status | Integrity |", "|---|---|---|---|---|---|"]
        for e in d["evidence"]:
            check = f"{e['last_result']} on {e['last_check']}" if e["last_result"] else "not checked"
            lines.append(f"| {md_cell(e['title'])} | {md_cell(e['file_name'] or e['file_ref'])} | {e['file_size']} | "
                         f"{e['sha256'] or 'none'} | {e['status']} | {check} |")
        lines.append("")
    if d["notes"]:
        lines += ["## Notes", ""]
        for n in d["notes"]:
            lines += [f"### {n['title']}", f"*{n['created']}*", "", n["body"] or "", ""]
    lines += ["---", "Exported from D76 CyberOps. Contents were entered by the user; D76 does not verify them."]
    return "\n".join(lines)


@bp.get("/api/cases/<int:case_id>/export")
def case_export(case_id):
    data = case_bundle(case_id)
    if not data:
        return err("That case no longer exists.", 404)
    fmt = request.args.get("format", "md")
    if fmt == "json":
        body, mime, ext = json.dumps(data, indent=2), "application/json", "json"
    elif fmt == "html":
        body = render_template("case_report.html", generated=db.now(), **data)
        mime, ext = "text/html", "html"
    elif fmt == "md":
        body, mime, ext = case_markdown(data), "text/markdown", "md"
    else:
        return err("Unknown export format.")
    slug = re.sub(r"[^a-z0-9]+", "-", data["case"]["title"].lower()).strip("-")[:40] or "case"
    db.log("CaseVault" if data["case"]["kind"] == "case" else "OSINT Explorer", "Case exported")
    return Response(body, mimetype=mime, headers={"Content-Disposition": f'attachment; filename="{slug}.{ext}"'})
