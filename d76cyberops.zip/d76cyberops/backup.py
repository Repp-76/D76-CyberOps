"""Incremental local backups with checksums. Originals are only ever read; nothing in the source is changed or deleted."""
import fnmatch
import hashlib
import json
import os
import re
import shutil
from datetime import datetime, timezone

MAX_FILES = 20000
MAX_BYTES = 2 * 1024 ** 3
SNAP_RE = re.compile(r"^\d{8}T\d{6}Z$")
SYSTEM_DIRS = {"/", "/proc", "/sys", "/dev", "/boot", "/etc", "/bin", "/sbin", "/usr", "/lib", "/lib64"}


class BackupError(ValueError):
    pass


def real(path, must_exist=True, kind="Path"):
    if not isinstance(path, str) or not path.strip() or "\x00" in path:
        raise BackupError(f"{kind} is empty or invalid.")
    path = os.path.expanduser(path.strip())
    if not os.path.isabs(path):
        raise BackupError(f"{kind} must be an absolute path (it should start from the root, for example /home/me/docs).")
    path = os.path.realpath(path)
    if must_exist and not os.path.exists(path):
        raise BackupError(f"{kind} does not exist: {path}")
    return path


def inside(child, parent):
    return os.path.commonpath([child, parent]) == parent


def safe_name(name):
    n = re.sub(r"[^A-Za-z0-9._-]+", "_", (name or "").strip()).strip("._")[:60]
    if not n:
        raise BackupError("Give the backup a name (letters, digits, dots, dashes).")
    return n


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        while chunk := fh.read(1024 * 1024):
            h.update(chunk)
    return h.hexdigest()


def copy_hashed(src, dst):
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    h = hashlib.sha256()
    with open(src, "rb") as a, open(dst, "wb") as b:
        while chunk := a.read(1024 * 1024):
            h.update(chunk)
            b.write(chunk)
    shutil.copystat(src, dst)
    return h.hexdigest()


def scan(source, excludes=()):
    files, skipped, total = {}, [], 0
    if os.path.isfile(source):
        walker = [(os.path.dirname(source), [], [os.path.basename(source)])]
        base = os.path.dirname(source)
    else:
        walker, base = os.walk(source, followlinks=False), source
    for root, dirs, names in walker:
        dirs[:] = [d for d in dirs if not any(fnmatch.fnmatch(d, pat) for pat in excludes)]
        for n in names:
            p = os.path.join(root, n)
            rel = os.path.relpath(p, base).replace(os.sep, "/")
            if any(fnmatch.fnmatch(n, pat) or fnmatch.fnmatch(rel, pat) for pat in excludes):
                continue
            if os.path.islink(p) or not os.path.isfile(p):
                skipped.append(rel)
                continue
            try:
                st = os.stat(p)
            except OSError:
                skipped.append(rel)
                continue
            total += st.st_size
            if len(files) >= MAX_FILES or total > MAX_BYTES:
                raise BackupError(f"The source is larger than the limit of {MAX_FILES:,} files or {MAX_BYTES // 1024 ** 3} GB. Back up a smaller folder or add exclude patterns.")
            files[rel] = {"path": p, "size": st.st_size, "mtime_ns": st.st_mtime_ns}
    return files, skipped


def set_dir(dest, name):
    return os.path.join(dest, safe_name(name))


def snapshots(sdir):
    if not os.path.isdir(sdir):
        return []
    return sorted(d for d in os.listdir(sdir) if SNAP_RE.match(d) and os.path.isfile(os.path.join(sdir, d, "manifest.json")))


def load_manifest(sdir, snap):
    if not SNAP_RE.match(snap):
        raise BackupError("Invalid snapshot name.")
    try:
        with open(os.path.join(sdir, snap, "manifest.json")) as fh:
            return json.load(fh)
    except (OSError, ValueError):
        raise BackupError(f"The manifest for {snap} is missing or damaged.") from None


def diff(files, manifest):
    old = manifest["files"] if manifest else {}
    new, changed, unchanged = [], [], []
    for rel, f in files.items():
        o = old.get(rel)
        if not o:
            new.append(rel)
        elif o["size"] == f["size"] and o.get("mtime_ns") == f["mtime_ns"]:
            unchanged.append(rel)
        elif o["size"] == f["size"] and sha256_file(f["path"]) == o["sha256"]:
            unchanged.append(rel)
        else:
            changed.append(rel)
    deleted = [r for r in old if r not in files]
    return {"new": sorted(new), "changed": sorted(changed), "deleted": sorted(deleted), "unchanged": len(unchanged)}


def preview(source, dest, name, excludes=()):
    source = real(source, kind="Source")
    files, skipped = scan(source, excludes)
    sdir = set_dir(real(dest, False, "Destination"), name)
    snaps = snapshots(sdir)
    d = diff(files, load_manifest(sdir, snaps[-1]) if snaps else None)
    return {"files": len(files), "bytes": sum(f["size"] for f in files.values()), "skipped": skipped[:50], "skipped_count": len(skipped), "previous": snaps[-1] if snaps else None,
            **{k: (v[:300] if isinstance(v, list) else v) for k, v in d.items()}, "counts": {"new": len(d["new"]), "changed": len(d["changed"]), "deleted": len(d["deleted"]), "unchanged": d["unchanged"]}}


def check_paths(source, dest):
    source, dest = real(source, kind="Source"), real(dest, False, "Destination")
    if dest in SYSTEM_DIRS or any(dest == d for d in SYSTEM_DIRS):
        raise BackupError("That destination is a system folder. Choose a folder you own.")
    if inside(dest, source) or inside(source, dest) and os.path.isdir(source):
        raise BackupError("The source and destination must not contain each other, or the backup would copy itself.")
    return source, dest


def run_backup(source, dest, name, excludes=()):
    source, dest = check_paths(source, dest)
    files, skipped = scan(source, excludes)
    if not files:
        raise BackupError("The source contains no files to back up.")
    sdir = set_dir(dest, name)
    snaps = snapshots(sdir)
    prev = load_manifest(sdir, snaps[-1]) if snaps else None
    d = diff(files, prev)
    if prev and not (d["new"] or d["changed"] or d["deleted"]):
        return {"created": False, "message": "Nothing changed since the last backup, so no new snapshot was made.", "snapshot": snaps[-1], "counts": {"new": 0, "changed": 0, "deleted": 0, "unchanged": d["unchanged"]}}
    snap = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    while snap in snaps:
        snap = datetime.fromtimestamp(datetime.strptime(snap, "%Y%m%dT%H%M%SZ").replace(tzinfo=timezone.utc).timestamp() + 1, timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    snap_dir = os.path.join(sdir, snap)
    manifest_files, to_copy = {}, set(d["new"]) | set(d["changed"])
    try:
        for rel, f in files.items():
            if rel in to_copy:
                digest = copy_hashed(f["path"], os.path.join(snap_dir, "files", *rel.split("/")))
                manifest_files[rel] = {"size": f["size"], "mtime_ns": f["mtime_ns"], "sha256": digest, "stored_in": snap}
            else:
                manifest_files[rel] = dict(prev["files"][rel], mtime_ns=f["mtime_ns"])
        manifest = {"version": 1, "name": safe_name(name), "source": source, "created": datetime.now(timezone.utc).isoformat(timespec="seconds"), "previous": snaps[-1] if snaps else None,
                    "files": manifest_files, "deleted": d["deleted"]}
        tmp = os.path.join(snap_dir, "manifest.json.tmp")
        with open(tmp, "w") as fh:
            json.dump(manifest, fh)
        os.replace(tmp, os.path.join(snap_dir, "manifest.json"))
    except Exception:
        shutil.rmtree(snap_dir, ignore_errors=True)  # remove only the half-written snapshot we just created
        raise
    return {"created": True, "snapshot": snap, "snapshot_dir": snap_dir, "files": len(files), "bytes": sum(f["size"] for f in files.values()), "skipped_count": len(skipped),
            "counts": {"new": len(d["new"]), "changed": len(d["changed"]), "deleted": len(d["deleted"]), "unchanged": d["unchanged"]}, "set_dir": sdir}


def stored_path(sdir, entry, rel):
    return os.path.join(sdir, entry["stored_in"], "files", *rel.split("/"))


def verify(sdir, snap):
    m = load_manifest(sdir, snap)
    missing, bad, checked = [], [], 0
    for rel, e in m["files"].items():
        p = stored_path(sdir, e, rel)
        checked += 1
        if not os.path.isfile(p):
            missing.append(rel)
        elif os.path.getsize(p) != e["size"] or sha256_file(p) != e["sha256"]:
            bad.append(rel)
    return {"checked": checked, "ok": not missing and not bad, "missing": missing[:200], "corrupted": bad[:200]}


def safe_rel(rel):
    parts = rel.split("/")
    if rel.startswith("/") or any(p in ("", "..", ".") for p in parts) or "\\" in rel or "\x00" in rel:
        raise BackupError(f"The backup lists an unsafe path and restore was stopped: {rel[:80]}")
    return parts


def restore(sdir, snap, target, overwrite=False):
    m = load_manifest(sdir, snap)
    sdir = os.path.realpath(sdir)
    target = real(target, False, "Restore folder")
    if inside(target, sdir) or inside(sdir, target) and os.path.isdir(target):
        raise BackupError("Restore into a folder that is separate from the backup itself.")
    if os.path.exists(target) and not os.path.isdir(target):
        raise BackupError("The restore location exists and is not a folder.")
    existing = [r for r in m["files"] if os.path.exists(os.path.join(target, *safe_rel(r)))]
    different = [r for r in existing if sha256_file(os.path.join(target, *r.split("/"))) != m["files"][r]["sha256"]]
    if different and not overwrite:
        raise BackupError(f"{len(different)} file(s) already exist in that folder with different contents. Choose an empty folder, or confirm that they may be overwritten.")
    restored = skipped = 0
    failed = []
    for rel, e in m["files"].items():
        src, dst = stored_path(sdir, e, rel), os.path.join(target, *safe_rel(rel))
        if os.path.exists(dst) and sha256_file(dst) == e["sha256"]:
            skipped += 1
            continue
        if not os.path.isfile(src):
            failed.append(f"{rel}: missing from the backup")
            continue
        if copy_hashed(src, dst) != e["sha256"]:
            failed.append(f"{rel}: checksum mismatch after copying")
            continue
        restored += 1
    return {"restored": restored, "already_identical": skipped, "failed": failed, "overwrote": len(different) if overwrite else 0, "target": target}


def removable(sdir, snap):
    others = [s for s in snapshots(sdir) if s != snap]
    for o in others:
        if any(e["stored_in"] == snap for e in load_manifest(sdir, o)["files"].values()):
            return False
    return True


def delete_snapshot(sdir, snap):
    if not SNAP_RE.match(snap):
        raise BackupError("Invalid snapshot name.")
    if not removable(sdir, snap):
        raise BackupError("Later backups reuse files stored in this snapshot, so it cannot be deleted without breaking them. Delete the newer snapshots first.")
    path = os.path.realpath(os.path.join(sdir, snap))
    if os.path.dirname(path) != os.path.realpath(sdir):
        raise BackupError("Refusing to delete outside the backup folder.")
    shutil.rmtree(path)


def browse(path):
    path = real(path or os.path.expanduser("~"), kind="Folder")
    if not os.path.isdir(path):
        raise BackupError("That is not a folder.")
    try:
        dirs = sorted(d for d in os.listdir(path) if os.path.isdir(os.path.join(path, d)) and not d.startswith("."))[:300]
    except OSError:
        raise BackupError("That folder cannot be read.") from None
    return {"path": path, "parent": os.path.dirname(path) if path != os.path.dirname(path) else None, "folders": dirs}
