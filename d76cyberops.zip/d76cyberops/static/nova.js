(() => {
  const st = $('#nv-st'), out = $('#nv-out'), copyBtn = $('#nv-copy');
  let raw = '', status = null;

  async function loadStatus() {
    status = await api('/api/nova/status');
    const s = status;
    fill($('#nv-status'), s.configured
      ? h('p', { class: 'ok' }, `Ready: ${s.provider} model ${s.model} via ${s.host}.`, s.local ? ' Running on this machine, so nothing leaves it.' : ` Text you send goes to ${s.host}.`)
      : h('div', {}, h('p', { class: 'warn' }, 'Not configured yet.'), s.problems ? h('ul', { class: 'plain' }, s.problems.map((p) => h('li', {}, p))) : h('p', {}, s.problem)),
      s.key_source ? h('p', { class: 'muted small' }, `Key source: ${s.key_source}`) : null, s.key_file_warning ? findingsList([{ severity: 'warn', message: s.key_file_warning }]) : null);
    fill($('#nv-task'), Object.entries(s.tasks).map(([k, l]) => h('option', { value: k }, l)));
    const c = s.stored || {};
    $('#nv-provider').value = c.provider || s.provider || 'anthropic'; $('#nv-model').value = c.model || ''; $('#nv-base').value = c.base_url || ''; $('#nv-max').value = c.max_tokens || 1500;
  }

  $('#nv-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    try { await api('/api/nova/config', { method: 'PUT', json: { provider: $('#nv-provider').value, model: $('#nv-model').value, base_url: $('#nv-base').value, max_tokens: Number($('#nv-max').value) } }); toast('Settings saved'); loadStatus(); } catch (err) { toast(err.message, true); }
  });
  $('#nv-file').addEventListener('change', async (e) => {
    const f = e.target.files[0];
    if (f) { if (f.size > 100000) toast('That file is over 100 KB and was not loaded.', true); else $('#nv-in').value = await f.text(); }
    e.target.value = '';
  });
  $('#nv-run').addEventListener('click', () => runWith($('#nv-run'), st, 'Waiting for the model...', async () => {
    const r = await api('/api/nova/run', { method: 'POST', json: { task: $('#nv-task').value, text: $('#nv-in').value, mask: $('#nv-mask').checked } });
    raw = r.text;
    fill(out, renderMarkdown(raw));
    copyBtn.disabled = false;
    setStatus(st, `${r.model} via ${r.host}.` + (r.masked ? ` ${r.masked} secret(s) were masked before sending.` : ''), true);
  }));
  copyBtn.addEventListener('click', () => copyText(raw));

  $('#nv-scaf').addEventListener('click', () => runWith($('#nv-scaf'), $('#nv-sst'), 'Waiting for the model...', async () => {
    const r = await api('/api/nova/scaffold', { method: 'POST', json: { description: $('#nv-desc').value } });
    setStatus($('#nv-sst'), `${r.files.length} file(s) proposed. Nothing was written to disk. Review them first.`, true);
    fill($('#nv-files'), r.files.map((f) => h('details', { class: 'block' }, h('summary', {}, h('code', {}, f.path)), h('pre', { class: 'json' }, f.content),
      h('div', { class: 'actions' }, h('button', { class: 'btn sm', type: 'button', onclick: () => copyText(f.content) }, icon('copy'), 'Copy'), h('button', { class: 'btn sm', type: 'button', onclick: () => download(f.path.split('/').pop(), f.content, 'text/plain') }, icon('download'), 'Download')))));
  }));
  loadStatus().catch((e) => setStatus(st, e.message, false));
})();
