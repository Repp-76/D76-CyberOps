const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
const csrf = $('meta[name=csrf]').content;

async function api(url, opts = {}) {
  const o = { method: 'GET', headers: {}, ...opts };
  if (o.method !== 'GET') o.headers['X-CSRF-Token'] = csrf;
  if (o.json) {
    o.headers['Content-Type'] = 'application/json';
    o.body = JSON.stringify(o.json);
  }
  let res;
  try {
    res = await fetch(url, o);
  } catch {
    throw new Error('Could not reach the local D76 server. Check that it is still running.');
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Request failed (${res.status}).`);
  return data;
}

function toast(msg, bad = false) {
  const el = document.createElement('div');
  el.className = 'toast' + (bad ? ' bad' : '');
  el.textContent = msg;
  $('#toasts').append(el);
  setTimeout(() => el.remove(), 3200);
}

function setStatus(el, msg, ok = true) {
  el.textContent = msg;
  el.className = 'status ' + (msg ? (ok ? 'ok' : 'bad') : '');
}

function copyText(text) {
  navigator.clipboard.writeText(text).then(
    () => toast('Copied to clipboard'),
    () => toast('Copy failed. Your browser blocked clipboard access.', true)
  );
}

function download(name, text, type) {
  const url = URL.createObjectURL(new Blob([text], { type }));
  const a = Object.assign(document.createElement('a'), { href: url, download: name });
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

// label / value row with a copy button
function kvRow(label, value) {
  const row = document.createElement('div');
  row.className = 'kv';
  const k = document.createElement('span');
  k.textContent = label;
  const v = document.createElement('code');
  v.textContent = value;
  const b = document.createElement('button');
  b.type = 'button';
  b.className = 'btn sm';
  b.textContent = 'Copy';
  b.setAttribute('aria-label', `Copy ${label}`);
  b.addEventListener('click', () => copyText(value));
  row.append(k, v, b);
  return row;
}

(() => {
  const open = (on) => document.body.classList.toggle('nav-open', on);
  $('#navBtn').addEventListener('click', () => open(true));
  $('#navClose').addEventListener('click', () => open(false));
  $('#scrim').addEventListener('click', () => open(false));
  document.addEventListener('keydown', (e) => e.key === 'Escape' && open(false));
  document.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-copy-from]');
    if (btn) copyText($('#' + btn.dataset.copyFrom).value);
  });
})();

/* ---- shared helpers for the data tools (phase 2) ---- */
const SVG_NS = 'http://www.w3.org/2000/svg';

function h(tag, props, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(props || {})) {
    if (v == null || v === false) continue;
    if (k === 'class') e.className = v;
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else e.setAttribute(k, v === true ? '' : v);
  }
  e.append(...kids.flat(Infinity).filter((k) => k != null && k !== false));
  return e;
}

function s(tag, props, ...kids) {
  const e = document.createElementNS(SVG_NS, tag);
  for (const [k, v] of Object.entries(props || {})) {
    if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else if (v != null) e.setAttribute(k, v);
  }
  e.append(...kids.flat(Infinity).filter((k) => k != null && k !== false));
  return e;
}

// Replace an element's children; unlike replaceChildren it flattens arrays and skips null/false.
function fill(parent, ...kids) {
  parent.replaceChildren(...kids.flat(Infinity).filter((k) => k != null && k !== false));
}

const icon = (name) => s('svg', { class: 'ic', 'aria-hidden': 'true', focusable: 'false' }, s('use', { href: '#i-' + name }));
const fmtDate = (iso) => (iso ? iso.slice(0, 10) : '');
const tagChips = (str) => (str ? str.split(',').filter(Boolean).map((t) => h('span', { class: 'tag' }, t)) : []);
const debounce = (fn, ms = 200) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };
const hashParams = () => new URLSearchParams(location.hash.slice(1));
const emptyState = (title, text, ...actions) =>
  h('div', { class: 'empty' }, h('h2', {}, title), h('p', {}, text), actions.length ? h('div', { class: 'actions center' }, actions) : null);

const R = {
  list: (res, params = {}) =>
    api(`/api/${res}?` + new URLSearchParams(Object.entries(params).filter(([, v]) => v !== '' && v != null))),
  get: (res, id) => api(`/api/${res}/${id}`),
  create: (res, json) => api(`/api/${res}`, { method: 'POST', json }),
  update: (res, id, json) => api(`/api/${res}/${id}`, { method: 'PUT', json }),
  remove: (res, id) => api(`/api/${res}/${id}`, { method: 'DELETE' }),
};

function toCsv(rows) {
  const cell = (v) => {
    v = String(v ?? '');
    if (/^[=+\-@\t\r]/.test(v)) v = "'" + v; // stop spreadsheet formula injection
    return `"${v.replace(/"/g, '""')}"`;
  };
  return rows.map((r) => r.map(cell).join(',')).join('\n');
}

// Modal form. `save(values)` runs on submit; the dialog stays open and shows the error if it throws.
function formDialog({ title, fields, values = {}, submit = 'Save', save }) {
  return new Promise((resolve) => {
    const err = h('p', { class: 'status bad', role: 'alert' });
    const inputs = {};
    const rows = fields.map((f) => {
      const id = 'fd-' + f.name;
      let input;
      if (f.type === 'textarea') input = h('textarea', { id, rows: f.rows || 5, spellcheck: 'false' });
      else if (f.type === 'select') input = h('select', { id }, f.options.map(([v, l]) => h('option', { value: v }, l)));
      else input = h('input', { id, type: f.type || 'text', autocomplete: 'off' });
      const val = values[f.name] ?? f.default ?? '';
      if (f.type === 'checkbox') input.checked = Number(val) === 1 || val === true;
      else if (f.type !== 'file' && !(f.type === 'select' && val === '')) input.value = val; // empty select keeps its first option
      if (f.required) input.required = true;
      if (f.max) input.maxLength = f.max;
      inputs[f.name] = input;
      if (f.type === 'checkbox') return h('div', { class: 'check' }, input, h('label', { for: id }, f.label));
      return h('div', { class: 'field' }, h('label', { for: id }, f.label), input, f.hint && h('small', { class: 'muted' }, f.hint));
    });
    const dlg = h('dialog', { class: 'dlg', 'aria-label': title });
    const submitBtn = h('button', { class: 'btn primary', type: 'submit' }, submit);
    const form = h('form', {}, h('h2', {}, title), rows, err,
      h('div', { class: 'actions' }, submitBtn, h('button', { class: 'btn', type: 'button', onclick: () => dlg.close() }, 'Cancel')));
    dlg.append(form);
    let result = null;
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const out = {};
      for (const f of fields) {
        const i = inputs[f.name];
        out[f.name] = f.type === 'checkbox' ? (i.checked ? 1 : 0) : f.type === 'file' ? i.files[0] || null : i.value.trim();
      }
      submitBtn.disabled = true;
      err.textContent = '';
      try {
        result = (await save(out)) ?? true;
        dlg.close();
      } catch (ex) {
        err.textContent = ex.message;
        submitBtn.disabled = false;
      }
    });
    dlg.addEventListener('close', () => { dlg.remove(); resolve(result); });
    document.body.append(dlg);
    dlg.showModal();
    const first = dlg.querySelector('input:not([type=checkbox]),textarea,select');
    if (first) first.focus();
  });
}

// Small, safe Markdown renderer: builds DOM nodes, never injects HTML. Links must be http(s).
function renderMarkdown(src) {
  const root = document.createDocumentFragment();
  const lines = src.replace(/\r/g, '').split('\n');
  const inline = (text) => {
    const nodes = [];
    const re = /(`[^`]+`)|(\*\*[^*]+\*\*)|(\[[^\]]+\]\((https?:\/\/[^)\s]+)\))/g;
    let last = 0, m;
    while ((m = re.exec(text))) {
      if (m.index > last) nodes.push(text.slice(last, m.index));
      if (m[1]) nodes.push(h('code', {}, m[1].slice(1, -1)));
      else if (m[2]) nodes.push(h('strong', {}, m[2].slice(2, -2)));
      else nodes.push(h('a', { href: m[4], target: '_blank', rel: 'noopener noreferrer' }, m[3].slice(1, m[3].indexOf(']'))));
      last = re.lastIndex;
    }
    if (last < text.length) nodes.push(text.slice(last));
    return nodes;
  };
  const isBullet = (l) => /^\s*[-*]\s+/.test(l), isNum = (l) => /^\s*\d+\.\s+/.test(l), isRow = (l) => /^\s*\|.*\|\s*$/.test(l);
  const cells = (l) => l.trim().replace(/^\||\|$/g, '').split('|').map((c) => c.trim());
  let i = 0;
  while (i < lines.length) {
    const line = lines[i];
    let m;
    if (/^```/.test(line)) {
      const buf = [];
      i++;
      while (i < lines.length && !/^```/.test(lines[i])) buf.push(lines[i++]);
      i++;
      root.append(h('pre', { class: 'out' }, h('code', {}, buf.join('\n'))));
    } else if ((m = line.match(/^(#{1,3})\s+(.*)/))) {
      root.append(h('h' + (m[1].length + 1), {}, inline(m[2])));
      i++;
    } else if (isRow(line)) {
      const rows = [];
      while (i < lines.length && isRow(lines[i])) rows.push(lines[i++]);
      const body = rows.filter((r) => !/^\s*\|[\s:|-]+\|\s*$/.test(r)).map(cells);
      const head = body.shift() || [];
      root.append(h('div', { class: 'tablewrap' }, h('table', {},
        h('thead', {}, h('tr', {}, head.map((c) => h('th', { scope: 'col' }, inline(c))))),
        h('tbody', {}, body.map((r) => h('tr', {}, r.map((c) => h('td', {}, inline(c)))))))));
    } else if (isBullet(line) || isNum(line)) {
      const test = isBullet(line) ? isBullet : isNum;
      const list = h(isBullet(line) ? 'ul' : 'ol');
      while (i < lines.length && test(lines[i])) list.append(h('li', {}, inline(lines[i++].replace(/^\s*(?:[-*]|\d+\.)\s+/, ''))));
      root.append(list);
    } else if (!line.trim()) {
      i++;
    } else {
      const para = [];
      while (i < lines.length && lines[i].trim() && !/^(```|#{1,3}\s)/.test(lines[i]) && !isBullet(lines[i]) && !isNum(lines[i]) && !isRow(lines[i])) para.push(lines[i++]);
      root.append(h('p', {}, inline(para.join(' '))));
    }
  }
  return root;
}
