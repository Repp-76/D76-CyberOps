$('#clearActivity').addEventListener('click', async () => {
  if (!confirm('Clear the whole activity log? This cannot be undone.')) return;
  try {
    await api('/api/reset', { method: 'POST', json: { confirm: 'RESET', scope: 'activity' } });
    location.reload();
  } catch (e) {
    toast(e.message, true);
  }
});
