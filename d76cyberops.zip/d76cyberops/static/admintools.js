(() => {
  tabs($('#at-tabs'), (k) => { $('#at-cron').hidden = k !== 'cron'; $('#at-perm').hidden = k !== 'perm'; });
  const EXAMPLES = [['Every 15 minutes in office hours', '*/15 9-17 * * mon-fri'], ['Nightly at 02:30', '30 2 * * *'], ['First of the month', '0 6 1 * *'], ['Weekdays at 22:00', '0 22 * * 1-5'], ['Hourly', '@hourly']];
  fill($('#cr-examples'), EXAMPLES.map(([l, e]) => h('button', { class: 'btn sm', type: 'button', onclick: () => { $('#cr-in').value = e; go(); } }, l)));

  const cst = $('#cr-st'), cout = $('#cr-out');
  const go = () => runWith($('#cr-run'), cst, 'Reading...', async () => {
    const r = await api('/api/admin/cron', { method: 'POST', json: { expr: $('#cr-in').value, count: Number($('#cr-n').value) } });
    setStatus(cst, '');
    fill(cout, h('p', { class: 'cron-sum' }, h('b', {}, r.summary)),
      dataTable(['Minute', 'Hour', 'Day of month', 'Month', 'Day of week'], [Object.values(r.fields).map((v) => h('code', {}, v))]),
      h('h3', {}, `Next ${r.next_runs.length} runs from ${r.from}`),
      r.next_runs.length ? h('ol', {}, r.next_runs.map((t) => h('li', {}, h('code', {}, t)))) : h('p', { class: 'muted' }, 'No run found in the next five years.'),
      r.notes.map((n) => h('p', { class: 'muted small' }, n)));
  });
  $('#cr-run').addEventListener('click', go);
  $('#cr-in').addEventListener('keydown', (e) => e.key === 'Enter' && go());

  // permissions
  const FORMS = [
    { action: 'octal', label: 'From octal (755, 4755)', fields: [['value', 'Octal mode', '755']] },
    { action: 'symbolic', label: 'From symbolic (rwxr-xr-x)', fields: [['value', 'Symbolic mode', 'rwxr-xr-x']] },
    { action: 'chmod', label: 'Apply a chmod expression', fields: [['start', 'Starting octal mode', '644'], ['value', 'Expression', 'u+x,go-r']] },
    { action: 'umask', label: 'What does a umask give?', fields: [['value', 'umask', '022']] },
  ];
  const form = $('#pm-form'), pst = $('#pm-st'), pout = $('#pm-out');
  fill(form, FORMS.map((f) => h('fieldset', {}, h('legend', {}, f.label),
    f.fields.map(([n, l, v]) => h('div', {}, h('label', { for: `pm-${f.action}-${n}` }, l), h('input', { id: `pm-${f.action}-${n}`, class: 'mono', value: v, autocomplete: 'off' }))),
    h('div', { class: 'actions' }, h('button', { class: 'btn', type: 'button', onclick: () => calc(f) }, 'Calculate')))));
  async function calc(f) {
    const body = { action: f.action };
    f.fields.forEach(([n]) => { body[n] = $(`#pm-${f.action}-${n}`).value; });
    try {
      const r = await api('/api/admin/permissions', { method: 'POST', json: body });
      setStatus(pst, '');
      if (f.action === 'umask') fill(pout, kvList([['umask', r.umask], ['New files', `${r.files}  ${r.files_symbolic}`], ['New directories', `${r.directories}  ${r.directories_symbolic}`]]));
      else fill(pout, h('p', { class: 'perm-big' }, h('code', {}, r.octal), '  ', h('code', {}, r.symbolic)),
        dataTable(['', 'Read', 'Write', 'Execute'], r.table.map((t) => [h('b', {}, t.who), ...[t.read, t.write, t.execute].map((b) => h('span', { class: b ? 'ok' : 'muted' }, b ? 'Yes' : 'No'))])),
        r.notes.length ? findingsList(r.notes.map((m) => ({ severity: 'warn', message: m }))) : null);
    } catch (e) { fill(pout); setStatus(pst, e.message, false); }
  }
})();
