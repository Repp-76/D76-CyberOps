(() => {
  const E = PipeEngine;
  const inEl = $('#tp-in'), outEl = $('#tp-out'), stepsEl = $('#tp-steps'), st = $('#tp-st');
  const savedSel = $('#tp-saved'), delBtn = $('#tp-del');
  let steps = [], saved = [], dirty = false;

  fill($('#tp-add'), Object.entries(E.STEPS).map(([k, d]) => h('option', { value: k }, d.label)));

  function defaults(type) {
    const p = {};
    E.STEPS[type].params.forEach((f) => { p[f.name] = f.type === 'checkbox' ? false : f.type === 'select' ? f.options[0][0] : f.default ?? ''; });
    return p;
  }

  function run() {
    $('#tp-inmeta').textContent = inEl.value ? `${inEl.value.split(/\r?\n/).length.toLocaleString()} lines` : '';
    try {
      const r = E.run(inEl.value, steps);
      outEl.value = r.text;
      $('#tp-outmeta').textContent = `${r.lines.toLocaleString()} lines`;
      setStatus(st, '');
      $$('.after', stepsEl).forEach((el, i) => { el.textContent = `${r.trace[i] ?? 0} lines after this step`; });
    } catch (e) { setStatus(st, e.message, false); }
  }

  function field(i, f, value) {
    const id = `tp-${i}-${f.name}`;
    let input;
    if (f.type === 'select') { input = h('select', { id }, f.options.map(([v, l]) => h('option', { value: v }, l))); input.value = value; }
    else if (f.type === 'checkbox') { input = h('input', { id, type: 'checkbox' }); input.checked = !!value; }
    else { input = h('input', { id, type: f.type === 'number' ? 'number' : 'text', placeholder: f.label, 'aria-label': f.label, autocomplete: 'off', spellcheck: 'false', class: 'mono' }); input.value = value; }
    input.addEventListener('input', () => { steps[i].params[f.name] = f.type === 'checkbox' ? input.checked : input.value; dirty = true; run(); });
    return f.type === 'checkbox' ? h('label', { class: 'check' }, input, f.label) : input;
  }

  function paint() {
    fill(stepsEl, steps.length ? steps.map((s, i) => {
      const def = E.STEPS[s.type];
      return h('li', {}, h('div', { class: 'head' }, def.label, h('span', { class: 'sp' },
        h('button', { class: 'btn sm', type: 'button', 'aria-label': 'Move up', disabled: i === 0, onclick: () => move(i, -1) }, 'Up'),
        h('button', { class: 'btn sm', type: 'button', 'aria-label': 'Move down', disabled: i === steps.length - 1, onclick: () => move(i, 1) }, 'Down'),
        h('button', { class: 'btn sm danger', type: 'button', 'aria-label': 'Remove step', onclick: () => { steps.splice(i, 1); dirty = true; paint(); } }, 'Remove'))),
        def.params.length ? h('div', { class: 'prm' }, def.params.map((f) => field(i, f, s.params[f.name]))) : null, h('div', { class: 'after' }));
    }) : h('li', { class: 'muted' }, 'No steps yet. Add one below.'));
    run();
  }
  const move = (i, d) => { [steps[i], steps[i + d]] = [steps[i + d], steps[i]]; dirty = true; paint(); };

  $('#tp-addbtn').addEventListener('click', () => { const type = $('#tp-add').value; steps.push({ type, params: defaults(type) }); dirty = true; paint(); });
  inEl.addEventListener('input', debounce(run, 150));

  async function loadSaved(select) {
    saved = (await R.list('pipelines')).items;
    fill(savedSel, h('option', { value: '' }, 'Unsaved pipeline'), saved.map((p) => h('option', { value: p.id }, p.name)));
    savedSel.value = select || '';
    delBtn.disabled = !savedSel.value;
  }
  savedSel.addEventListener('change', () => {
    const p = saved.find((x) => String(x.id) === savedSel.value);
    delBtn.disabled = !p;
    if (!p) return;
    try { steps = JSON.parse(p.steps); } catch { steps = []; }
    dirty = false;
    history.replaceState(null, '', '#pipeline=' + p.id);
    paint();
  });
  $('#tp-save').addEventListener('click', () => {
    if (!steps.length) return toast('Add at least one step first.', true);
    const cur = saved.find((x) => String(x.id) === savedSel.value);
    formDialog({ title: cur ? 'Update pipeline' : 'Save pipeline', values: cur || {}, submit: 'Save',
      fields: [{ name: 'name', label: 'Name', required: true, max: 120 }, { name: 'description', label: 'Description', max: 500 }],
      save: async (v) => (cur ? await R.update('pipelines', cur.id, { ...v, steps: JSON.stringify(steps) }) : await R.create('pipelines', { ...v, steps: JSON.stringify(steps) })).item })
      .then(async (item) => { if (item) { dirty = false; await loadSaved(item.id); } });
  });
  delBtn.addEventListener('click', async () => {
    const cur = saved.find((x) => String(x.id) === savedSel.value);
    if (!cur || !confirm(`Delete the pipeline "${cur.name}"?`)) return;
    try { await R.remove('pipelines', cur.id); await loadSaved(); } catch (e) { toast(e.message, true); }
  });
  $('#tp-dl').addEventListener('click', () => (outEl.value ? download('output.txt', outEl.value, 'text/plain') : toast('There is no output yet.', true)));
  window.addEventListener('beforeunload', (e) => { if (dirty && steps.length) e.preventDefault(); });

  paint();
  loadSaved().then(() => { const id = hashParams().get('pipeline'); if (id) { savedSel.value = id; savedSel.dispatchEvent(new Event('change')); } }).catch((e) => toast(e.message, true));
})();
