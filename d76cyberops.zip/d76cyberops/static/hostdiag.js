(() => {
  const out = $('#hd-out'), st = $('#hd-st'), pauseBtn = $('#hd-pause'), interval = $('#hd-int');
  const hist = { cpu: [], mem: [] };
  let timer = null, paused = false;

  const push = (arr, v) => { if (v != null) arr.push(v); if (arr.length > 60) arr.shift(); };
  function spark(values, max = 100) {
    const w = 300, hgt = 56, n = Math.max(values.length, 2);
    const pts = values.map((v, i) => [(i / (n - 1)) * w, hgt - (Math.min(v, max) / max) * (hgt - 4) - 2]);
    const d = pts.length ? 'M' + pts.map((p) => p.map((x) => x.toFixed(1)).join(',')).join(' L') : '';
    return s('svg', { class: 'spark', viewBox: `0 0 ${w} ${hgt}`, preserveAspectRatio: 'none', role: 'img', 'aria-label': 'Recent history' },
      pts.length ? s('path', { class: 'area', d: `${d} L${w},${hgt} L0,${hgt} Z` }) : null, s('path', { d }));
  }
  const meter = (pct, cls) => { const i = h('i', { class: cls || (pct > 90 ? 'bad' : pct > 75 ? 'warn' : 'ok') }); i.style.width = (pct || 0) + '%'; return h('div', { class: 'meter', role: 'meter', 'aria-valuemin': '0', 'aria-valuemax': '100', 'aria-valuenow': String(Math.round(pct || 0)) }, i); };
  const dur = (sec) => { const d = Math.floor(sec / 86400), hr = Math.floor(sec % 86400 / 3600), m = Math.floor(sec % 3600 / 60); return `${d ? d + ' d ' : ''}${hr} h ${m} min`; };

  function render(r) {
    push(hist.cpu, r.cpu);
    if (r.memory) push(hist.mem, r.memory.percent);
    const unavailable = (what) => h('p', { class: 'muted' }, `${what} is not available on this system (it needs Linux /proc).`);
    fill(out,
      h('div', { class: 'split-2' },
        h('section', {}, h('h2', {}, 'Processor'),
          r.cpu == null ? h('p', { class: 'muted' }, 'Measuring. CPU use needs two samples.') : h('div', {}, h('p', {}, h('b', {}, `${r.cpu}%`), ` busy across ${r.system.cpu_count} core(s)`), meter(r.cpu), spark(hist.cpu)),
          r.load ? h('p', { class: 'muted' }, `Load average: ${r.load.join(', ')} (1, 5 and 15 minutes)`) : null),
        h('section', {}, h('h2', {}, 'Memory'),
          r.memory ? h('div', {}, h('p', {}, h('b', {}, `${r.memory.percent}%`), ` used, ${fmtBytes(r.memory.used)} of ${fmtBytes(r.memory.total)}`), meter(r.memory.percent), spark(hist.mem),
            r.memory.swap_total ? h('p', { class: 'muted' }, `Swap: ${fmtBytes(r.memory.swap_used)} of ${fmtBytes(r.memory.swap_total)}`) : null) : unavailable('Memory information'))),
      h('h2', {}, 'Disks'), r.disks.length ? dataTable(['Location', 'Path', 'Used', 'Size', ''], r.disks.map((d) => [d.label, h('code', {}, d.path), `${d.percent}%`, fmtBytes(d.total), meter(d.percent)])) : h('p', { class: 'muted' }, 'No disk information.'),
      h('h2', {}, 'System'), kvList([['Operating system', r.system.os], ['Architecture', r.system.machine], ['Host name', r.system.hostname], ['Python', r.system.python], ['Up for', r.uptime ? dur(r.uptime.seconds) : null], ['Running since', r.uptime ? r.uptime.since.replace('T', ' ') : null]]),
      h('h2', {}, 'Largest processes by memory'), r.processes && r.processes.length ? dataTable(['PID', 'Name', 'Memory', 'State'], r.processes.map((p) => [p.pid, p.name, fmtBytes(p.rss), p.state])) : unavailable('The process list'),
      h('h2', {}, 'Listening TCP ports'),
      r.listening ? h('div', {}, h('p', { class: 'muted small' }, 'Read from the local socket table. "All interfaces" means other machines on the network could connect if no firewall blocks them. Process names appear only for processes you may inspect.'),
        r.listening.length ? dataTable(['Port', 'Address', 'Reachable from', 'Process'], r.listening.map((p) => [h('code', {}, p.port), h('code', {}, p.address), h('span', { class: p.exposure === 'all interfaces' ? 'warn' : '' }, p.exposure), p.process ? `${p.process} (${p.pid})` : 'unknown'])) : h('p', { class: 'muted' }, 'Nothing is listening.')) : unavailable('The listening port list'));
    $('#hd-time').textContent = 'Updated ' + new Date().toLocaleTimeString();
  }

  async function poll() {
    try { render(await api('/api/system/info')); setStatus(st, ''); } catch (e) { setStatus(st, e.message, false); }
  }
  function start() { clearInterval(timer); if (!paused && !document.hidden) { poll(); timer = setInterval(poll, Number(interval.value)); } }
  pauseBtn.addEventListener('click', () => { paused = !paused; pauseBtn.textContent = paused ? 'Resume' : 'Pause'; paused ? clearInterval(timer) : start(); });
  interval.addEventListener('change', start);
  document.addEventListener('visibilitychange', start);
  start();
})();
