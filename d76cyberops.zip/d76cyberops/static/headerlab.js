(() => {
  const LABELS = { headers: 'Response headers', csp: 'Content-Security-Policy value', cookies: 'Set-Cookie lines (one per line)' };
  const SAMPLE = {
    headers: `HTTP/1.1 200 OK
Server: nginx/1.18.0
Strict-Transport-Security: max-age=300
Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline' https:
X-Content-Type-Options: nosniff
Set-Cookie: sessionid=abc123; Path=/; HttpOnly
Access-Control-Allow-Origin: *`,
    csp: "default-src 'self'; script-src 'self' 'unsafe-inline'; img-src *",
    cookies: 'Set-Cookie: sessionid=abc123; Path=/; HttpOnly\nSet-Cookie: __Host-pref=dark; Secure; Path=/; SameSite=Lax',
  };
  const input = $('#hl-in'), out = $('#hl-out'), st = $('#hl-st');
  let kind = 'headers';

  tabs($('#hl-tabs'), (k) => { kind = k; $('#hl-label').textContent = LABELS[k]; input.value = ''; fill(out); setStatus(st, ''); });
  $('#hl-sample').addEventListener('click', () => { input.value = SAMPLE[kind]; });

  const cookieBlock = (c) => h('div', { class: 'out-block' }, h('h3', {}, c.name || '(unnamed)'),
    h('p', { class: 'muted small' }, 'Value hidden. Attributes: ' + (Object.keys(c.attributes).join(', ') || 'none')), findingsList(c.findings));

  function showHeaders(r) {
    fill(out,
      h('div', { class: 'grade ' + r.grade }, h('b', {}, r.grade), h('span', {}, `${r.score} out of 100 across ${r.header_count} headers`)),
      h('p', { class: 'muted small' }, r.note),
      dataTable(['Header', 'Result', 'Value', 'Comment'], r.checks.map((c) => [h('b', {}, c.name), sevBadge(c.severity), h('code', { class: 'code-sm' }, c.value || 'not set'), c.message])),
      r.cookies.length ? h('div', {}, h('h2', {}, 'Cookies'), r.cookies.map(cookieBlock)) : null);
  }

  function showCsp(r) {
    const rows = Object.entries(r.directives).map(([d, v]) => [h('code', {}, d), h('code', { class: 'code-sm' }, v.join(' ') || '(no values)')]);
    fill(out, h('h2', {}, 'Findings'), findingsList(r.findings), h('h2', {}, 'Directives'), rows.length ? dataTable(['Directive', 'Sources'], rows) : null);
  }

  $('#hl-run').addEventListener('click', () => runWith($('#hl-run'), st, 'Analyzing...', async () => {
    const r = await api('/api/web/analyze', { method: 'POST', json: { kind, text: input.value } });
    setStatus(st, '');
    if (kind === 'headers') showHeaders(r);
    else if (kind === 'csp') showCsp(r);
    else fill(out, r.cookies.map(cookieBlock));
  }));
})();
