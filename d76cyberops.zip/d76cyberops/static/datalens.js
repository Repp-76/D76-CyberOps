(() => {
  const input = $('#dl-file'), out = $('#dl-out'), st = $('#dl-st');
  let sortCol = -1, sortDir = 1;

  function previewTable(r) {
    const filter = h('input', { type: 'search', placeholder: 'Filter rows', 'aria-label': 'Filter rows' });
    const wrap = h('div');
    const paint = () => {
      const q = filter.value.trim().toLowerCase();
      let rows = r.preview.filter((row) => !q || row.some((c) => c.toLowerCase().includes(q)));
      if (sortCol >= 0) {
        const num = rows.every((row) => row[sortCol] === '' || !Number.isNaN(Number(row[sortCol])));
        rows = [...rows].sort((a, b) => sortDir * (num ? Number(a[sortCol] || 0) - Number(b[sortCol] || 0) : a[sortCol].localeCompare(b[sortCol])));
      }
      const head = r.preview_columns.map((c, i) => {
        const label = c + (sortCol === i ? (sortDir > 0 ? ' (asc)' : ' (desc)') : '');
        const btn = h('button', { type: 'button', class: 'th-btn', onclick: () => { sortDir = sortCol === i ? -sortDir : 1; sortCol = i; paint(); } }, label);
        return h('th', { scope: 'col', 'aria-sort': sortCol === i ? (sortDir > 0 ? 'ascending' : 'descending') : 'none' }, btn);
      });
      const body = rows.slice(0, 200).map((row) => h('tr', {}, row.map((c) => h('td', {}, c.length > 80 ? c.slice(0, 80) + '...' : c))));
      fill(wrap,
        h('div', { class: 'tablewrap' }, h('table', {}, h('thead', {}, h('tr', {}, head)), h('tbody', {}, body))),
        h('p', { class: 'muted small' }, `Showing ${Math.min(rows.length, 200)} of ${rows.length} matching rows (the preview holds the first ${r.preview.length} of ${r.rows.toLocaleString()}).`));
    };
    filter.addEventListener('input', debounce(paint, 120));
    sortCol = -1; sortDir = 1;
    paint();
    return h('div', {}, h('div', { class: 'filters' }, filter), wrap);
  }

  async function convert(f, target) {
    const fd = new FormData();
    fd.append('file', f);
    fd.append('target', target);
    try {
      const res = await fetch('/api/data/convert', { method: 'POST', headers: { 'X-CSRF-Token': csrf }, body: fd });
      if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || 'Conversion failed.');
      const name = (res.headers.get('Content-Disposition') || '').match(/filename="([^"]+)"/);
      download(name ? name[1] : 'data.' + target, await res.blob(), 'application/octet-stream');
    } catch (e) { toast(e.message, true); }
  }

  $('#dl-run').addEventListener('click', () => runWith($('#dl-run'), st, 'Profiling...', async () => {
    const f = input.files[0];
    if (!f) throw new Error('Choose a file first.');
    const fd = new FormData();
    fd.append('file', f);
    const r = await api('/api/data/profile', { method: 'POST', body: fd });
    setStatus(st, '');
    const cols = r.columns.map((c) => [h('b', {}, c.name), h('span', { class: 'badge' }, c.type), c.filled.toLocaleString(), c.missing ? h('span', { class: 'warn' }, c.missing.toLocaleString()) : '0', c.unique.toLocaleString(),
      c.min !== undefined ? `${c.min} to ${c.max}, mean ${c.mean}, median ${c.median}` : c.min_length !== undefined ? `length ${c.min_length} to ${c.max_length}` : '',
      c.top.map(([v, n]) => `${v} (${n})`).join(', ')]);
    fill(out,
      kvList([['File', f.name], ['Format', r.format], ['Rows', r.rows.toLocaleString()], ['Columns', r.columns.length], ['Duplicate rows', r.duplicates]]),
      r.notes.length ? h('div', {}, h('h2', {}, 'Worth a look'), findingsList(r.notes.map((m) => ({ severity: 'warn', message: m })))) : h('p', { class: 'ok' }, 'No quality problems noticed.'),
      h('div', { class: 'actions' }, h('button', { class: 'btn', type: 'button', onclick: () => convert(f, 'json') }, icon('download'), 'Convert to JSON'), h('button', { class: 'btn', type: 'button', onclick: () => convert(f, 'csv') }, icon('download'), 'Convert to CSV')),
      h('h2', {}, 'Columns'), dataTable(['Column', 'Type', 'Filled', 'Missing', 'Distinct', 'Range', 'Most common values'], cols),
      h('h2', {}, 'Preview'), previewTable(r));
  }));
})();
