(() => {
  const STATUS = [['backlog', 'Backlog'], ['progress', 'In progress'], ['review', 'Review'], ['done', 'Completed']];
  const label = Object.fromEntries(STATUS);
  const sel = $('#bd-project'), body = $('#bd-body'), actions = $('#bd-actions');
  let projects = [], cur = null, tasks = [], events = [];

  const projectFields = [
    { name: 'name', label: 'Project name', required: true, max: 120 },
    { name: 'description', label: 'Description', type: 'textarea', rows: 3, max: 2000 },
  ];
  const taskFields = [
    { name: 'title', label: 'Task', required: true, max: 200 },
    { name: 'status', label: 'Status', type: 'select', options: STATUS },
    { name: 'priority', label: 'Priority', type: 'select', options: [['low', 'Low'], ['normal', 'Normal'], ['high', 'High'], ['urgent', 'Urgent']], default: 'normal' },
    { name: 'due', label: 'Deadline', type: 'date' },
    { name: 'tags', label: 'Tags', hint: 'Comma separated' },
    { name: 'notes', label: 'Notes', type: 'textarea', rows: 4 },
  ];

  async function loadProjects(selectId) {
    try { projects = (await R.list('projects')).items; } catch (e) { toast(e.message, true); return; }
    fill(sel, ...projects.map((p) => h('option', { value: p.id }, p.name)));
    sel.disabled = !projects.length;
    if (!projects.length) { cur = null; render(); return; }
    const id = selectId || (cur && projects.some((p) => p.id === cur.id) ? cur.id : projects[0].id);
    sel.value = id;
    await openProject(id);
  }

  async function openProject(id) {
    try {
      const [t, hist] = await Promise.all([R.list('tasks', { project_id: id }), R.list('task_history', { project_id: id })]);
      tasks = t.items;
      events = hist.items;
    } catch (e) { toast(e.message, true); return; }
    cur = projects.find((p) => p.id === Number(id));
    history.replaceState(null, '', '#project=' + id);
    render();
  }

  const refresh = () => openProject(cur.id);
  const today = new Date().toISOString().slice(0, 10);

  function render() {
    fill(actions, );
    if (!cur) {
      fill(body, emptyState('No projects yet', 'Create a project, then add tasks to move across the board.',
        h('button', { class: 'btn primary', type: 'button', onclick: newProject }, 'New project')));
      return;
    }
    fill(actions, 
      h('button', { class: 'btn primary', type: 'button', onclick: () => taskDialog() }, 'Add task'),
      h('button', { class: 'btn', type: 'button', onclick: editProject }, 'Edit project'),
      h('button', { class: 'btn danger', type: 'button', onclick: deleteProject }, 'Delete project'));
    const done = tasks.filter((t) => t.status === 'done').length;
    const pct = tasks.length ? Math.round((done / tasks.length) * 100) : 0;
    const bar = h('i', { class: 'ok' });
    bar.style.width = pct + '%';
    fill(body, 
      cur.description ? h('p', { class: 'muted prewrap' }, cur.description) : null,
      h('div', { class: 'progress' },
        h('div', { class: 'meter', role: 'meter', 'aria-valuemin': '0', 'aria-valuemax': '100', 'aria-valuenow': String(pct), 'aria-label': 'Project progress' }, bar),
        h('span', {}, tasks.length ? `${done} of ${tasks.length} completed (${pct}%)` : 'No tasks yet')),
      h('div', { class: 'board' }, STATUS.map(([key, name]) => {
        const col = tasks.filter((t) => t.status === key);
        return h('section', { class: 'col', 'data-s': key, 'aria-label': name },
          h('h3', {}, name, h('span', {}, String(col.length))),
          col.length ? col.map(card) : h('p', { class: 'muted small' }, 'Nothing here.'));
      })),
      history_());
  }

  const card = (t) => h('article', { class: 'task p-' + t.priority },
    h('button', { type: 'button', class: 'title', onclick: () => taskDialog(t) }, t.title),
    h('div', { class: 'meta' }, h('span', {}, t.priority),
      t.due ? h('span', { class: t.due < today && t.status !== 'done' ? 'late' : '' }, `${t.due < today && t.status !== 'done' ? 'Overdue: ' : 'Due '}${t.due}`) : null),
    h('div', {}, tagChips(t.tags)),
    h('div', { class: 'row2' },
      h('label', { class: 'sr', for: 'mv-' + t.id }, `Move ${t.title}`),
      h('select', { id: 'mv-' + t.id, onchange: async (ev) => {
        try { await R.update('tasks', t.id, { status: ev.target.value }); refresh(); } catch (e) { toast(e.message, true); }
      } }, STATUS.map(([v, l]) => h('option', { value: v, selected: v === t.status }, l))),
      h('button', { class: 'btn sm danger', type: 'button', onclick: () => removeTask(t) }, 'Delete')));

  const history_ = () => h('details', { class: 'hist' }, h('summary', {}, `Activity history (${events.length})`),
    events.length ? events.slice(0, 40).map((ev) => h('div', { class: 'rel' }, h('span', { class: 'num muted' }, ev.ts.replace('T', ' ').slice(0, 16)), h('span', {}, ev.event)))
      : h('p', { class: 'muted' }, 'Changes to tasks will be listed here.'));

  const taskDialog = (t) => formDialog({
    title: t ? 'Edit task' : 'Add task', fields: taskFields, values: t || { status: 'backlog', priority: 'normal' },
    save: (v) => (t ? R.update('tasks', t.id, v) : R.create('tasks', { ...v, project_id: cur.id })),
  }).then((ok) => ok && refresh());

  async function removeTask(t) {
    if (!confirm(`Delete the task "${t.title}"?`)) return;
    try { await R.remove('tasks', t.id); refresh(); } catch (e) { toast(e.message, true); }
  }

  const newProject = () => formDialog({
    title: 'New project', fields: projectFields, submit: 'Create project',
    save: async (v) => (await R.create('projects', v)).item,
  }).then((item) => item && loadProjects(item.id));

  const editProject = () => formDialog({
    title: 'Edit project', fields: projectFields, values: cur, save: (v) => R.update('projects', cur.id, v),
  }).then((ok) => ok && loadProjects(cur.id));

  async function deleteProject() {
    if (!confirm(`Delete "${cur.name}" with all ${tasks.length} of its tasks? This cannot be undone.`)) return;
    try { await R.remove('projects', cur.id); cur = null; history.replaceState(null, '', location.pathname); loadProjects(); } catch (e) { toast(e.message, true); }
  }

  sel.addEventListener('change', () => openProject(sel.value));
  $('#bd-new').addEventListener('click', newProject);
  const id = hashParams().get('project');
  loadProjects(id ? Number(id) : undefined);
})();
