(() => {
  const CATEGORIES = ['Cybersecurity', 'OSINT', 'Networking', 'Linux', 'Programming', 'Web Security',
    'Digital Forensics', 'Developer Tools', 'Privacy', 'Security Awareness'];
  const list = $('#kb-list'), detail = $('#kb-detail'), q = $('#kb-q'), catSel = $('#kb-cat');
  const bm = $('#kb-bm'), unread = $('#kb-unread');
  let articles = [], current = null;

  const fields = [
    { name: 'title', label: 'Title', required: true, max: 200 },
    { name: 'category', label: 'Category', type: 'select', options: CATEGORIES.map((c) => [c, c]) },
    { name: 'tags', label: 'Tags', hint: 'Comma separated' },
    { name: 'body', label: 'Article', type: 'textarea', rows: 14, required: true, hint: 'Markdown: headings, lists, tables, code blocks, bold and links' },
  ];

  async function load() {
    try { articles = (await R.list('kb_articles')).items; } catch (e) { fill(list, h('li', { class: 'bad pad' }, e.message)); return; }
    const counts = {};
    articles.forEach((a) => (counts[a.category] = (counts[a.category] || 0) + 1));
    const keep = catSel.value;
    fill(catSel, h('option', { value: '' }, `All categories (${articles.length})`),
      CATEGORIES.map((c) => h('option', { value: c }, `${c} (${counts[c] || 0})`)));
    catSel.value = keep;
    paintList();
    if (current) { current = articles.find((a) => a.id === current.id) || null; paintDetail(); }
  }

  function paintList() {
    const term = q.value.trim().toLowerCase();
    const rows = articles.filter((a) => (!catSel.value || a.category === catSel.value) && (!bm.checked || a.bookmarked)
      && (!unread.checked || !a.read) && (!term || [a.title, a.body, a.tags].join(' ').toLowerCase().includes(term)));
    fill(list, ...(rows.length ? rows.map((a) => h('li', {}, h('button', {
      type: 'button', class: 'item' + (current && current.id === a.id ? ' on' : ''), onclick: () => select(a.id),
    }, h('b', {}, a.title), h('small', {}, [a.category, a.read ? 'read' : 'unread', a.bookmarked ? 'bookmarked' : ''].filter(Boolean).join(', '))))) :
      [h('li', { class: 'muted pad' }, articles.length ? 'No articles match these filters.' : 'No articles yet. Write the first one.')]));
  }

  function select(id) {
    current = articles.find((a) => a.id === id) || null;
    history.replaceState(null, '', current ? '#article=' + id : location.pathname);
    paintList();
    paintDetail();
  }

  const toggle = (a, field) => async () => {
    try { await R.update('kb_articles', a.id, { [field]: a[field] ? 0 : 1 }); load(); } catch (e) { toast(e.message, true); }
  };

  function paintDetail() {
    const a = current;
    if (!a) { fill(detail, emptyState('Select an article', 'Pick an article from the list, or write a new one.')); return; }
    fill(detail, 
      h('div', { class: 'detail-head' }, h('h2', {}, a.title), h('span', { class: 'badge' }, a.category)),
      h('div', {}, tagChips(a.tags)),
      h('div', { class: 'actions' },
        h('button', { class: 'btn', type: 'button', 'aria-pressed': String(!!a.bookmarked), onclick: toggle(a, 'bookmarked') }, a.bookmarked ? 'Remove bookmark' : 'Bookmark'),
        h('button', { class: 'btn', type: 'button', onclick: toggle(a, 'read') }, a.read ? 'Mark as unread' : 'Mark as read'),
        h('button', { class: 'btn', type: 'button', onclick: () => dialog(a) }, 'Edit'),
        h('button', { class: 'btn danger', type: 'button', onclick: () => remove(a) }, 'Delete')),
      h('article', { class: 'prose' }, renderMarkdown(a.body)),
      h('p', { class: 'muted small' }, `Updated ${fmtDate(a.updated)}`));
  }

  const dialog = (a) => formDialog({
    title: a ? 'Edit article' : 'New article', fields, values: a || {},
    save: async (v) => (a ? await R.update('kb_articles', a.id, v) : await R.create('kb_articles', v)).item,
  }).then(async (item) => { if (item) { await load(); select(item.id); } });

  async function remove(a) {
    if (!confirm(`Delete "${a.title}"? This cannot be undone.`)) return;
    try { await R.remove('kb_articles', a.id); current = null; history.replaceState(null, '', location.pathname); await load(); paintDetail(); } catch (e) { toast(e.message, true); }
  }

  $('#kb-new').addEventListener('click', () => dialog());
  q.addEventListener('input', debounce(paintList, 120));
  [catSel, bm, unread].forEach((el) => el.addEventListener('change', paintList));
  paintDetail();
  load().then(() => { const id = hashParams().get('article'); if (id) select(Number(id)); });
})();
