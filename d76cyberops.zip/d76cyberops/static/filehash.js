(() => {
  const form = $('#fh-form'), input = $('#fh-files'), run = $('#fh-run');
  const status = $('#fh-st'), section = $('#fh-results'), body = $('#fh-body');
  const expect = $('#fh-expect'), cmp = $('#fh-cmp');
  const LABEL = { sha256: 'SHA-256', sha512: 'SHA-512', sha1: 'SHA-1', md5: 'MD5' };
  let data = null;

  const fmtSize = (n) => {
    if (n < 1024) return `${n} B`;
    const u = ['KB', 'MB', 'GB'];
    let i = -1;
    do { n /= 1024; i++; } while (n >= 1024 && i < u.length - 1);
    return `${n.toFixed(1)} ${u[i]}`;
  };

  function render() {
    body.replaceChildren();
    const want = expect.value.trim().toLowerCase();
    let matches = 0;
    for (const r of data.results) {
      for (const [algo, digest] of Object.entries(r.hashes)) {
        const tr = document.createElement('tr');
        const cells = [r.name, fmtSize(r.size), LABEL[algo]].map((t) => {
          const td = document.createElement('td');
          td.textContent = t;
          return td;
        });
        const dig = document.createElement('td');
        const code = document.createElement('code');
        code.className = 'digest';
        code.textContent = digest;
        const copy = document.createElement('button');
        copy.type = 'button';
        copy.className = 'btn sm';
        copy.textContent = 'Copy';
        copy.setAttribute('aria-label', `Copy ${LABEL[algo]} digest of ${r.name}`);
        copy.addEventListener('click', () => copyText(digest));
        dig.append(code, copy);
        const res = document.createElement('td');
        if (want) {
          const hit = digest === want;
          if (hit) matches++;
          res.textContent = hit ? 'Match' : 'No match';
          res.className = hit ? 'ok' : 'muted';
        }
        tr.append(...cells, dig, res);
        body.append(tr);
      }
    }
    if (!want) setStatus(cmp, '');
    else if (matches) setStatus(cmp, `The expected digest matches ${matches} result${matches === 1 ? '' : 's'}.`, true);
    else setStatus(cmp, 'The expected digest does not match any calculated digest.', false);
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!input.files.length) return setStatus(status, 'Choose at least one file first.', false);
    const algos = $$('input[name=algo]:checked', form).map((c) => c.value);
    if (!algos.length) return setStatus(status, 'Select at least one algorithm.', false);
    const fd = new FormData();
    for (const f of input.files) fd.append('files', f);
    algos.forEach((a) => fd.append('algo', a));
    run.disabled = true;
    setStatus(status, `Hashing ${input.files.length} file${input.files.length === 1 ? '' : 's'}...`, true);
    try {
      data = await api('/api/hash', { method: 'POST', body: fd });
      section.hidden = false;
      render();
      setStatus(status, `Done at ${data.generated.replace('T', ' ')} UTC.`, true);
    } catch (err) {
      setStatus(status, err.message, false);
    } finally {
      run.disabled = false;
    }
  });

  expect.addEventListener('input', () => data && render());

  $('#fh-save').addEventListener('click', async () => {
    try {
      await R.create('saved_results', { kind: 'filehash', title: `File hashes (${data.results.length} file${data.results.length === 1 ? '' : 's'}) ${data.generated.slice(0, 10)}`, data: JSON.stringify(data) });
      toast('Saved. Choose it in ReportGen.');
    } catch (e) { toast(e.message, true); }
  });

  $('#fh-json').addEventListener('click', () =>
    download('filehash-results.json', JSON.stringify(data, null, 2), 'application/json'));

  $('#fh-csv').addEventListener('click', () => {
    const esc = (v) => {
      v = String(v);
      if (/^[=+\-@]/.test(v)) v = "'" + v;
      return `"${v.replace(/"/g, '""')}"`;
    };
    const rows = [['file', 'size_bytes', 'algorithm', 'digest']];
    data.results.forEach((r) => Object.entries(r.hashes).forEach(([a, d]) => rows.push([r.name, r.size, LABEL[a], d])));
    download('filehash-results.csv', rows.map((r) => r.map(esc).join(',')).join('\n'), 'text/csv');
  });
})();
