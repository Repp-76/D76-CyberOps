(() => {
  const $f = { method: $('#aw-method'), url: $('#aw-url'), headers: $('#aw-headers'), body: $('#aw-body'), vars: $('#aw-vars'),
    follow: $('#aw-follow'), verify: $('#aw-verify'), priv: $('#aw-private'), auth: $('#aw-auth'), timeout: $('#aw-timeout') };
  const out = $('#aw-out'), st = $('#aw-st'), saved = $('#aw-saved');
  let last = null;

  // A variable with no value counts as undefined, so sending stops instead of sending an empty header.
  const variables = () => Object.fromEntries($f.vars.value.split('\n').map((l) => l.trim()).filter((l) => l.includes('=')).map((l) => [l.slice(0, l.indexOf('=')).trim(), l.slice(l.indexOf('=') + 1)]).filter(([k, v]) => k && v !== ''));
  const subst = (text, vars) => text.replace(/\{\{\s*([\w-]+)\s*\}\}/g, (m, name) => (name in vars ? vars[name] : m));
  function unresolved(text) { return [...new Set([...text.matchAll(/\{\{\s*([\w-]+)\s*\}\}/g)].map((m) => m[1]))]; }

  function prepared() {
    const vars = variables();
    const url = subst($f.url.value.trim(), vars), body = subst($f.body.value, vars);
    const headers = $f.headers.value.split('\n').map((l) => l.trim()).filter(Boolean).map((l) => {
      const i = l.indexOf(':');
      return i < 0 ? [l, ''] : [l.slice(0, i).trim(), subst(l.slice(i + 1).trim(), vars)];
    });
    return { url, body, headers };
  }

  const q = (s) => "'" + s.replace(/'/g, "'\\''") + "'";
  $('#aw-curl').addEventListener('click', () => {
    const p = prepared();
    if (!p.url) return toast('Enter a URL first.', true);
    const parts = ['curl', '-X', $f.method.value, q(p.url), ...p.headers.flatMap(([k, v]) => ['-H', q(`${k}: ${v}`)])];
    if (p.body) parts.push('--data-raw', q(p.body));
    copyText(parts.join(' '));
  });

  function bodyView(r) {
    if (r.binary) return h('p', { class: 'muted' }, `Binary response (${fmtBytes(r.size)}). It is not shown.`);
    if (!r.body) return h('p', { class: 'muted' }, 'The response has no body.');
    let text = r.body;
    const ct = (r.headers.find(([k]) => k.toLowerCase() === 'content-type') || [, ''])[1];
    if (/json/i.test(ct) || /^\s*[[{]/.test(text)) { try { text = JSON.stringify(JSON.parse(text), null, 2); } catch { /* show as received */ } }
    return h('div', {}, h('pre', { class: 'json' }, text), r.truncated ? h('p', { class: 'muted small' }, 'Truncated at 1 MB.') : null,
      h('div', { class: 'actions' }, h('button', { class: 'btn sm', type: 'button', onclick: () => copyText(r.body) }, icon('copy'), 'Copy body')));
  }

  function show(r) {
    const cls = r.status < 300 ? 'ok' : r.status < 400 ? 'warn' : 'bad';
    const pane = h('div');
    const views = {
      body: () => bodyView(r),
      headers: () => dataTable(['Name', 'Value'], r.headers.map(([k, v]) => [h('code', {}, k), h('code', { class: 'code-sm' }, v)])),
      path: () => h('div', {}, r.chain.map((c, i) => h('div', { class: 'hop' }, h('span', { class: 'n' }, String(i + 1)), h('div', {}, h('code', { class: 'code-sm' }, c.url), h('div', { class: 'muted small' }, `HTTP ${c.status}, ${c.ip}`)))),
        r.tls ? kvList([['TLS version', r.tls.version], ['Cipher', r.tls.cipher], ['Certificate', r.tls.verified ? 'Verified' : 'Not verified' + (r.tls.error ? ': ' + r.tls.error : '')]]) : null),
    };
    const bar = h('div', { class: 'subtabs', role: 'tablist' });
    const pick = (k) => { $$('button', bar).forEach((b) => b.setAttribute('aria-selected', String(b.dataset.k === k))); fill(pane, views[k]()); };
    [['body', 'Body'], ['headers', `Headers (${r.headers.length})`], ['path', r.chain.length > 1 ? `Redirects (${r.chain.length})` : 'Connection']].forEach(([k, l]) =>
      bar.append(h('button', { type: 'button', role: 'tab', 'data-k': k, onclick: () => pick(k) }, l)));
    fill(out,
      h('div', { class: 'detail-head' }, h('h2', { class: cls }, `${r.status} ${r.reason}`), h('span', { class: 'badge' }, r.http_version), h('span', { class: 'badge' }, `${r.ms} ms`), h('span', { class: 'badge' }, fmtBytes(r.size))),
      bar, pane);
    pick('body');
  }

  $('#aw-send').addEventListener('click', () => runWith($('#aw-send'), st, 'Sending...', async () => {
    const p = prepared();
    const missing = unresolved(p.url + p.headers.map((h_) => h_.join(':')).join('\n') + p.body);
    if (missing.length) throw new Error(`Define a value for: ${missing.join(', ')}.`);
    if (!p.url) throw new Error('Enter a URL.');
    const r = await api('/api/apiwb/send', { method: 'POST', json: { method: $f.method.value, url: p.url, headers: p.headers, body: p.body,
      follow: $f.follow.checked, verify: $f.verify.checked, allow_private: $f.priv.checked, authorized: $f.auth.checked, timeout: Number($f.timeout.value) || 10 } });
    last = r;
    setStatus(st, '');
    show(r);
  }));

  async function loadSaved() {
    const { items } = await R.list('api_requests');
    fill(saved, items.length ? items.map((it) => h('li', {}, h('div', { class: 'rel' },
      h('button', { class: 'item', type: 'button', onclick: () => load(it) }, h('b', {}, it.name), h('small', {}, `${it.method} ${it.url}`)),
      h('button', { class: 'btn sm danger', type: 'button', 'aria-label': 'Delete ' + it.name, onclick: async () => { if (confirm(`Delete "${it.name}"?`)) { await R.remove('api_requests', it.id); loadSaved(); } } }, 'Delete'))))
      : h('li', { class: 'muted pad' }, 'Nothing saved yet.'));
  }
  function load(it) {
    $f.method.value = it.method; $f.url.value = it.url; $f.headers.value = it.headers; $f.body.value = it.body;
    const names = unresolved(it.url + it.headers + it.body).filter((n) => !(n in variables()));
    if (names.length) $f.vars.value = ($f.vars.value ? $f.vars.value + '\n' : '') + names.map((n) => n + '=').join('\n');
    toast('Request loaded. Fill in the variables before sending.');
  }
  $('#aw-save').addEventListener('click', () => {
    if (!$f.url.value.trim()) return toast('Enter a URL first.', true);
    formDialog({ title: 'Save request', fields: [{ name: 'name', label: 'Name', required: true, max: 120, hint: 'Authorization, Cookie and API-key values are replaced with {{placeholders}} when saved. Check the body for secrets yourself.' }], submit: 'Save',
      save: (v) => R.create('api_requests', { name: v.name, method: $f.method.value, url: $f.url.value.trim(), headers: $f.headers.value, body: $f.body.value }) })
      .then((ok) => ok && loadSaved());
  });
  loadSaved().catch((e) => toast(e.message, true));
})();
