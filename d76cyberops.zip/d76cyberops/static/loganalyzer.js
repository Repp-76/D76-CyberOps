(() => {
  const out = $('#la-out'), st = $('#la-st');
  let data = null;

  function timeline(r) {
    if (!r.timeline.length) return h('p', { class: 'muted' }, 'No timestamps were found, so there is no timeline.');
    const max = Math.max(...r.timeline.map((b) => b.n));
    const unit = r.bucket_seconds >= 86400 ? 'day' : r.bucket_seconds >= 3600 ? 'hour' : 'minute';
    return h('div', {}, h('div', { class: 'bars', role: 'img', 'aria-label': 'Lines over time' }, r.timeline.map((b) => {
      const bar = h('i', { class: b.errors ? 'hi' : '', title: `${b.t.replace('T', ' ')} UTC: ${b.n} lines, ${b.errors} errors` });
      bar.style.height = Math.max(3, (b.n / max) * 100) + '%';
      return bar;
    })), h('p', { class: 'muted small' }, `Each bar groups about ${Math.round(r.bucket_seconds / (unit === 'day' ? 86400 : unit === 'hour' ? 3600 : 60))} ${unit}(s). Amber bars contain error lines.`));
  }

  function explorer(r) {
    const q = h('input', { type: 'search', placeholder: 'Search the log', 'aria-label': 'Search the log' });
    const lvl = h('select', { 'aria-label': 'Level' }, h('option', { value: '' }, 'Any level'), ['error', 'warn', 'info', 'debug'].map((l) => h('option', { value: l }, l)));
    const ip = h('input', { type: 'search', placeholder: 'Address', 'aria-label': 'Address' });
    const wrap = h('div'), more = h('button', { class: 'btn', type: 'button' }, 'Show more');
    let shown = 200, rows = [];
    const paint = () => {
      const term = q.value.toLowerCase();
      rows = r.entries.filter((e) => (!lvl.value || e.level === lvl.value) && (!ip.value || (e.ip || '').includes(ip.value.trim())) && (!term || e.text.toLowerCase().includes(term)));
      fill(wrap, rows.length ? dataTable(['Line', 'Time (UTC)', 'Level', 'Address', 'Text'], rows.slice(0, shown).map((e) => [String(e.n), e.ts ? e.ts.replace('T', ' ') : '', h('span', { class: e.level === 'error' ? 'bad' : e.level === 'warn' ? 'warn' : 'muted' }, e.level), e.ip || '', h('code', { class: 'code-sm' }, e.text)])) : h('p', { class: 'muted' }, 'No lines match.'),
        h('p', { class: 'muted small' }, `${rows.length.toLocaleString()} matching line(s)` + (r.entries_truncated ? ` among the first ${r.entries.length.toLocaleString()} kept for browsing.` : '.')));
      more.hidden = rows.length <= shown;
    };
    more.addEventListener('click', () => { shown += 200; paint(); });
    [q, ip].forEach((el) => el.addEventListener('input', debounce(() => { shown = 200; paint(); }, 150)));
    lvl.addEventListener('change', () => { shown = 200; paint(); });
    paint();
    return h('div', {}, h('div', { class: 'filters' }, q, lvl, ip), wrap, h('div', { class: 'actions' }, more));
  }

  function mdReport(r) {
    const lines = [`# Log analysis: ${r.filename}`, '', `${r.lines} lines, ${r.first || 'no timestamps'} to ${r.last || ''}`, '', '## Potential anomalies', ''];
    if (!r.anomalies.length) lines.push('None flagged.');
    r.anomalies.forEach((a) => { lines.push(`### ${a.title}`, a.detail, ''); a.samples.forEach((s) => lines.push(`- line ${s.line}: \`${s.text.replace(/`/g, "'")}\``)); lines.push(''); });
    return lines.join('\n');
  }

  $('#la-run').addEventListener('click', () => runWith($('#la-run'), st, 'Analyzing...', async () => {
    const f = $('#la-file').files[0];
    if (!f) throw new Error('Choose a log file first.');
    const fd = new FormData();
    fd.append('file', f);
    const r = data = await api('/api/logs/analyze', { method: 'POST', body: fd });
    setStatus(st, '');
    const anomalies = r.anomalies.length ? r.anomalies.map((a) => h('div', { class: 'out-block' }, h('h3', {}, a.title), h('p', {}, a.detail),
      h('pre', { class: 'hex' }, a.samples.map((s) => `line ${s.line}: ${s.text}`).join('\n') || 'No sample lines.'))) : [h('p', { class: 'ok' }, 'None of the checks flagged anything.')];
    fill(out,
      h('div', { class: 'detail-head' }, h('h2', {}, f.name), h('span', { class: 'badge' }, fmtBytes(f.size))),
      h('div', { class: 'actions' },
        h('button', { class: 'btn', type: 'button', onclick: () => download('log-analysis.json', JSON.stringify({ ...r, entries: undefined }, null, 2), 'application/json') }, icon('download'), 'Export JSON'),
        h('button', { class: 'btn', type: 'button', onclick: () => download('log-analysis.md', mdReport(r), 'text/markdown') }, icon('download'), 'Export Markdown'),
        h('button', { class: 'btn', type: 'button', onclick: async () => { try { await R.create('saved_results', { kind: 'log', title: `Log: ${f.name} ${new Date().toISOString().slice(0, 10)}`, data: JSON.stringify({ ...r, entries: [] }) }); toast('Saved. Choose it in ReportGen.'); } catch (e) { toast(e.message, true); } } }, icon('report'), 'Save for reports')),
      kvList([['Lines', r.lines.toLocaleString()], ['First entry', r.first], ['Last entry', r.last], ['Formats', Object.entries(r.formats).map(([k, v]) => `${k}: ${v}`).join(', ')],
        ['Levels', Object.entries(r.levels).map(([k, v]) => `${k}: ${v}`).join(', ')]]),
      r.notes.map((n) => h('p', { class: 'muted small' }, n)),
      h('h2', {}, `Potential anomalies (${r.anomalies.length})`), h('p', { class: 'muted small' }, 'A pattern worth a look is not proof of malicious activity. Check the lines shown before drawing conclusions.'), anomalies,
      h('h2', {}, 'Timeline'), timeline(r),
      h('div', { class: 'split-2' }, h('div', {}, h('h2', {}, 'Busiest addresses'), r.top_ips.length ? dataTable(['Address', 'Lines', ''], r.top_ips.map((i) => [h('code', {}, i.ip), String(i.count), i.private ? 'private' : ''])) : h('p', { class: 'muted' }, 'No addresses found.')),
        h('div', {}, h('h2', {}, 'HTTP status codes'), r.statuses.length ? dataTable(['Status', 'Count'], r.statuses.map(([s, c]) => [String(s), String(c)])) : h('p', { class: 'muted' }, 'No HTTP status codes found.'))),
      h('h2', {}, 'Browse the log'), explorer(r));
  }));
})();
