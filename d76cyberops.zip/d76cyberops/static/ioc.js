(() => {
  const out = $('#io-out'), st = $('#io-st'), csvBtn = $('#io-csv');
  const NAMES = { url: 'URLs', domain: 'Domains', ipv4: 'IPv4 addresses', ipv6: 'IPv6 addresses', email: 'Email addresses', sha256: 'SHA-256 hashes', sha1: 'SHA-1 hashes', md5: 'MD5 hashes', cve: 'CVE identifiers', attack: 'ATT&CK techniques' };
  let last = null;

  function paint() {
    if (!last) return;
    const def = $('#io-defang').checked;
    fill(out, Object.entries(last.iocs).map(([kind, rows]) => {
      const values = rows.map((r) => (def ? r.defanged : r.value));
      return h('div', { class: 'out-block' }, h('div', { class: 'detail-head' }, h('h3', {}, `${NAMES[kind] || kind} (${rows.length})`),
        h('button', { class: 'btn sm', type: 'button', onclick: () => copyText(values.join('\n')) }, icon('copy'), 'Copy all')),
        dataTable(['Indicator', 'Occurrences'], rows.map((r, i) => [h('code', { class: 'code-sm' }, values[i]), r.count])));
    }));
  }

  $('#io-defang').addEventListener('change', paint);
  csvBtn.addEventListener('click', () => {
    const def = $('#io-defang').checked, rows = [['type', 'indicator', 'occurrences']];
    Object.entries(last.iocs).forEach(([k, list]) => list.forEach((r) => rows.push([k, def ? r.defanged : r.value, r.count])));
    download('indicators.csv', toCsv(rows), 'text/csv');
  });
  $('#io-run').addEventListener('click', () => runWith($('#io-run'), st, 'Scanning...', async () => {
    last = await api('/api/forensics/ioc', { method: 'POST', json: { text: $('#io-in').value, refang: $('#io-refang').checked, include_private: $('#io-private').checked } });
    csvBtn.disabled = !last.total;
    setStatus(st, last.total ? `${last.total} indicator(s) found. ${last.note}` : 'No indicators found.', last.total > 0);
    if (!last.total) fill(out); else paint();
  }));
})();
