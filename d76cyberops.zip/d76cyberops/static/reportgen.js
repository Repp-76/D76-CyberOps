(() => {
  const st = $('#rg-st');
  async function sources() {
    const s = await api('/api/reports/sources');
    const box = (type, id, label, sub) => h('label', { class: 'check' }, h('input', { type: 'checkbox', 'data-type': type, 'data-id': id }), h('span', {}, label, sub ? h('small', { class: 'muted' }, '  ' + sub) : null));
    const group = (title, rows) => (rows.length ? h('div', {}, h('h3', {}, title), rows) : null);
    fill($('#rg-sources'),
      group('Cases and research cases', s.cases.map((c) => box('case', c.id, c.title, `${c.kind === 'research' ? 'research' : 'case'}, ${c.status}`))),
      group('Security checklists', s.checklists.map((c) => box('checklist', c.id, c.name, c.target))),
      group('Saved inspections, log analyses and file hashes', s.saved.map((x) => box('saved', x.id, x.title, x.kind))),
      s.netwatch ? group('Monitoring', [box('netwatch', 0, `NetWatch summary (${s.netwatch} target${s.netwatch === 1 ? '' : 's'})`, 'last 24 hours')]) : null,
      !s.cases.length && !s.checklists.length && !s.saved.length && !s.netwatch ? h('p', { class: 'muted' }, 'Nothing to include yet. Create a case or checklist, or use Save for reports in Domain Inspector, LogAnalyzer or FileHash.') : null);
  }

  async function list() {
    const { items } = await api('/api/reports/list');
    fill($('#rg-list'), items.length ? items.map((r) => h('div', { class: 'item-row' }, h('h3', {}, r.title), h('p', {}, r.created.replace('T', ' ').slice(0, 16) + ' UTC'),
      h('div', { class: 'actions' }, h('a', { class: 'btn sm', href: `/api/reports/${r.id}/download?format=view`, target: '_blank', rel: 'noopener' }, 'View'),
        [['pdf', 'PDF'], ['html', 'HTML'], ['md', 'Markdown'], ['json', 'JSON']].map(([f, l]) => h('a', { class: 'btn sm', href: `/api/reports/${r.id}/download?format=${f}`, download: '' }, icon('download'), l)),
        h('button', { class: 'btn sm danger', type: 'button', onclick: async () => { if (confirm(`Delete the report "${r.title}"?`)) { await api(`/api/reports/${r.id}/delete`, { method: 'POST' }); list(); } } }, 'Delete')))) : h('p', { class: 'muted' }, 'No reports yet.'));
  }

  $('#rg-go').addEventListener('click', () => runWith($('#rg-go'), st, 'Building the report...', async () => {
    const picked = $$('#rg-sources input:checked').map((i) => ({ type: i.dataset.type, id: Number(i.dataset.id) }));
    const r = await api('/api/reports', { method: 'POST', json: { title: $('#rg-title').value, author: $('#rg-author').value, scope: $('#rg-scope').value, methodology: $('#rg-method').value, notes: $('#rg-notes').value, conclusion: $('#rg-concl').value, sources: picked } });
    setStatus(st, 'Report created. Download it from the list.', true);
    list();
  }));
  sources().catch((e) => fill($('#rg-sources'), h('p', { class: 'bad' }, e.message)));
  list().catch(() => {});
})();
