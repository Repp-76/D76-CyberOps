(() => {
  const list = $('#ti-list'), st = $('#ti-st'), more = $('#ti-more');
  const f = { q: $('#ti-q'), feed: $('#ti-feed'), sev: $('#ti-sev'), kev: $('#ti-kev'), bm: $('#ti-bm') };
  let items = [], feeds = [], shown = 60;

  const feedName = (id) => (feeds.find((x) => x.id === id) || {}).name || 'Unknown feed';
  const filtered = () => {
    const q = f.q.value.trim().toLowerCase();
    const only = Number(hashParams().get('item')) || null;
    return items.filter((i) => (!only || i.id === only) && (!f.feed.value || String(i.feed_id) === f.feed.value) && (!f.sev.value || i.severity === f.sev.value) && (!f.kev.checked || i.exploited) && (!f.bm.checked || i.bookmarked)
      && (!q || `${i.title} ${i.summary} ${i.cve}`.toLowerCase().includes(q)));
  };

  function paint() {
    const rows = filtered();
    $('#ti-count').textContent = items.length ? `${rows.length.toLocaleString()} of ${items.length.toLocaleString()} cached items` : '';
    fill(list, rows.length ? rows.slice(0, shown).map((i) => h('li', {}, h('div', { class: 'detail-head' },
      i.link ? h('a', { class: 'rt', href: i.link, target: '_blank', rel: 'noopener noreferrer' }, i.title) : h('span', { class: 'rt' }, i.title)),
      h('div', {}, i.severity !== 'unrated' ? h('span', { class: 'badge ' + (i.severity === 'critical' || i.severity === 'high' ? 'bad' : i.severity === 'medium' ? 'warn' : '') }, i.severity) : h('span', { class: 'badge' }, 'unrated'), ' ',
        i.exploited ? h('span', { class: 'badge bad' }, 'Known exploited') : null, ' ', h('small', {}, `${feedName(i.feed_id)}${i.published ? ', ' + i.published.slice(0, 10) : ''}`)),
      h('p', {}, i.summary.slice(0, 320) + (i.summary.length > 320 ? '...' : '')),
      h('div', { class: 'actions' }, h('button', { class: 'btn sm', type: 'button', 'aria-pressed': String(!!i.bookmarked), onclick: async () => {
        try { await R.update('intel_items', i.id, { bookmarked: i.bookmarked ? 0 : 1 }); i.bookmarked = i.bookmarked ? 0 : 1; paint(); } catch (e) { toast(e.message, true); }
      } }, i.bookmarked ? 'Bookmarked' : 'Bookmark'), i.cve ? h('span', { class: 'muted small' }, i.cve) : null)))
      : h('li', { class: 'muted pad' }, items.length ? 'Nothing matches these filters.' : 'No items cached yet. Press Refresh feeds to fetch them.'));
    more.hidden = rows.length <= shown;
  }

  async function load() {
    [items, feeds] = (await Promise.all([R.list('intel_items'), R.list('feeds')])).map((r) => r.items);
    const keep = f.feed.value;
    fill(f.feed, h('option', { value: '' }, 'All sources'), feeds.map((x) => h('option', { value: x.id }, x.name)));
    f.feed.value = keep;
    paint();
    paintFeeds();
  }

  function paintFeeds() {
    fill($('#ti-feedlist'), dataTable(['Feed', 'Type', 'Last fetch', 'Status', ''], feeds.map((x) => [h('div', {}, h('b', {}, x.name), h('span', { class: 'sub' }, x.url)), x.kind, x.last_fetch ? x.last_fetch.replace('T', ' ').slice(0, 16) : 'never',
      x.last_status === 'ok' ? h('span', { class: 'ok' }, 'OK') : x.last_status ? h('span', { class: 'bad' }, x.last_status) : h('span', { class: 'muted' }, 'not fetched'),
      h('div', { class: 'actions' }, h('button', { class: 'btn sm', type: 'button', onclick: async () => { await R.update('feeds', x.id, { enabled: x.enabled ? 0 : 1 }); load(); } }, x.enabled ? 'Disable' : 'Enable'),
        h('button', { class: 'btn sm', type: 'button', onclick: () => feedDialog(x) }, 'Edit'),
        h('button', { class: 'btn sm danger', type: 'button', onclick: async () => { if (confirm(`Remove "${x.name}" and its cached items?`)) { await R.remove('feeds', x.id); load(); } } }, 'Remove'))])));
  }

  const feedDialog = (x) => formDialog({ title: x ? 'Edit feed' : 'Add a feed', values: x || { kind: 'rss' }, submit: 'Save', fields: [
    { name: 'name', label: 'Name', required: true, max: 120 }, { name: 'url', label: 'Address (https only)', type: 'url', required: true, max: 1000, hint: 'An RSS or Atom feed, the CISA KEV JSON catalog, or the NVD CVE API.' },
    { name: 'kind', label: 'Type', type: 'select', options: [['rss', 'RSS or Atom'], ['kev', 'CISA Known Exploited Vulnerabilities (JSON)'], ['nvd', 'NVD CVE API 2.0 (JSON)']] }],
    save: (v) => (x ? R.update('feeds', x.id, v) : R.create('feeds', v)) }).then((ok) => ok && load());

  const refresh = (force, btn) => runWith(btn, st, 'Fetching feeds (this can take a few seconds)...', async () => {
    const { results } = await api('/api/intel/refresh', { method: 'POST', json: { force } });
    const bad = results.filter((r) => !r.ok), added = results.reduce((n, r) => n + (r.added || 0), 0);
    setStatus(st, `${results.length} feed(s) checked, ${added} new item(s)` + (results.filter((r) => r.skipped).length ? `, ${results.filter((r) => r.skipped).length} still fresh in the cache` : '') + (bad.length ? `. Problems: ${bad.map((b) => `${b.name}: ${b.error}`).join(' | ')}` : '.'), !bad.length);
    await load();
  });

  const csvRows = () => [['published', 'severity', 'known_exploited', 'cve', 'title', 'source', 'link'], ...filtered().map((i) => [i.published, i.severity, i.exploited ? 'yes' : 'no', i.cve, i.title, feedName(i.feed_id), i.link])];
  $('#ti-refresh').addEventListener('click', () => refresh(false, $('#ti-refresh')));
  $('#ti-force').addEventListener('click', () => refresh(true, $('#ti-force')));
  $('#ti-feeds-btn').addEventListener('click', () => { const s = $('#ti-feeds'); s.hidden = !s.hidden; });
  $('#ti-addfeed').addEventListener('click', () => feedDialog());
  $('#ti-json').addEventListener('click', () => download('threat-intel.json', JSON.stringify(filtered(), null, 2), 'application/json'));
  $('#ti-csv').addEventListener('click', () => download('threat-intel.csv', toCsv(csvRows()), 'text/csv'));
  $('#ti-clear').addEventListener('click', async () => { if (confirm('Clear cached items? Bookmarked items are kept.')) { await api('/api/intel/clear', { method: 'POST' }); load(); } });
  more.addEventListener('click', () => { shown += 60; paint(); });
  Object.values(f).forEach((el) => el.addEventListener(el.type === 'search' ? 'input' : 'change', debounce(() => { shown = 60; paint(); }, 120)));
  api('/api/intel/status').then((s) => { $('#ti-keyline').textContent = s.nvd_key ? 'An NVD API key is configured through D76_NVD_API_KEY.' : 'No NVD API key is set. NVD works without one but limits how often it answers; set D76_NVD_API_KEY to raise the limit.'; });
  load().catch((e) => toast(e.message, true));
})();
