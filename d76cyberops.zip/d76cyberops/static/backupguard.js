(() => {
  const st = $('#bg-st'), out = $('#bg-out'), hist = $('#bg-hist');
  const val = (id) => $('#' + id).value.trim();
  const body = () => ({ source: val('bg-src'), dest: val('bg-dst'), name: val('bg-name'), excludes: $('#bg-ex').value });

  function picker(targetId) {
    const dlg = h('dialog', { class: 'dlg', 'aria-label': 'Choose a folder' });
    const path = h('code', { class: 'code-sm' }), list = h('ul', { class: 'folder-list' }), err = h('p', { class: 'status bad' });
    async function go(p) {
      try { const r = await api('/api/backup/browse?path=' + encodeURIComponent(p || '')); path.textContent = r.path; dlg.dataset.path = r.path;
        fill(list, r.parent ? h('li', {}, h('button', { type: 'button', onclick: () => go(r.parent) }, '.. (up one level)')) : null, r.folders.map((n) => h('li', {}, h('button', { type: 'button', onclick: () => go(r.path.replace(/\/$/, '') + '/' + n) }, n)))); err.textContent = ''; }
      catch (e) { err.textContent = e.message; }
    }
    dlg.append(h('form', { method: 'dialog' }, h('h2', {}, 'Choose a folder'), path, list, err, h('div', { class: 'actions' },
      h('button', { class: 'btn primary', type: 'button', onclick: () => { $('#' + targetId).value = dlg.dataset.path; dlg.close(); } }, 'Use this folder'), h('button', { class: 'btn', type: 'button', onclick: () => dlg.close() }, 'Cancel'))));
    dlg.addEventListener('close', () => dlg.remove());
    document.body.append(dlg); dlg.showModal();
    go($('#' + targetId).value.trim() || '');
  }
  $$('[data-pick]').forEach((b) => b.addEventListener('click', () => picker(b.dataset.pick)));

  const counts = (c) => `${c.new} new, ${c.changed} changed, ${c.deleted} removed from the source, ${c.unchanged} unchanged`;
  const names = (title, list) => (list && list.length ? h('details', {}, h('summary', {}, `${title} (${list.length})`), h('pre', { class: 'hex' }, list.join('\n'))) : null);

  $('#bg-prev').addEventListener('click', () => runWith($('#bg-prev'), st, 'Comparing...', async () => {
    const r = await api('/api/backup/preview', { method: 'POST', json: body() });
    setStatus(st, '');
    fill(out, h('p', {}, h('b', {}, `${r.files.toLocaleString()} files, ${fmtBytes(r.bytes)} in the source. `), r.previous ? `Compared with the backup of ${r.previous}: ` : 'This would be the first backup: ', counts(r.counts) + '.'),
      r.skipped_count ? h('p', { class: 'muted small' }, `${r.skipped_count} item(s) skipped (links and special files are not backed up).`) : null, names('New files', r.new), names('Changed files', r.changed), names('Deleted from the source', r.deleted));
  }));

  $('#bg-run').addEventListener('click', () => runWith($('#bg-run'), st, 'Backing up. Large folders take a while...', async () => {
    const r = await api('/api/backup/run', { method: 'POST', json: body() });
    setStatus(st, r.created ? `Backup ${r.snapshot} complete: ${counts(r.counts)}.` : r.message, true);
    fill(out);
    history_();
  }));

  const restore = (b) => formDialog({ title: `Restore ${b.name} (${b.snapshot})`, submit: 'Restore', fields: [
    { name: 'target', label: 'Restore into this folder', required: true, hint: 'Choose a new or empty folder. Nothing existing is deleted.' },
    { name: 'overwrite', label: 'Allow files that already exist there to be overwritten', type: 'checkbox' },
    { name: 'confirm', label: 'To overwrite, type OVERWRITE', hint: 'Only needed when overwriting.' }],
    save: (v) => api(`/api/backups/${b.id}/restore`, { method: 'POST', json: { target: v.target, overwrite: !!v.overwrite, confirm: v.confirm } }) }).then((r) => {
    if (r && r !== true) toast(`${r.restored} restored, ${r.already_identical} already identical` + (r.failed.length ? `, ${r.failed.length} failed: ${r.failed[0]}` : '.'), r.failed.length > 0);
  });
  const del = (b) => formDialog({ title: `Delete ${b.name} (${b.snapshot})`, submit: 'Delete this backup', fields: [{ name: 'confirm', label: 'Type DELETE to confirm', required: true, hint: 'This removes the backup copy only. The original files are never touched.' }],
    save: (v) => api(`/api/backups/${b.id}/delete`, { method: 'POST', json: { confirm: v.confirm } }) }).then((ok) => ok && history_());

  async function history_() {
    const { items } = await api('/api/backups');
    fill(hist, items.length ? dataTable(['Backup', 'Made', 'Files', 'Integrity', ''], items.map((b) => [h('div', {}, h('b', {}, b.name), h('span', { class: 'sub' }, `${b.snapshot}, from ${b.source}`)), b.created.replace('T', ' ').slice(0, 16), `${b.files} (${b.changed} changed), ${fmtBytes(b.bytes)}`,
      !b.present ? h('span', { class: 'bad' }, 'Copy not found') : b.verify_result ? h('span', { class: b.verify_result === 'ok' ? 'ok' : 'bad' }, b.verify_result === 'ok' ? `Verified ${b.verified_at.slice(0, 10)}` : b.verify_result) : h('span', { class: 'muted' }, 'Not verified'),
      b.present ? h('div', { class: 'actions' }, h('button', { class: 'btn sm', type: 'button', onclick: async () => { try { const r = await api(`/api/backups/${b.id}/verify`, { method: 'POST' }); toast(r.ok ? `All ${r.checked} files match their checksums.` : `Problems found: ${r.missing.length} missing, ${r.corrupted.length} corrupted.`, !r.ok); history_(); } catch (e) { toast(e.message, true); } } }, 'Verify'),
        h('button', { class: 'btn sm', type: 'button', onclick: () => restore(b) }, 'Restore'), b.removable ? h('button', { class: 'btn sm danger', type: 'button', onclick: () => del(b) }, 'Delete') : h('span', { class: 'muted small', title: 'A newer backup reuses its files' }, 'in use')) : null]))
      : h('p', { class: 'muted' }, 'No backups yet.'));
  }
  history_().catch((e) => fill(hist, h('p', { class: 'bad' }, e.message)));
})();
