(() => {
  const out = $('#ca-out'), st = $('#ca-st'), jsonBtn = $('#ca-json'), mdBtn = $('#ca-md');
  let data = null;
  const sevOrder = ['critical', 'high', 'medium', 'low'];
  const mdReport = (d) => d.results.map((r) => [`## ${r.name} (${r.format})`, '', ...(r.findings.length ? r.findings.map((f) => `- **${f.severity}** ${f.rule}${f.line ? ' (line ' + f.line + ')' : ''}${f.key ? ' key ' + f.key : ''}: ${f.detail} Fix: ${f.recommendation}`) : ['No problems found.']), ''].join('\n')).join('\n');

  $('#ca-run').addEventListener('click', () => runWith($('#ca-run'), st, 'Auditing...', async () => {
    const fd = new FormData();
    [...$('#ca-files').files].forEach((f) => fd.append('files', f));
    fd.append('pasted', $('#ca-pasted').value);
    fd.append('pasted_name', $('#ca-name').value);
    const d = data = await api('/api/config/audit', { method: 'POST', body: fd });
    setStatus(st, '');
    jsonBtn.disabled = mdBtn.disabled = false;
    fill(out, h('p', { class: 'muted small' }, d.note), d.results.map((r) => h('section', { class: 'out-block' },
      h('div', { class: 'detail-head' }, h('h2', {}, r.name), h('span', { class: 'badge' }, r.format), h('span', { class: 'badge' }, `${r.lines} lines`)),
      r.syntax.ok ? (r.syntax.message ? h('p', { class: 'muted small' }, r.syntax.message) : null) : findingsList([{ severity: 'warn', message: r.syntax.message }]),
      h('p', {}, sevOrder.map((s) => r.counts[s] ? `${r.counts[s]} ${s}` : null).filter(Boolean).join(', ') || 'No problems found.'),
      r.findings.length ? dataTable(['Severity', 'Problem', 'Where', 'Value', 'What to do'], r.findings.map((f) => [h('span', { class: 'badge ' + (f.severity === 'critical' || f.severity === 'high' ? 'bad' : f.severity === 'medium' ? 'warn' : '') }, f.severity),
        h('div', {}, h('b', {}, f.rule), h('span', { class: 'sub' }, f.detail)), (f.line ? `Line ${f.line}` : '') + (f.key ? ` ${f.key}` : ''), f.value ? h('code', { class: 'code-sm' }, f.value) : '', f.recommendation])) : null)));
  }));
  jsonBtn.addEventListener('click', () => download('config-audit.json', JSON.stringify(data, null, 2), 'application/json'));
  mdBtn.addEventListener('click', () => download('config-audit.md', mdReport(data), 'text/markdown'));
})();
