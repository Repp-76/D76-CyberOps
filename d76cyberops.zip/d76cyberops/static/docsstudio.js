(() => {
  const TEMPLATES = {
    'README': `# Project name

One sentence on what this does and who it is for.

## Install

\`\`\`
pip install -r requirements.txt
\`\`\`

## Use

Describe the most common task first.

## Configuration

| Setting | Default | Purpose |
|---|---|---|
| PORT | 8000 | Port to listen on |

## Security

Report problems as described in SECURITY.md.
`,
    'SECURITY.md': `# Security policy

## Supported versions

| Version | Supported |
|---|---|
| 1.x | Yes |

## Reporting a vulnerability

Email **security@example.com** with a description and steps to reproduce. Please do not open a public issue.

You can expect an acknowledgement within 3 working days and a status update within 10.

## Scope

Report problems in this project's code and its default configuration. Issues in third-party services are out of scope.

## Safe harbour

Good-faith research that follows this policy will not be pursued.
`,
    'Runbook': `# Runbook: service name

## Purpose

What this service does and who depends on it.

## Health checks

1. Open the status page.
2. Confirm the last deploy time.

## Common problems

### Symptom

- **Cause:** what usually triggers it
- **Fix:** the exact steps, in order

## Escalation

1. On-call engineer
2. Team lead
`,
    'Post-incident review': `# Post-incident review: short title

**Date:** YYYY-MM-DD  **Duration:** x hours  **Severity:** low / medium / high

## Summary

Two or three sentences a stranger could understand.

## Impact

Who was affected and how.

## Timeline (UTC)

- 00:00 First sign
- 00:00 Detected
- 00:00 Mitigated
- 00:00 Resolved

## Root cause

What actually went wrong, without blaming a person.

## What went well

## What went badly

## Actions

| Action | Owner | Due |
|---|---|---|
| | | |
`,
    'Changelog entry': `## 1.0.0 - YYYY-MM-DD

### Added

- 

### Changed

- 

### Fixed

- 

### Security

- 
`,
  };
  const input = $('#ds-in'), prev = $('#ds-prev'), tpl = $('#ds-tpl');
  fill(tpl, h('option', { value: '' }, 'Start from a template'), Object.keys(TEMPLATES).map((k) => h('option', { value: k }, k)));
  tabs($('#ds-tabs'), (k) => { $('#ds-md').hidden = k !== 'md'; $('#ds-sec').hidden = k !== 'sec'; });

  const render = () => {
    fill(prev, renderMarkdown(input.value));
    const words = (input.value.match(/\S+/g) || []).length;
    $('#ds-count').textContent = `${words.toLocaleString()} words`;
  };
  input.addEventListener('input', debounce(render, 120));
  tpl.addEventListener('change', () => {
    if (!tpl.value) return;
    if (input.value.trim() && !confirm('Replace the current text with this template?')) { tpl.value = ''; return; }
    input.value = TEMPLATES[tpl.value];
    tpl.value = '';
    render();
  });
  const title = () => ((input.value.match(/^#\s+(.+)$/m) || [])[1] || 'document').trim();
  const slug = () => title().toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 50) || 'document';

  $('#ds-md-dl').addEventListener('click', () => (input.value.trim() ? download(slug() + '.md', input.value, 'text/markdown') : toast('Write something first.', true)));
  $('#ds-html-dl').addEventListener('click', () => {
    if (!input.value.trim()) return toast('Write something first.', true);
    const esc = (t) => t.replace(/&/g, '&amp;').replace(/</g, '&lt;');
    const css = 'body{font:16px/1.6 system-ui,sans-serif;max-width:760px;margin:40px auto;padding:0 20px;color:#1a1f28}table{border-collapse:collapse}th,td{border:1px solid #d8dce3;padding:6px 10px;text-align:left}pre{background:#f3f4f6;padding:12px;overflow:auto}code{font-family:ui-monospace,Menlo,monospace}';
    download(slug() + '.html', `<!doctype html>\n<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>${esc(title())}</title><style>${css}</style></head><body>${prev.innerHTML}</body></html>`, 'text/html');
  });
  $('#ds-kb').addEventListener('click', () => {
    if (!input.value.trim()) return toast('Write something first.', true);
    formDialog({ title: 'Save to Knowledge Base', submit: 'Save article', values: { title: title() }, fields: [
      { name: 'title', label: 'Title', required: true, max: 200 },
      { name: 'category', label: 'Category', type: 'select', options: ['Cybersecurity', 'OSINT', 'Networking', 'Linux', 'Programming', 'Web Security', 'Digital Forensics', 'Developer Tools', 'Privacy', 'Security Awareness'].map((c) => [c, c]) },
      { name: 'tags', label: 'Tags', hint: 'Comma separated' }],
      save: async (v) => (await R.create('kb_articles', { ...v, body: input.value })).item,
    }).then((item) => item && toast('Saved. Find it in the Knowledge Base.'));
  });

  // ---- security.txt (RFC 9116)
  const nextYear = new Date(Date.now() + 364 * 86400000).toISOString().replace(/\.\d+Z$/, 'Z');
  const FIELDS = [
    { name: 'contact', label: 'Contact (one per line, required)', area: true, hint: 'mailto:security@example.com, https://example.com/report or tel:+60123456789', value: 'mailto:security@example.com' },
    { name: 'expires', label: 'Expires (required, ISO 8601 UTC)', value: nextYear, hint: 'Choose a date less than a year away and renew it.' },
    { name: 'encryption', label: 'Encryption key URL', hint: 'https:// link to your PGP key' },
    { name: 'acknowledgments', label: 'Acknowledgments page URL' },
    { name: 'policy', label: 'Disclosure policy URL' },
    { name: 'hiring', label: 'Security jobs URL' },
    { name: 'canonical', label: 'Canonical URL of this file', hint: 'For example https://example.com/.well-known/security.txt' },
    { name: 'preferred', label: 'Preferred languages', value: 'en, ms', hint: 'Comma separated language tags' },
  ];
  const secForm = $('#ss-form');
  fill(secForm, FIELDS.map((f) => {
    const id = 'ss-' + f.name;
    const input = f.area ? h('textarea', { id, rows: 3, class: 'mono', spellcheck: 'false' }) : h('input', { id, class: 'mono', autocomplete: 'off', spellcheck: 'false' });
    input.value = f.value || '';
    input.addEventListener('input', buildSec);
    return h('div', {}, h('label', { for: id }, f.label), input, f.hint ? h('small', { class: 'muted' }, f.hint) : null);
  }));
  const val = (n) => $('#ss-' + n).value.trim();
  function buildSec() {
    const lines = [], issues = [];
    const urls = (n, label) => val(n) && (/^https:\/\/\S+$/.test(val(n)) ? lines.push(`${label}: ${val(n)}`) : issues.push({ severity: 'bad', message: `${label} must be an https:// URL.` }));
    const contacts = val('contact').split('\n').map((l) => l.trim()).filter(Boolean);
    if (!contacts.length) issues.push({ severity: 'bad', message: 'At least one Contact is required.' });
    contacts.forEach((c) => (/^(mailto:\S+@\S+|https:\/\/\S+|tel:\+?[\d\s-]+)$/.test(c) ? lines.push(`Contact: ${c}`) : issues.push({ severity: 'bad', message: `Contact "${c}" must start with mailto:, https: or tel:.` })));
    const d = new Date(val('expires'));
    if (!val('expires') || Number.isNaN(d.getTime())) issues.push({ severity: 'bad', message: 'Expires must be a valid date and time, for example 2027-09-30T00:00:00Z.' });
    else {
      lines.push(`Expires: ${d.toISOString().replace(/\.\d+Z$/, 'Z')}`);
      if (d < new Date()) issues.push({ severity: 'bad', message: 'The expiry date is in the past.' });
      else if (d - Date.now() > 366 * 86400000) issues.push({ severity: 'warn', message: 'RFC 9116 recommends an expiry less than a year away.' });
    }
    urls('encryption', 'Encryption'); urls('acknowledgments', 'Acknowledgments'); urls('policy', 'Policy'); urls('hiring', 'Hiring'); urls('canonical', 'Canonical');
    if (val('preferred')) lines.push(`Preferred-Languages: ${val('preferred').split(',').map((x) => x.trim()).filter(Boolean).join(', ')}`);
    $('#ss-out').value = lines.join('\n') + (lines.length ? '\n' : '');
    fill($('#ss-findings'), issues.length ? findingsList(issues) : findingsList([{ severity: 'good', message: 'Valid against the required fields of RFC 9116.' }]));
    return !issues.some((i) => i.severity === 'bad');
  }
  $('#ss-dl').addEventListener('click', () => (buildSec() ? download('security.txt', $('#ss-out').value, 'text/plain') : toast('Fix the problems first.', true)));
  buildSec();
  render();
})();
