(() => {
  const TYPES = ['A', 'AAAA', 'MX', 'NS', 'TXT', 'CNAME', 'SOA', 'CAA'];
  const out = $('#dm-out'), st = $('#dm-st');
  let last = null;
  fill($('#dm-types'), TYPES.map((t) => h('label', { class: 'check' }, h('input', { type: 'checkbox', value: t, checked: true }), t)));

  const section = (title, ...kids) => h('section', { class: 'out-block' }, h('h2', {}, title), kids);
  const failed = (msg) => h('p', { class: 'bad' }, msg);

  function dnsView(d) {
    if (!d.ok) return failed(d.error);
    const rows = d.results.flatMap((r) => (r.records.length ? r.records.map((x) => [h('code', {}, x.type), h('code', { class: 'code-sm' }, x.data), String(x.ttl)])
      : [[h('code', {}, r.type), h('span', { class: r.status === 'empty' ? 'muted' : 'bad' }, r.status === 'empty' ? 'No records' : r.status === 'nxdomain' ? 'Name does not exist' : r.error || r.status), '']]));
    return h('div', {}, d.nxdomain ? h('p', { class: 'bad' }, 'The name does not exist (NXDOMAIN).') : null, dataTable(['Type', 'Value', 'TTL (s)'], rows),
      h('p', { class: 'muted small' }, 'Answered by ' + d.resolvers.join(', ')));
  }

  function tlsView(t) {
    if (!t.ok) return failed(t.error);
    const c = t.certificate;
    return h('div', {}, kvList([['Protocol', t.version], ['Cipher', t.cipher], ['Address', `${t.ip}:${t.port}`], ['Certificate verified', t.verified ? 'Yes' : 'No: ' + t.error]]),
      c ? h('div', {}, findingsList(c.findings), kvList([['Subject', c.subject], ['Issuer', c.issuer], ['Valid from', c.not_before], ['Valid until', c.not_after], ['Days left', c.days_left],
        ['Key', [c.public_key.algorithm, c.public_key.bits ? c.public_key.bits + ' bits' : '', c.public_key.curve || ''].filter(Boolean).join(', ')], ['Signature', c.signature_algorithm],
        ['Names', c.san.join('\n')], ['SHA-256 fingerprint', c.fingerprints.sha256]])) : h('p', { class: 'muted' }, t.certificate_error || 'No certificate details.'));
  }

  function httpView(x) {
    if (!x.ok) return failed(x.error);
    return h('div', {}, x.note ? h('p', { class: 'warn' }, x.note) : null,
      dataTable(['Step', 'URL', 'Status', 'Time', 'Address'], x.chain.map((c, i) => [String(i + 1), h('code', { class: 'code-sm' }, c.url), `${c.status} ${c.reason}`, c.ms + ' ms', c.ip])),
      x.final ? h('div', {}, h('h3', {}, 'Security headers on the final response'), dataTable(['Header', 'Present', 'Value'], x.final.security.map((s) => [h('code', {}, s.header), s.present ? h('span', { class: 'ok' }, 'Yes') : h('span', { class: 'warn' }, 'No'), s.value || ''])),
        h('details', {}, h('summary', {}, `All ${x.final.headers.length} response headers`), dataTable(['Name', 'Value'], x.final.headers.map(([k, v]) => [h('code', {}, k), h('code', { class: 'code-sm' }, v)])))) : null);
  }

  function show(r) {
    last = r;
    fill(out,
      h('div', { class: 'detail-head' }, h('h2', {}, r.target + (r.port ? ':' + r.port : '')), h('span', { class: 'badge' }, 'Taken ' + r.generated.replace('T', ' ') + ' UTC')),
      h('div', { class: 'actions' },
        h('button', { class: 'btn', type: 'button', onclick: () => download(`inspection-${r.target}.json`, JSON.stringify(r, null, 2), 'application/json') }, icon('download'), 'Export JSON'),
        r.dns && r.dns.ok ? h('button', { class: 'btn', type: 'button', onclick: exportCsv }, icon('download'), 'Export DNS CSV') : null,
        h('button', { class: 'btn', type: 'button', onclick: save }, icon('report'), 'Save for reports')),
      r.dns ? section('DNS records', dnsView(r.dns)) : null, r.tls ? section('TLS certificate', tlsView(r.tls)) : null,
      r.http ? section('HTTP', httpView(r.http)) : null,
      r.rdap ? section('Registration (RDAP)', r.rdap.ok ? kvList([['Registrar', r.rdap.registrar], ['Registered', r.rdap.registered], ['Expires', r.rdap.expires], ['Last changed', r.rdap.last_changed], ['Status', (r.rdap.status || []).join(', ')], ['Name servers', (r.rdap.nameservers || []).join('\n')]]) : failed(r.rdap.error)) : null);
  }

  function exportCsv() {
    const rows = [['type', 'value', 'ttl', 'queried_at']];
    last.dns.results.forEach((x) => x.records.forEach((rec) => rows.push([rec.type, rec.data, rec.ttl, last.generated])));
    download(`dns-${last.target}.csv`, toCsv(rows), 'text/csv');
  }
  async function save() {
    try { await R.create('saved_results', { kind: 'domain', title: `Domain: ${last.target} ${last.generated.slice(0, 10)}`, data: JSON.stringify(last) }); toast('Saved. Choose it in ReportGen.'); } catch (e) { toast(e.message, true); }
  }

  $('#dm-form').addEventListener('submit', (e) => {
    e.preventDefault();
    runWith($('#dm-run'), st, 'Inspecting (each check has its own timeout)...', async () => {
      const r = await api('/api/domain/inspect', { method: 'POST', json: { target: $('#dm-target').value, authorized: $('#dm-auth').checked, allow_private: $('#dm-private').checked,
        dns: $('#dm-dns').checked, tls: $('#dm-tls').checked, http: $('#dm-http').checked, rdap: $('#dm-rdap').checked, types: $$('#dm-types input:checked').map((i) => i.value) } });
      setStatus(st, '');
      show(r);
    });
  });
})();
