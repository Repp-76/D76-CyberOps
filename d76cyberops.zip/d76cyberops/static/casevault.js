(() => {
  const STATUS = [['open', 'Open'], ['in review', 'In review'], ['closed', 'Closed']];
  const EV_STATUS = [['collected', 'Collected'], ['in analysis', 'In analysis'], ['archived', 'Archived']];
  const list = $('#cv-list'), detail = $('#cv-detail'), q = $('#cv-q'), statusSel = $('#cv-status');
  const verifyInput = $('#cv-verify');
  let current = null, tab = 'overview', verifyTarget = null;

  const caseFields = [
    { name: 'title', label: 'Title', required: true, max: 200 },
    { name: 'investigator', label: 'Investigator or researcher', max: 120 },
    { name: 'status', label: 'Status', type: 'select', options: STATUS },
    { name: 'tags', label: 'Tags', hint: 'Comma separated' },
    { name: 'description', label: 'Description and scope', type: 'textarea', rows: 6 },
  ];
  const noteFields = [
    { name: 'title', label: 'Title', required: true, max: 200 },
    { name: 'body', label: 'Note', type: 'textarea', rows: 8 },
    { name: 'tags', label: 'Tags', hint: 'Comma separated' },
  ];
  const evidenceEdit = [
    { name: 'title', label: 'Title', required: true, max: 200 },
    { name: 'description', label: 'Description', type: 'textarea', rows: 3 },
    { name: 'file_ref', label: 'Location reference', hint: 'Where the original is kept, for example a path or storage label' },
    { name: 'collected_by', label: 'Collected by' },
    { name: 'status', label: 'Status', type: 'select', options: EV_STATUS },
    { name: 'tags', label: 'Tags', hint: 'Comma separated' },
  ];
  const evidenceNew = [
    evidenceEdit[0], evidenceEdit[1],
    { name: 'file', label: 'Evidence file', type: 'file', hint: 'The file is hashed on your own server and is not stored or changed.' },
    { name: 'sha256', label: 'Or a known SHA-256', hint: 'Use this when the file is not at hand. Ignored if a file is chosen.' },
    ...evidenceEdit.slice(2),
  ];

  async function loadList() {
    try {
      const { items } = await R.list('cases', { kind: 'case', q: q.value.trim(), status: statusSel.value });
      const rows = items.map((c) => h('li', {}, h('button', {
        type: 'button', class: 'item' + (current && current.id === c.id ? ' on' : ''), onclick: () => open(c.id),
      }, h('b', {}, c.title), h('small', {}, `${c.status}, updated ${fmtDate(c.updated)}`))));
      fill(list, ...(rows.length ? rows : [h('li', { class: 'muted pad' },
        q.value || statusSel.value ? 'No cases match these filters.' : 'No cases yet. Create the first one.')]));
    } catch (e) {
      fill(list, h('li', { class: 'bad pad' }, e.message));
    }
  }

  async function open(id, nextTab) {
    try {
      const [c, n, e] = await Promise.all([R.get('cases', id), R.list('notes', { case_id: id }), R.list('evidence', { case_id: id })]);
      current = { ...c.item, notes: n.items, evidence: e.items };
    } catch (err) {
      toast(err.message, true);
      return;
    }
    if (nextTab) tab = nextTab;
    history.replaceState(null, '', '#case=' + id);
    render();
    loadList();
  }

  function render() {
    const c = current;
    if (!c) {
      fill(detail, emptyState('Select a case', 'Pick a case from the list, or create a new one.'));
      return;
    }
    const tabs = [['overview', 'Overview'], ['evidence', `Evidence (${c.evidence.length})`], ['notes', `Notes (${c.notes.length})`]];
    fill(detail, 
      h('div', { class: 'detail-head' }, h('h2', {}, c.title), h('span', { class: 'badge' }, c.status)),
      h('div', { class: 'subtabs', role: 'tablist' }, tabs.map(([k, l]) =>
        h('button', { type: 'button', role: 'tab', 'aria-selected': String(tab === k), onclick: () => { tab = k; render(); } }, l))),
      tab === 'overview' ? overview(c) : tab === 'evidence' ? evidencePane(c) : notesPane(c));
  }

  const overview = (c) => h('div', {},
    h('ul', { class: 'kvlist' },
      h('li', {}, h('span', {}, 'Investigator'), h('b', {}, c.investigator || 'Not set')),
      h('li', {}, h('span', {}, 'Created'), h('b', {}, fmtDate(c.created))),
      h('li', {}, h('span', {}, 'Last updated'), h('b', {}, fmtDate(c.updated))),
      h('li', {}, h('span', {}, 'Tags'), h('b', {}, c.tags ? tagChips(c.tags) : 'None'))),
    h('h3', {}, 'Description and scope'),
    h('p', { class: 'prewrap' }, c.description || 'No description yet.'),
    h('div', { class: 'actions' },
      h('button', { class: 'btn', type: 'button', onclick: editCase }, 'Edit case'),
      [['md', 'Markdown'], ['html', 'HTML'], ['json', 'JSON']].map(([f, l]) =>
        h('a', { class: 'btn', href: `/api/cases/${c.id}/export?format=${f}`, download: '' }, icon('download'), `Export ${l}`)),
      h('button', { class: 'btn danger', type: 'button', onclick: deleteCase }, 'Delete case')));

  const newCase = () => formDialog({
    title: 'New case', fields: caseFields, submit: 'Create case',
    save: async (v) => (await R.create('cases', { ...v, kind: 'case' })).item,
  }).then((item) => item && open(item.id, 'overview'));

  const editCase = () => formDialog({
    title: 'Edit case', fields: caseFields, values: current,
    save: (v) => R.update('cases', current.id, v),
  }).then((ok) => ok && open(current.id));

  async function deleteCase() {
    if (!confirm(`Delete "${current.title}" with its notes and evidence records? This cannot be undone.`)) return;
    try {
      await R.remove('cases', current.id);
      current = null;
      history.replaceState(null, '', location.pathname);
      render();
      loadList();
    } catch (e) { toast(e.message, true); }
  }

  function evidencePane(c) {
    const add = h('button', { class: 'btn primary', type: 'button', onclick: addEvidence }, icon('upload'), 'Add evidence');
    if (!c.evidence.length) return h('div', {}, h('div', { class: 'actions' }, add),
      emptyState('No evidence recorded', 'Add a file to record its SHA-256, or enter a known hash.'));
    const rows = c.evidence.map((e) => {
      const check = !e.sha256 ? 'No hash stored' : e.last_result
        ? h('span', { class: e.last_result === 'match' ? 'ok' : 'bad' }, `${e.last_result === 'match' ? 'Verified' : 'Mismatch'} on ${fmtDate(e.last_check)}`)
        : 'Not checked yet';
      return h('tr', {},
        h('td', {}, h('b', {}, e.title), e.description ? h('span', { class: 'sub' }, e.description) : null, tagChips(e.tags)),
        h('td', {}, e.file_name || e.file_ref || 'None', e.file_name ? h('span', { class: 'sub' }, `${e.file_size.toLocaleString()} bytes`) : null),
        h('td', {}, e.sha256 ? [h('code', { class: 'digest' }, e.sha256.slice(0, 16) + '...'),
          h('button', { class: 'btn sm', type: 'button', onclick: () => copyText(e.sha256) }, 'Copy')] : 'None'),
        h('td', {}, e.status), h('td', {}, check),
        h('td', {}, h('div', { class: 'actions' },
          e.sha256 ? h('button', { class: 'btn sm', type: 'button', onclick: () => { verifyTarget = e; verifyInput.value = ''; verifyInput.click(); } }, 'Verify') : null,
          h('button', { class: 'btn sm', type: 'button', onclick: () => editEvidence(e) }, 'Edit'),
          h('button', { class: 'btn sm danger', type: 'button', onclick: () => removeEvidence(e) }, 'Delete'))));
    });
    return h('div', {}, h('div', { class: 'actions' }, add),
      h('div', { class: 'tablewrap' }, h('table', {},
        h('thead', {}, h('tr', {}, ['Evidence', 'File', 'SHA-256', 'Status', 'Integrity', 'Actions'].map((t) => h('th', { scope: 'col' }, t)))),
        h('tbody', {}, rows))));
  }

  const addEvidence = () => formDialog({
    title: 'Add evidence', fields: evidenceNew, submit: 'Add evidence',
    save: (v) => {
      const fd = new FormData();
      fd.append('case_id', current.id);
      for (const [k, val] of Object.entries(v)) {
        if (k === 'file') { if (val) fd.append('file', val); } else fd.append(k, val);
      }
      return api('/api/evidence', { method: 'POST', body: fd });
    },
  }).then((ok) => ok && open(current.id, 'evidence'));

  const editEvidence = (e) => formDialog({
    title: 'Edit evidence', fields: evidenceEdit, values: e,
    save: (v) => R.update('evidence', e.id, v),
  }).then((ok) => ok && open(current.id, 'evidence'));

  async function removeEvidence(e) {
    if (!confirm(`Delete the record "${e.title}"? The original file is not affected.`)) return;
    try { await R.remove('evidence', e.id); open(current.id, 'evidence'); } catch (err) { toast(err.message, true); }
  }

  verifyInput.addEventListener('change', async () => {
    if (!verifyInput.files[0] || !verifyTarget) return;
    const fd = new FormData();
    fd.append('file', verifyInput.files[0]);
    try {
      const r = await api(`/api/evidence/${verifyTarget.id}/verify`, { method: 'POST', body: fd });
      toast(r.match ? 'Integrity verified. The file matches the stored SHA-256.' : 'Integrity check failed. The file does not match the stored SHA-256.', !r.match);
      open(current.id, 'evidence');
    } catch (e) { toast(e.message, true); }
  });

  function notesPane(c) {
    const add = h('button', { class: 'btn primary', type: 'button', onclick: () => noteDialog() }, 'Add note');
    if (!c.notes.length) return h('div', {}, h('div', { class: 'actions' }, add), emptyState('No notes yet', 'Notes are kept with the case and included in exports.'));
    return h('div', {}, h('div', { class: 'actions' }, add), c.notes.map((n) => h('article', { class: 'entry' },
      h('h3', {}, n.title), h('small', {}, `Added ${fmtDate(n.created)}`), ' ', tagChips(n.tags),
      h('p', { class: 'prewrap' }, n.body),
      h('div', { class: 'actions' },
        h('button', { class: 'btn sm', type: 'button', onclick: () => noteDialog(n) }, 'Edit'),
        h('button', { class: 'btn sm danger', type: 'button', onclick: async () => {
          if (!confirm('Delete this note?')) return;
          try { await R.remove('notes', n.id); open(c.id, 'notes'); } catch (e) { toast(e.message, true); }
        } }, 'Delete')))));
  }

  const noteDialog = (n) => formDialog({
    title: n ? 'Edit note' : 'Add note', fields: noteFields, values: n || {},
    save: (v) => (n ? R.update('notes', n.id, v) : R.create('notes', { ...v, case_id: current.id })),
  }).then((ok) => ok && open(current.id, 'notes'));

  $('#cv-new').addEventListener('click', newCase);
  q.addEventListener('input', debounce(loadList));
  statusSel.addEventListener('change', loadList);
  render();
  loadList();
  const id = hashParams().get('case');
  if (id) open(Number(id));
})();
