// HOTP (RFC 4226) and TOTP (RFC 6238) on the Web Crypto API.
(function (g) {
  const B32 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
  const HASH = { SHA1: 'SHA-1', SHA256: 'SHA-256', SHA512: 'SHA-512' };

  function base32Decode(text) {
    let bits = 0, val = 0;
    const out = [];
    for (const c of text.replace(/[\s=-]/g, '').toUpperCase()) {
      const i = B32.indexOf(c);
      if (i < 0) throw new Error('The secret must be Base32 (letters A-Z and digits 2-7).');
      val = ((val << 5) | i) & 0xffff;
      bits += 5;
      if (bits >= 8) { out.push((val >>> (bits - 8)) & 255); bits -= 8; }
    }
    if (!out.length) throw new Error('Enter a secret.');
    return new Uint8Array(out);
  }

  function base32Encode(bytes) {
    let bits = 0, val = 0, out = '';
    for (const b of bytes) {
      val = (val << 8) | b; bits += 8;
      while (bits >= 5) { out += B32[(val >>> (bits - 5)) & 31]; bits -= 5; }
    }
    if (bits) out += B32[(val << (5 - bits)) & 31];
    return out;
  }

  async function hotp(secret, counter, digits = 6, alg = 'SHA1') {
    const key = await crypto.subtle.importKey('raw', secret, { name: 'HMAC', hash: HASH[alg] }, false, ['sign']);
    const msg = new ArrayBuffer(8);
    new DataView(msg).setBigUint64(0, BigInt(counter));
    const sig = new Uint8Array(await crypto.subtle.sign('HMAC', key, msg));
    const o = sig[sig.length - 1] & 15;
    const bin = ((sig[o] & 0x7f) << 24) | (sig[o + 1] << 16) | (sig[o + 2] << 8) | sig[o + 3];
    return String(bin % 10 ** digits).padStart(digits, '0');
  }

  const stepOf = (ms, period) => Math.floor(ms / 1000 / period);
  const totp = (secret, { time = Date.now(), period = 30, digits = 6, alg = 'SHA1' } = {}) => hotp(secret, stepOf(time, period), digits, alg);

  // Returns the offset (in steps or counters) at which the code matches, or null.
  async function verify(secret, code, { mode = 'totp', time = Date.now(), counter = 0, period = 30, digits = 6, alg = 'SHA1', window = 1 } = {}) {
    const base = mode === 'totp' ? stepOf(time, period) : counter;
    for (let d = 0; d <= window; d++) {
      for (const off of d === 0 ? [0] : [-d, d]) {
        if (base + off >= 0 && (await hotp(secret, base + off, digits, alg)) === code) return off;
      }
    }
    return null;
  }

  function parseUri(uri) {
    let u;
    try { u = new URL(uri.trim()); } catch { throw new Error('That is not a valid otpauth:// link.'); }
    if (u.protocol !== 'otpauth:' || !['totp', 'hotp'].includes(u.hostname)) throw new Error('Expected an otpauth://totp/... or otpauth://hotp/... link.');
    const q = u.searchParams, alg = (q.get('algorithm') || 'SHA1').toUpperCase();
    if (!HASH[alg]) throw new Error('Unsupported algorithm in the link.');
    return { mode: u.hostname, label: decodeURIComponent(u.pathname.replace(/^\//, '')), secret: q.get('secret') || '', issuer: q.get('issuer') || '',
      alg, digits: Number(q.get('digits') || 6), period: Number(q.get('period') || 30), counter: Number(q.get('counter') || 0) };
  }

  function buildUri({ mode, label, secret, issuer, alg, digits, period, counter }) {
    const p = new URLSearchParams({ secret, ...(issuer ? { issuer } : {}), algorithm: alg, digits: String(digits) });
    p.set(mode === 'totp' ? 'period' : 'counter', String(mode === 'totp' ? period : counter));
    return `otpauth://${mode}/${encodeURIComponent(label)}?${p}`;
  }

  g.OtpEngine = { base32Decode, base32Encode, hotp, totp, verify, parseUri, buildUri };
})(typeof window !== 'undefined' ? window : globalThis);
