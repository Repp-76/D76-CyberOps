(() => {
  const st = $('#nw-st'), monBtn = $('#nw-mon');
  let prev = null, active = false;
  const kindLabel = { tcp: 'TCP connect', http: 'HTTP', https: 'HTTPS', dns: 'DNS lookup', icmp: 'Ping' };
  const fields = (t) => [
    { name: 'name', label: 'Name', required: true, max: 100 },
    { name: 'kind', label: 'Check type', type: 'select', options: Object.entries(kindLabel) },
    { name: 'host', label: 'Host (a name or address you are authorized to monitor)', required: true, max: 253 },
    { name: 'port', label: 'Port (required for TCP; optional for HTTP)', type: 'number' },
    { name: 'path', label: 'Path for HTTP checks', default: '/' },
    { name: 'interval_sec', label: 'Check every (seconds)', type: 'number', default: 60 }, { name: 'timeout_sec', label: 'Timeout (seconds)', type: 'number', default: 5 },
    { name: 'alert_failures', label: 'Alert after this many failures in a row', type: 'number', default: 3 }, { name: 'alert_latency_ms', label: 'Alert when slower than (ms, 0 for never)', type: 'number', default: 0 },
    { name: 'allow_private', label: 'This is a local or lab target (allow private addresses)', type: 'checkbox' }, { name: 'enabled', label: 'Enabled', type: 'checkbox', default: 1 }];
  const send = (t) => (v) => (t ? api(`/api/watch/targets/${t.id}`, { method: 'PUT', json: v }) : api('/api/watch/targets', { method: 'POST', json: v }));
  const dialog = (t) => formDialog({ title: t ? 'Edit target' : 'Add a target', fields: fields(t), values: t || { kind: 'tcp', interval_sec: 60, timeout_sec: 5, alert_failures: 3, enabled: 1 }, save: send(t) }).then((ok) => ok && refresh());
  $('#nw-add').addEventListener('click', () => dialog());

  function spark(hist) {
    const ok = hist.filter((x) => x.ok && x.ms != null).map((x) => x.ms), max = Math.max(1, ...ok);
    return h('span', { class: 'hist', 'aria-hidden': 'true' }, hist.slice(-30).map((x) => { const i = h('i', { class: x.ok ? '' : 'f' }); if (x.ok) i.style.height = Math.max(8, ((x.ms || 0) / max) * 100) + '%'; return i; }));
  }

  function targets(list) {
    if (!list.length) return emptyState('Nothing is being watched', 'Add a host or service you are authorized to monitor.', h('button', { class: 'btn primary', type: 'button', onclick: () => dialog() }, 'Add a target'));
    return dataTable(['Target', 'Now', 'Availability (24 h)', 'Latency', 'Recent', ''], list.map((t) => {
      const s = t.stats, last = s.last, up = last ? !!last.ok : null;
      return [h('div', {}, h('b', {}, t.name), h('span', { class: 'sub' }, `${kindLabel[t.kind]} ${t.host}${t.port ? ':' + t.port : ''}${t.enabled ? '' : ' (disabled)'}`)),
        last ? h('span', {}, h('span', { class: 'statdot ' + (up ? 'up' : 'down') }), up ? 'Up' : 'Down', h('span', { class: 'sub' }, last.detail)) : h('span', { class: 'muted' }, 'No checks yet'),
        s.up_pct != null ? `${s.up_pct}% of ${s.checks}` : '', s.avg_ms != null ? `avg ${s.avg_ms} ms (${s.min_ms} to ${s.max_ms})` : '', spark(s.history),
        h('div', { class: 'actions' }, h('button', { class: 'btn sm', type: 'button', onclick: async () => { try { const r = await api(`/api/watch/targets/${t.id}/check`, { method: 'POST' }); toast(r.ok ? `${t.name}: ${r.detail}` : `${t.name} failed: ${r.detail}`, !r.ok); refresh(); } catch (e) { toast(e.message, true); } } }, 'Check now'),
          h('button', { class: 'btn sm', type: 'button', onclick: () => dialog(t) }, 'Edit'), h('button', { class: 'btn sm danger', type: 'button', onclick: async () => { if (confirm(`Remove "${t.name}" and its history?`)) { await R.remove('watch_targets', t.id).catch(() => api(`/api/watch/targets/${t.id}`, { method: 'DELETE' })); refresh(); } } }, 'Remove'))];
    }));
  }

  async function alerts() {
    const { items } = await R.list('watch_alerts');
    const names = Object.fromEntries((await api('/api/watch/overview')).targets.map((t) => [t.id, t.name]));
    fill($('#nw-alerts'), items.length ? items.slice(0, 20).map((a) => h('div', { class: 'alert-row' + (a.acknowledged ? ' done' : '') }, h('span', { class: 'badge ' + (a.kind === 'down' ? 'bad' : a.kind === 'slow' ? 'warn' : 'ok') }, a.kind),
      h('div', {}, a.message, h('span', { class: 'sub' }, `${names[a.target_id] || ''} at ${a.ts.replace('T', ' ').slice(0, 16)} UTC`)),
      a.acknowledged ? h('span', { class: 'muted small' }, 'Acknowledged') : h('button', { class: 'btn sm', type: 'button', onclick: async () => { await R.update('watch_alerts', a.id, { acknowledged: 1 }); refresh(); } }, 'Acknowledge'))) : h('p', { class: 'muted' }, 'No alerts.'));
  }

  const rate = (cur, old, key, dt) => (old ? fmtBytes(Math.max(0, (cur[key] - old[key]) / dt)) + '/s' : '');
  async function local() {
    const s = await api('/api/watch/local');
    const dt = prev ? s.ts - prev.ts : 0, old = prev ? Object.fromEntries((prev.interfaces || []).map((i) => [i.name, i])) : {};
    fill($('#nw-local'),
      kvList([['Host name', s.hostname], ['Default gateway', s.gateway ? `${s.gateway.gateway} on ${s.gateway.interface}` : null], ['DNS resolvers', (s.resolvers || []).join(', ') || 'none found'],
        ['TCP connections', s.tcp_states ? Object.entries(s.tcp_states).map(([k, v]) => `${k.toLowerCase()} ${v}`).join(', ') : null]]),
      s.interfaces ? dataTable(['Interface', 'Addresses', 'Received', 'Sent', 'Errors / drops'], s.interfaces.map((i) => [h('b', {}, i.name), (i.addrs || []).join(', ') || (i.state || ''), `${fmtBytes(i.rx_bytes)} ${dt ? rate(i, old[i.name], 'rx_bytes', dt) : ''}`, `${fmtBytes(i.tx_bytes)} ${dt ? rate(i, old[i.name], 'tx_bytes', dt) : ''}`,
        `${i.rx_errors + i.tx_errors} / ${i.rx_drops + i.tx_drops}`])) : h('p', { class: 'muted' }, 'Interface counters need Linux /proc, which is not available here.'));
    prev = s;
  }

  async function refresh() {
    try {
      const o = await api('/api/watch/overview');
      active = o.active;
      monBtn.textContent = active ? 'Stop monitoring' : 'Start monitoring';
      $('#nw-monst').textContent = active ? 'Monitoring runs in the background while D76 is running.' : 'Monitoring is off. Use Check now, or start it to check on each target\'s schedule.';
      fill($('#nw-targets'), targets(o.targets));
      await alerts();
      setStatus(st, '');
    } catch (e) { setStatus(st, e.message, false); }
  }
  monBtn.addEventListener('click', async () => { try { await api('/api/watch/monitor', { method: 'POST', json: { active: !active } }); refresh(); } catch (e) { toast(e.message, true); } });
  const tick = () => { if (!document.hidden) { refresh(); local().catch(() => {}); } };
  setInterval(tick, 5000);
  tick();
})();
