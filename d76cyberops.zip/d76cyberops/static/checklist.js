(() => {
  const sel = $('#ck-sel'), body = $('#ck-body'), actions = $('#ck-actions');
  const STATUS = [['unanswered', 'Not checked'], ['pass', 'Pass'], ['fail', 'Fail'], ['na', 'Not applicable']];
  let items = [], cats = [], list = [], cur = null, answers = {}, timer = null;

  const save = debounce(async () => {
    try { await R.update('checklists', cur.id, { answers: JSON.stringify(answers) }); $('#ck-saved').textContent = 'Saved'; } catch (e) { toast(e.message, true); }
  }, 600);
  const touch = () => { $('#ck-saved').textContent = 'Saving...'; save(); summary(); };

  function summary() {
    const c = { pass: 0, fail: 0, na: 0, unanswered: 0 };
    items.forEach((i) => { c[(answers[i.id] || {}).status || 'unanswered']++; });
    const app = c.pass + c.fail, pct = app ? Math.round((100 * c.pass) / app) : 0;
    const bar = $('#ck-bar');
    bar.style.width = pct + '%';
    $('#ck-sum').textContent = `${c.pass} passed, ${c.fail} failed, ${c.na} not applicable, ${c.unanswered} not checked. ` + (app ? `Score ${pct}% of answered applicable items.` : 'Answer some items to see a score.');
  }

  async function loadList(id) {
    list = (await R.list('checklists')).items;
    fill(sel, list.map((x) => h('option', { value: x.id }, x.name)));
    sel.disabled = !list.length;
    if (!list.length) { cur = null; return render(); }
    sel.value = id || (cur && list.some((x) => x.id === cur.id) ? cur.id : list[0].id);
    open(sel.value);
  }
  function open(id) {
    cur = list.find((x) => x.id === Number(id));
    try { answers = JSON.parse(cur.answers || '{}'); } catch { answers = {}; }
    history.replaceState(null, '', '#assessment=' + cur.id);
    render();
  }

  function itemRow(i) {
    const a = answers[i.id] || { status: 'unanswered', notes: '' };
    const select = h('select', { 'aria-label': 'Status of ' + i.title }, STATUS.map(([v, l]) => h('option', { value: v }, l)));
    select.value = a.status;
    const notes = h('input', { type: 'text', class: 'full', placeholder: 'Notes or evidence', 'aria-label': 'Notes for ' + i.title, maxlength: 2000 });
    notes.value = a.notes || '';
    const rec = h('p', { class: 'full muted small' });
    const upd = () => { rec.textContent = answers[i.id] && answers[i.id].status === 'fail' ? 'What to do: ' + i.recommendation : ''; };
    select.addEventListener('change', () => { answers[i.id] = { ...(answers[i.id] || {}), status: select.value, notes: notes.value }; upd(); touch(); });
    notes.addEventListener('input', () => { answers[i.id] = { ...(answers[i.id] || { status: 'unanswered' }), notes: notes.value }; touch(); });
    upd();
    return h('div', { class: 'ck-item' }, h('div', {}, h('b', {}, i.title), ' ', h('span', { class: 'badge ' + (i.severity === 'critical' || i.severity === 'high' ? 'bad' : i.severity === 'medium' ? 'warn' : '') }, i.severity),
      i.auto ? h('span', { class: 'badge' }, 'can be checked automatically') : null, a.source === 'auto' ? h('span', { class: 'badge ok' }, 'checked automatically') : null), select, notes, rec);
  }

  function render() {
    fill(actions);
    if (!cur) { fill(body, emptyState('No assessments yet', 'Create one for a site or project, then work through the checklist.', h('button', { class: 'btn primary', type: 'button', onclick: newOne }, 'New assessment'))); return; }
    fill(actions, h('button', { class: 'btn', type: 'button', onclick: autoDialog }, icon('globe'), 'Run automatic checks'),
      ['md', 'html', 'pdf', 'json'].map((fmt) => h('a', { class: 'btn', href: `/api/checklists/${cur.id}/report?format=${fmt}`, download: '' }, icon('download'), fmt === 'md' ? 'Markdown' : fmt.toUpperCase())),
      h('button', { class: 'btn', type: 'button', onclick: rename }, 'Rename'), h('button', { class: 'btn danger', type: 'button', onclick: remove }, 'Delete'));
    const bar = h('i', { class: 'ok', id: 'ck-bar' });
    fill(body, cur.target ? h('p', { class: 'muted' }, 'Target: ' + cur.target) : null,
      h('div', { class: 'progress' }, h('div', { class: 'meter' }, bar), h('span', { id: 'ck-sum' })), h('p', { class: 'muted small', id: 'ck-saved' }, ''),
      cats.map((c) => h('details', { class: 'ck-cat', open: true }, h('summary', {}, c, h('small', { class: 'muted' }, `  ${items.filter((i) => i.category === c).length} items`)), items.filter((i) => i.category === c).map(itemRow))));
    summary();
  }

  const fields = [{ name: 'name', label: 'Name', required: true, max: 120 }, { name: 'target', label: 'Site or project (for your notes, and the default for automatic checks)', max: 300 }];
  const newOne = () => formDialog({ title: 'New assessment', fields, submit: 'Create', save: async (v) => (await R.create('checklists', v)).item }).then((it) => it && loadList(it.id));
  const rename = () => formDialog({ title: 'Edit assessment', fields, values: cur, save: (v) => R.update('checklists', cur.id, v) }).then((ok) => ok && loadList(cur.id));
  async function remove() { if (confirm(`Delete "${cur.name}"? This cannot be undone.`)) { await R.remove('checklists', cur.id); cur = null; loadList(); } }

  const autoDialog = () => formDialog({ title: 'Run automatic checks', submit: 'Run checks', values: { target: cur.target }, fields: [
    { name: 'target', label: 'Site address', required: true, hint: 'Checks HTTP to HTTPS redirect, certificate, security headers and cookie flags on the home page.' },
    { name: 'authorized', label: 'I own this site or am authorized to test it', type: 'checkbox' }, { name: 'allow_private', label: 'It is a local or lab target', type: 'checkbox' }],
    save: async (v) => {
      const r = await api(`/api/checklists/${cur.id}/auto`, { method: 'POST', json: { target: v.target, authorized: !!v.authorized, allow_private: !!v.allow_private } });
      let n = 0;
      Object.entries(r.results).forEach(([id, x]) => { if (x.status !== 'na') { answers[id] = { status: x.status, notes: 'Automatic: ' + x.note, source: 'auto' }; n++; } else if (!answers[id]) answers[id] = { status: 'unanswered', notes: 'Automatic: ' + x.note }; });
      await R.update('checklists', cur.id, { answers: JSON.stringify(answers) });
      return n;
    } }).then((n) => { if (n !== null) { toast(`${n} item(s) filled in by automatic checks. Review them; they reflect only the home page.`); render(); } });

  sel.addEventListener('change', () => open(sel.value));
  $('#ck-new').addEventListener('click', newOne);
  api('/api/checklist/items').then((r) => { items = r.items; cats = r.categories; const id = Number(hashParams().get('assessment')); return loadList(id || undefined); }).catch((e) => toast(e.message, true));
})();
