(() => {
  const enc = new TextEncoder();
  const utf8 = new TextDecoder('utf-8', { fatal: true });

  const b64 = {
    encode(s) {
      let bin = '';
      enc.encode(s).forEach((b) => (bin += String.fromCharCode(b)));
      return btoa(bin);
    },
    decode(s) {
      try {
        const bin = atob(s.trim().replace(/-/g, '+').replace(/_/g, '/'));
        return utf8.decode(Uint8Array.from(bin, (c) => c.charCodeAt(0)));
      } catch {
        throw new Error('Input is not valid Base64, or it does not decode to UTF-8 text.');
      }
    },
  };
  const ENTITIES = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };

  const ops = {
    json: {
      format: (s) => JSON.stringify(JSON.parse(s), null, 2),
      minify: (s) => JSON.stringify(JSON.parse(s)),
      validate: (s) => {
        const v = JSON.parse(s);
        const kind = Array.isArray(v) ? `array of ${v.length}` : v === null ? 'null'
          : typeof v === 'object' ? `object with ${Object.keys(v).length} keys` : typeof v;
        return `Valid JSON: ${kind}.`;
      },
    },
    base64: { encode: b64.encode, decode: b64.decode },
    url: {
      encode: encodeURIComponent,
      decode: (s) => {
        try { return decodeURIComponent(s); } catch { throw new Error('Input contains a malformed percent sequence.'); }
      },
    },
    html: {
      encode: (s) => s.replace(/[&<>"']/g, (c) => ENTITIES[c]),
      decode: (s) => new DOMParser().parseFromString(s, 'text/html').documentElement.textContent,
    },
  };

  $$('[data-t][data-a]').forEach((btn) =>
    btn.addEventListener('click', () => {
      const { t, a } = btn.dataset;
      const st = $(`#${t}-st`), out = $(`#${t}-out`), value = $(`#${t}-in`).value;
      if (!value.trim()) return setStatus(st, 'Enter some input first.', false);
      try {
        out.value = ops[t][a](value);
        setStatus(st, a === 'validate' ? out.value : 'Done.', true);
      } catch (e) {
        out.value = '';
        setStatus(st, e.message, false);
      }
    })
  );

  // tabs
  const tabs = $$('[role=tab]'), panels = $$('.panel');
  function show(id) {
    tabs.forEach((t) => {
      const on = t.dataset.p === id;
      t.setAttribute('aria-selected', String(on));
      t.tabIndex = on ? 0 : -1;
    });
    panels.forEach((p) => (p.hidden = p.id !== 'p-' + id));
    history.replaceState(null, '', '#' + id);
  }
  tabs.forEach((t, i) => {
    t.addEventListener('click', () => show(t.dataset.p));
    t.addEventListener('keydown', (e) => {
      const step = { ArrowDown: 1, ArrowRight: 1, ArrowUp: -1, ArrowLeft: -1 }[e.key];
      if (!step) return;
      e.preventDefault();
      const next = tabs[(i + step + tabs.length) % tabs.length];
      next.focus();
      show(next.dataset.p);
    });
  });
  const start = location.hash.slice(1);
  show(tabs.some((t) => t.dataset.p === start) ? start : 'json');

  // hashes
  const hex = (buf) => [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');
  $('#hash-run').addEventListener('click', async () => {
    const st = $('#hash-st'), out = $('#hash-out');
    out.replaceChildren();
    if (!window.crypto || !crypto.subtle) return setStatus(st, 'Web Crypto is unavailable. Open D76 through localhost or HTTPS.', false);
    const bytes = enc.encode($('#hash-in').value);
    for (const algo of ['SHA-1', 'SHA-256', 'SHA-384', 'SHA-512']) {
      out.append(kvRow(algo, hex(await crypto.subtle.digest(algo, bytes))));
    }
    setStatus(st, `Hashed ${bytes.length} byte${bytes.length === 1 ? '' : 's'}.`, true);
  });

  // ids
  const uuid = () => crypto.randomUUID
    ? crypto.randomUUID()
    : ([1e7] + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, (c) =>
        (c ^ (crypto.getRandomValues(new Uint8Array(1))[0] & (15 >> (c / 4)))).toString(16));
  const SETS = {
    alnum: 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',
    hex: '0123456789abcdef',
    url: 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_',
    num: '0123456789',
  };
  function randomId(len, chars) {
    const limit = 256 - (256 % chars.length); // reject values that would bias the result
    const out = [];
    while (out.length < len) {
      for (const b of crypto.getRandomValues(new Uint8Array(len * 2))) {
        if (b < limit && out.length < len) out.push(chars[b % chars.length]);
      }
    }
    return out.join('');
  }
  const clamp = (el, lo, hi) => Math.min(hi, Math.max(lo, parseInt(el.value, 10) || lo));
  $('#uuid-run').addEventListener('click', () => {
    const out = $('#ids-out'), n = clamp($('#uuid-n'), 1, 100);
    out.replaceChildren(...Array.from({ length: n }, (_, i) => kvRow(`UUID ${i + 1}`, uuid())));
    setStatus($('#ids-st'), `Generated ${n} UUID v4 value${n === 1 ? '' : 's'}.`, true);
  });
  $('#rid-run').addEventListener('click', () => {
    const out = $('#ids-out'), len = clamp($('#rid-len'), 4, 128), n = clamp($('#rid-n'), 1, 50);
    const chars = SETS[$('#rid-set').value];
    out.replaceChildren(...Array.from({ length: n }, (_, i) => kvRow(`ID ${i + 1}`, randomId(len, chars))));
    setStatus($('#ids-st'), `Generated ${n} identifier${n === 1 ? '' : 's'} of ${len} characters.`, true);
  });

  // timestamps
  function convertTime() {
    const st = $('#time-st'), out = $('#time-out'), raw = $('#time-in').value.trim();
    out.replaceChildren();
    if (!raw) return setStatus(st, 'Enter a timestamp or a date.', false);
    let ms;
    if (/^-?\d+(\.\d+)?$/.test(raw)) {
      const n = Number(raw);
      ms = Math.abs(n) < 1e11 ? n * 1000 : n;
    } else {
      ms = Date.parse(raw);
    }
    const d = new Date(ms);
    if (Number.isNaN(d.getTime())) return setStatus(st, 'Could not read that as a timestamp or date.', false);
    out.append(
      kvRow('Unix seconds', String(Math.floor(ms / 1000))),
      kvRow('Unix milliseconds', String(Math.round(ms))),
      kvRow('ISO 8601 (UTC)', d.toISOString()),
      kvRow('Local time', d.toString())
    );
    setStatus(st, 'Converted.', true);
  }
  $('#time-run').addEventListener('click', convertTime);
  $('#time-in').addEventListener('keydown', (e) => e.key === 'Enter' && convertTime());
  $('#time-now').addEventListener('click', () => {
    $('#time-in').value = String(Date.now());
    convertTime();
  });

  // regex
  function runRegex() {
    const st = $('#rx-st'), hl = $('#rx-hl'), list = $('#rx-list');
    hl.replaceChildren();
    list.replaceChildren();
    const pattern = $('#rx-pat').value, flags = $('#rx-flags').value, text = $('#rx-text').value;
    if (!pattern) return setStatus(st, 'Enter a pattern to test.', false);
    let re;
    try {
      re = new RegExp(pattern, flags.includes('g') ? flags : flags + 'g');
    } catch (e) {
      return setStatus(st, e.message, false);
    }
    let last = 0, count = 0, m;
    while ((m = re.exec(text)) && count < 500) {
      count++;
      hl.append(text.slice(last, m.index));
      const mark = document.createElement('mark');
      mark.textContent = m[0];
      hl.append(mark);
      last = m.index + m[0].length;
      const li = document.createElement('li');
      const groups = m.slice(1).map((g, i) => `$${i + 1}=${g === undefined ? 'undefined' : JSON.stringify(g)}`).join('  ');
      li.textContent = `index ${m.index}: ${JSON.stringify(m[0])}${groups ? '  ' + groups : ''}`;
      list.append(li);
      if (m[0] === '') re.lastIndex++;
    }
    hl.append(text.slice(last));
    setStatus(st, count ? `${count}${count === 500 ? '+' : ''} match${count === 1 ? '' : 'es'}.` : 'No matches.', count > 0);
  }
  ['#rx-pat', '#rx-flags', '#rx-text'].forEach((s) => $(s).addEventListener('input', runRegex));

  // diff
  function diffLines(a, b) {
    const A = a.split('\n'), B = b.split('\n');
    const n = A.length, m = B.length;
    const L = Array.from({ length: n + 1 }, () => new Uint32Array(m + 1));
    for (let i = n - 1; i >= 0; i--)
      for (let j = m - 1; j >= 0; j--)
        L[i][j] = A[i] === B[j] ? L[i + 1][j + 1] + 1 : Math.max(L[i + 1][j], L[i][j + 1]);
    const out = [];
    let i = 0, j = 0;
    while (i < n && j < m) {
      if (A[i] === B[j]) { out.push([' ', A[i]]); i++; j++; }
      else if (L[i + 1][j] >= L[i][j + 1]) out.push(['-', A[i++]]);
      else out.push(['+', B[j++]]);
    }
    while (i < n) out.push(['-', A[i++]]);
    while (j < m) out.push(['+', B[j++]]);
    return out;
  }
  $('#diff-run').addEventListener('click', () => {
    const st = $('#diff-st'), out = $('#diff-out');
    out.replaceChildren();
    const a = $('#diff-a').value, b = $('#diff-b').value;
    if (a.split('\n').length * b.split('\n').length > 4e6) return setStatus(st, 'Inputs are too long for an in-browser diff (about 2,000 lines each).', false);
    const lines = diffLines(a, b);
    const added = lines.filter((l) => l[0] === '+').length, removed = lines.filter((l) => l[0] === '-').length;
    for (const [sign, text] of lines) {
      const row = document.createElement('div');
      row.className = sign === '+' ? 'add' : sign === '-' ? 'del' : '';
      row.textContent = `${sign} ${text}`;
      out.append(row);
    }
    setStatus(st, added || removed ? `${added} line${added === 1 ? '' : 's'} added, ${removed} removed.` : 'The two texts are identical.', true);
  });

  // color
  function hslToRgb(h, s, l) {
    s /= 100; l /= 100;
    const k = (n) => (n + h / 30) % 12, a = s * Math.min(l, 1 - l);
    const f = (n) => l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
    return [f(0), f(8), f(4)].map((x) => Math.round(x * 255));
  }
  function rgbToHsl([r, g, b]) {
    r /= 255; g /= 255; b /= 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b), d = max - min, l = (max + min) / 2;
    let h = 0, s = 0;
    if (d) {
      s = d / (1 - Math.abs(2 * l - 1));
      h = max === r ? ((g - b) / d) % 6 : max === g ? (b - r) / d + 2 : (r - g) / d + 4;
      h = (h * 60 + 360) % 360;
    }
    return [Math.round(h), Math.round(s * 100), Math.round(l * 100)];
  }
  function parseColor(raw) {
    const s = raw.trim().toLowerCase();
    let m = s.match(/^#?([0-9a-f]{3}|[0-9a-f]{6})$/);
    if (m) {
      const h = m[1].length === 3 ? [...m[1]].map((c) => c + c).join('') : m[1];
      return [0, 2, 4].map((i) => parseInt(h.slice(i, i + 2), 16));
    }
    m = s.match(/^rgb\(\s*(\d{1,3})\s*[, ]\s*(\d{1,3})\s*[, ]\s*(\d{1,3})\s*\)$/);
    if (m && m.slice(1).every((v) => +v <= 255)) return m.slice(1).map(Number);
    m = s.match(/^hsl\(\s*(\d{1,3})\s*[, ]\s*(\d{1,3})%\s*[, ]\s*(\d{1,3})%\s*\)$/);
    if (m && +m[1] <= 360 && +m[2] <= 100 && +m[3] <= 100) return hslToRgb(+m[1], +m[2], +m[3]);
    return null;
  }
  $('#color-in').addEventListener('input', () => {
    const st = $('#color-st'), out = $('#color-out'), sw = $('#color-sw');
    out.replaceChildren();
    sw.style.background = 'transparent';
    const value = $('#color-in').value;
    if (!value.trim()) return setStatus(st, '');
    const rgb = parseColor(value);
    if (!rgb) return setStatus(st, 'Not a recognised color. Use hex, rgb() or hsl().', false);
    const [h, s, l] = rgbToHsl(rgb);
    sw.style.background = `rgb(${rgb.join(',')})`;
    out.append(
      kvRow('Hex', '#' + rgb.map((v) => v.toString(16).padStart(2, '0')).join('')),
      kvRow('RGB', `rgb(${rgb.join(', ')})`),
      kvRow('HSL', `hsl(${h}, ${s}%, ${l}%)`)
    );
    setStatus(st, '');
  });
})();
