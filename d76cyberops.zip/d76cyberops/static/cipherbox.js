(() => {
  const st = $('#cb-st'), outWrap = $('#cb-outwrap'), out = $('#cb-out');
  let mode = 'text';
  tabs($('#cb-tabs'), (k) => { mode = k; $('#cb-text').hidden = k !== 'text'; $('#cb-file').hidden = k !== 'file'; outWrap.hidden = true; setStatus(st, ''); });

  const iterations = () => Number($('#cb-iter').value);
  const pass = () => $('#cb-pass').value;

  function checkEncrypt() {
    if (pass().length < 8) throw new Error('Use a passphrase of at least 8 characters; 14 or more is better.');
    if (pass() !== $('#cb-pass2').value) throw new Error('The two passphrases do not match.');
  }

  async function fileJob(encrypt) {
    const f = $('#cb-f').files[0];
    if (!f) throw new Error('Choose a file first.');
    if (f.size > 200 * 1024 * 1024) throw new Error('Files over 200 MB are not supported here.');
    const bytes = new Uint8Array(await f.arrayBuffer());
    if (encrypt) {
      checkEncrypt();
      const data = await CipherEngine.encryptBytes(bytes, pass(), iterations());
      download(f.name + '.d76enc', data, 'application/octet-stream');
      setStatus(st, `Encrypted ${f.name} (${fmtBytes(f.size)}). Keep the passphrase safe.`, true);
    } else {
      const data = await CipherEngine.decryptBytes(bytes, pass());
      download(f.name.replace(/\.d76enc$/i, '') || 'decrypted', data, 'application/octet-stream');
      setStatus(st, `Decrypted ${f.name}.`, true);
    }
  }

  async function textJob(encrypt) {
    const text = $('#cb-in').value;
    if (!text) throw new Error('Enter some text first.');
    let result;
    if (encrypt) { checkEncrypt(); result = await CipherEngine.encryptText(text, pass(), iterations()); } else result = await CipherEngine.decryptText(text, pass());
    out.value = result;
    outWrap.hidden = false;
    setStatus(st, encrypt ? 'Encrypted. Copy the block below; it contains everything needed except the passphrase.' : 'Decrypted.', true);
  }

  const job = (encrypt) => (mode === 'file' ? fileJob(encrypt) : textJob(encrypt));
  const go = (btn, encrypt) => runWith(btn, st, 'Working (key derivation takes a moment)...', () => job(encrypt));
  $('#cb-enc').addEventListener('click', () => go($('#cb-enc'), true));
  $('#cb-dec').addEventListener('click', () => go($('#cb-dec'), false));
})();
