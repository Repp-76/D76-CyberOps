(() => {
  const input = $('#fi-file'), out = $('#fi-out'), st = $('#fi-st');
  const hexBlock = (rows) => h('pre', { class: 'hex' }, rows.map((r) => `${r.offset}  ${r.hex.padEnd(47)}  ${r.ascii}`).join('\n'));

  function entropyChart(blocks) {
    return h('div', {}, h('div', { class: 'bars', role: 'img', 'aria-label': 'Entropy across the file' }, blocks.map((e) => {
      const bar = h('i', { class: e >= 7.5 ? 'vhi' : e >= 6.5 ? 'hi' : '', title: `${e} bits per byte` });
      bar.style.height = Math.max(2, (e / 8) * 100) + '%';
      return bar;
    })), h('p', { class: 'muted small' }, 'Start of file on the left, end on the right. Each bar is the randomness of one block, from 0 to 8 bits per byte.'));
  }

  function stringsPane(s) {
    const pane = h('div');
    const filter = h('input', { type: 'search', placeholder: 'Filter strings', 'aria-label': 'Filter strings' });
    let which = 'ascii';
    const paint = () => {
      const q = filter.value.toLowerCase();
      const list = s[which].filter((x) => !q || x.toLowerCase().includes(q));
      fill(pane, h('p', { class: 'muted small' }, `Showing ${list.length} of ${s[which + '_total']} found${s[which + '_total'] > s[which].length ? ' (the first ' + s[which].length + ' are kept)' : ''}.`),
        h('pre', { class: 'hex' }, list.join('\n') || 'None.'));
    };
    const bar = h('div', { class: 'subtabs', role: 'tablist' }, [['ascii', 'ASCII'], ['utf16', 'UTF-16']].map(([k, l]) =>
      h('button', { type: 'button', role: 'tab', 'aria-selected': String(k === which), onclick: (e) => { which = k; $$('button', bar).forEach((b) => b.setAttribute('aria-selected', String(b === e.target))); paint(); } }, `${l} (${s[k + '_total']})`)));
    filter.addEventListener('input', debounce(paint, 120));
    paint();
    return h('div', {}, bar, h('div', { class: 'filters' }, filter), pane);
  }

  function headers(r) {
    if (r.pe && !r.pe.error) return h('div', { class: 'out-block' }, h('h2', {}, 'Windows PE headers'),
      kvList([['Format', r.pe.format], ['Machine', r.pe.machine], ['Kind', r.pe.dll ? 'DLL' : r.pe.executable ? 'Executable' : 'Object'], ['Subsystem', r.pe.subsystem], ['Entry point (RVA)', r.pe.entry_point_rva], ['Compile timestamp', r.pe.timestamp]]),
      h('p', { class: 'muted small' }, r.pe.timestamp_note),
      r.pe.sections.length ? dataTable(['Section', 'Virtual size', 'Raw size', 'Flags', 'Entropy', 'Note'], r.pe.sections.map((s) => [h('code', {}, s.name), s.virtual_size, s.raw_size, s.flags, s.entropy, s.note])) : null);
    if (r.pe && r.pe.error) return h('p', { class: 'warn' }, r.pe.error);
    if (r.elf) return h('div', { class: 'out-block' }, h('h2', {}, 'ELF headers'), kvList([['Class', r.elf.class], ['Endianness', r.elf.endianness], ['Type', r.elf.type], ['Machine', r.elf.machine], ['Entry point', r.elf.entry_point]]));
    return null;
  }

  $('#fi-run').addEventListener('click', () => runWith($('#fi-run'), st, 'Inspecting...', async () => {
    const f = input.files[0];
    if (!f) throw new Error('Choose a file first.');
    const fd = new FormData();
    fd.append('file', f);
    const r = await api('/api/forensics/file', { method: 'POST', body: fd });
    setStatus(st, '');
    const ind = r.strings.interesting;
    fill(out,
      h('div', { class: 'detail-head' }, h('h2', {}, r.filename), h('span', { class: 'badge' }, fmtBytes(r.size))),
      kvList([['Detected type', r.type], ['Entropy', `${r.entropy} bits per byte`], ['Reading', r.entropy_reading]]),
      r.extension_note ? findingsList([{ severity: 'warn', message: r.extension_note }]) : null,
      h('p', { class: 'muted small' }, r.note),
      h('div', { class: 'out-block' }, h('h2', {}, 'Entropy'), entropyChart(r.entropy_blocks)),
      headers(r),
      (ind.urls.length || ind.emails.length || ind.ipv4.length) ? h('div', { class: 'out-block' }, h('h2', {}, 'Indicators in strings'),
        kvList([['URLs', ind.urls.join('\n')], ['Email addresses', ind.emails.join('\n')], ['IPv4 addresses', ind.ipv4.join('\n')]])) : null,
      h('div', { class: 'out-block' }, h('h2', {}, 'Strings'), stringsPane(r.strings)),
      h('div', { class: 'out-block' }, h('h2', {}, 'First 512 bytes'), hexBlock(r.hex_head)),
      r.hex_tail.length ? h('div', { class: 'out-block' }, h('h2', {}, 'Last 160 bytes'), hexBlock(r.hex_tail)) : null);
  }));
})();
