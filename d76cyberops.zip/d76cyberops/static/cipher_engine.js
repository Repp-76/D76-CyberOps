// AES-256-GCM with a PBKDF2-SHA256 key. Container: "D76C" | version | iterations | salt | iv | ciphertext+tag.
// The header is bound to the ciphertext as additional authenticated data.
(function (g) {
  const MAGIC = [0x44, 0x37, 0x36, 0x43], VERSION = 1, SALT = 16, IV = 12, HEADER = 4 + 1 + 4 + SALT;
  const enc = new TextEncoder();
  const dec = new TextDecoder('utf-8', { fatal: true });

  async function deriveKey(pass, salt, iterations) {
    const base = await crypto.subtle.importKey('raw', enc.encode(pass), 'PBKDF2', false, ['deriveKey']);
    return crypto.subtle.deriveKey({ name: 'PBKDF2', salt, iterations, hash: 'SHA-256' }, base, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
  }

  async function encryptBytes(bytes, pass, iterations = 600000) {
    if (!pass) throw new Error('Enter a passphrase.');
    const salt = crypto.getRandomValues(new Uint8Array(SALT));
    const iv = crypto.getRandomValues(new Uint8Array(IV));
    const header = new Uint8Array(HEADER);
    header.set(MAGIC, 0);
    header[4] = VERSION;
    new DataView(header.buffer).setUint32(5, iterations);
    header.set(salt, 9);
    const key = await deriveKey(pass, salt, iterations);
    const ct = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv, additionalData: header }, key, bytes));
    const out = new Uint8Array(HEADER + IV + ct.length);
    out.set(header, 0);
    out.set(iv, HEADER);
    out.set(ct, HEADER + IV);
    return out;
  }

  async function decryptBytes(data, pass) {
    if (data.length < HEADER + IV + 16 || MAGIC.some((b, i) => data[i] !== b)) throw new Error('This is not CipherBox data.');
    if (data[4] !== VERSION) throw new Error('This data was made by a newer version of CipherBox.');
    const iterations = new DataView(data.buffer, data.byteOffset, data.byteLength).getUint32(5);
    if (iterations < 100000 || iterations > 10000000) throw new Error('The data declares an unreasonable iteration count and was rejected.');
    if (!pass) throw new Error('Enter a passphrase.');
    const header = data.slice(0, HEADER), salt = data.slice(9, HEADER), iv = data.slice(HEADER, HEADER + IV), ct = data.slice(HEADER + IV);
    try {
      return new Uint8Array(await crypto.subtle.decrypt({ name: 'AES-GCM', iv, additionalData: header }, await deriveKey(pass, salt, iterations), ct));
    } catch {
      throw new Error('Wrong passphrase, or the data was changed or damaged.');
    }
  }

  const toB64 = (bytes) => { let s = ''; for (let i = 0; i < bytes.length; i += 8192) s += String.fromCharCode(...bytes.subarray(i, i + 8192)); return btoa(s); };
  const fromB64 = (text) => {
    try { return Uint8Array.from(atob(text.replace(/\s+/g, '')), (c) => c.charCodeAt(0)); } catch { throw new Error('That is not valid encrypted text.'); }
  };

  g.CipherEngine = {
    encryptBytes, decryptBytes,
    encryptText: async (text, pass, iter) => toB64(await encryptBytes(enc.encode(text), pass, iter)),
    decryptText: async (b64, pass) => dec.decode(await decryptBytes(fromB64(b64), pass)),
  };
})(typeof window !== 'undefined' ? window : globalThis);
