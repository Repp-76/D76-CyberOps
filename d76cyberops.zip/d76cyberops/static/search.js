(() => {
  const form = $('#sform'), q = $('#sq'), type = $('#stype');
  const status = $('#sstatus'), list = $('#sresults');

  async function run() {
    list.replaceChildren();
    setStatus(status, 'Searching...', true);
    try {
      const data = await api(`/api/search?q=${encodeURIComponent(q.value.trim())}&type=${type.value}`);
      if (!data.results.length) {
        setStatus(status, `No results for "${data.query}". Cases, notes and articles appear here once the tools that create them are installed.`, true);
        return;
      }
      setStatus(status, `${data.results.length} result${data.results.length === 1 ? '' : 's'}`, true);
      for (const r of data.results) {
        const li = document.createElement('li');
        const title = document.createElement(r.built ? 'a' : 'span');
        if (r.built) title.href = `/tools/${r.tool}#${r.param}=${r.ref}`;
        title.className = 'rt';
        title.textContent = r.title;
        const meta = document.createElement('small');
        meta.textContent = r.type;
        const ex = document.createElement('p');
        ex.textContent = r.excerpt || '';
        li.append(title, meta, ex);
        list.append(li);
      }
    } catch (e) {
      setStatus(status, e.message, false);
    }
  }

  form.addEventListener('submit', (e) => { e.preventDefault(); run(); });
  const initial = new URLSearchParams(location.search).get('q');
  if (initial) { q.value = initial; run(); }
})();
