// Line-based text transformations. Each step takes an array of lines and returns an array of lines.
(function (g) {
  const rx = (p, ignoreCase, flags = '') => new RegExp(p.pattern, flags + (ignoreCase ? 'i' : ''));
  const needPattern = (p) => { if (!p.pattern) throw new Error('Enter a pattern.'); };
  const num = (v, d) => { const n = parseInt(v, 10); return Number.isFinite(n) && n >= 0 ? n : d; };

  const STEPS = {
    trim: { label: 'Trim each line', params: [], run: (L) => L.map((l) => l.trim()) },
    remove_empty: { label: 'Remove empty lines', params: [], run: (L) => L.filter((l) => l.trim() !== '') },
    dedupe: { label: 'Remove duplicate lines', params: [{ name: 'ignore_case', type: 'checkbox', label: 'Ignore case' }],
      run: (L, p) => { const seen = new Set(); return L.filter((l) => { const k = p.ignore_case ? l.toLowerCase() : l; if (seen.has(k)) return false; seen.add(k); return true; }); } },
    sort: { label: 'Sort lines', params: [{ name: 'mode', type: 'select', options: [['asc', 'A to Z'], ['desc', 'Z to A'], ['numeric', 'Numeric'], ['length', 'By length']] }],
      run: (L, p) => {
        const a = [...L], cmp = (x, y) => x.localeCompare(y, undefined, { sensitivity: 'base', numeric: true });
        if (p.mode === 'desc') return a.sort((x, y) => cmp(y, x));
        if (p.mode === 'numeric') { const n = (s) => { const v = parseFloat(s); return Number.isNaN(v) ? Infinity : v; }; return a.sort((x, y) => n(x) - n(y) || cmp(x, y)); }
        if (p.mode === 'length') return a.sort((x, y) => x.length - y.length || cmp(x, y));
        return a.sort(cmp);
      } },
    reverse: { label: 'Reverse line order', params: [], run: (L) => [...L].reverse() },
    case: { label: 'Change case', params: [{ name: 'mode', type: 'select', options: [['lower', 'lowercase'], ['upper', 'UPPERCASE'], ['title', 'Title Case']] }],
      run: (L, p) => L.map((l) => (p.mode === 'upper' ? l.toUpperCase() : p.mode === 'title' ? l.toLowerCase().replace(/(^|[\s(-])(\p{L})/gu, (m, a, b) => a + b.toUpperCase()) : l.toLowerCase())) },
    replace: { label: 'Find and replace', params: [{ name: 'find', type: 'text', label: 'Find' }, { name: 'with', type: 'text', label: 'Replace with' },
      { name: 'regex', type: 'checkbox', label: 'Regex' }, { name: 'ignore_case', type: 'checkbox', label: 'Ignore case' }],
      run: (L, p) => {
        if (!p.find) throw new Error('Enter the text to find.');
        const re = new RegExp(p.regex ? p.find : p.find.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g' + (p.ignore_case ? 'i' : ''));
        const rep = p.regex ? (p.with || '') : (p.with || '').replace(/\$/g, '$$$$');
        return L.map((l) => l.replace(re, rep));
      } },
    keep_matching: { label: 'Keep lines matching', params: [{ name: 'pattern', type: 'text', label: 'Regex' }, { name: 'ignore_case', type: 'checkbox', label: 'Ignore case' }],
      run: (L, p) => { needPattern(p); const re = rx(p, p.ignore_case); return L.filter((l) => re.test(l)); } },
    remove_matching: { label: 'Remove lines matching', params: [{ name: 'pattern', type: 'text', label: 'Regex' }, { name: 'ignore_case', type: 'checkbox', label: 'Ignore case' }],
      run: (L, p) => { needPattern(p); const re = rx(p, p.ignore_case); return L.filter((l) => !re.test(l)); } },
    extract: { label: 'Extract matches', params: [{ name: 'pattern', type: 'text', label: 'Regex (group 1 is used if present)' }, { name: 'ignore_case', type: 'checkbox', label: 'Ignore case' }],
      run: (L, p) => { needPattern(p); const re = rx(p, p.ignore_case, 'g'); return L.flatMap((l) => [...l.matchAll(re)].map((m) => (m[1] !== undefined ? m[1] : m[0]))); } },
    prefix_suffix: { label: 'Add prefix or suffix', params: [{ name: 'prefix', type: 'text', label: 'Prefix' }, { name: 'suffix', type: 'text', label: 'Suffix' }],
      run: (L, p) => L.map((l) => (p.prefix || '') + l + (p.suffix || '')) },
    number_lines: { label: 'Number the lines', params: [{ name: 'start', type: 'number', label: 'Start at', default: 1 }],
      run: (L, p) => { const s = num(p.start, 1); return L.map((l, i) => `${s + i}. ${l}`); } },
    head: { label: 'Keep the first lines', params: [{ name: 'n', type: 'number', label: 'How many', default: 10 }], run: (L, p) => L.slice(0, num(p.n, 10)) },
    tail: { label: 'Keep the last lines', params: [{ name: 'n', type: 'number', label: 'How many', default: 10 }], run: (L, p) => { const n = num(p.n, 10); return n ? L.slice(-n) : []; } },
    split: { label: 'Split lines on a separator', params: [{ name: 'delimiter', type: 'text', label: 'Separator', default: ',' }],
      run: (L, p) => { if (!p.delimiter) throw new Error('Enter a separator.'); return L.flatMap((l) => l.split(p.delimiter)); } },
    join: { label: 'Join all lines into one', params: [{ name: 'delimiter', type: 'text', label: 'Separator', default: ', ' }], run: (L, p) => [L.join(p.delimiter ?? ', ')] },
    count_unique: { label: 'Count each distinct line', params: [],
      run: (L) => { const m = new Map(); L.forEach((l) => m.set(l, (m.get(l) || 0) + 1)); return [...m].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0])).map(([v, c]) => `${c}\t${v}`); } },
  };

  function run(text, steps) {
    if (text.length > 5000000) throw new Error('The input is larger than 5 MB.');
    let lines = text === '' ? [] : text.split(/\r?\n/);
    const trace = [];
    steps.forEach((s, i) => {
      const def = STEPS[s.type];
      if (!def) throw new Error(`Step ${i + 1}: unknown step type.`);
      try { lines = def.run(lines, s.params || {}); } catch (e) { throw new Error(`Step ${i + 1} (${def.label}): ${e.message}`); }
      trace.push(lines.length);
    });
    return { text: lines.join('\n'), lines: lines.length, trace };
  }

  g.PipeEngine = { STEPS, run };
})(typeof window !== 'undefined' ? window : globalThis);
