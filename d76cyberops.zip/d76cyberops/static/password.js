(() => {
  const COMMON = new Set(['password', '123456', '12345678', '123456789', 'qwerty', 'abc123', '111111', '123123',
    'admin', 'letmein', 'welcome', 'iloveyou', 'monkey', 'dragon', 'football', 'baseball', 'sunshine', 'princess',
    'login', 'passw0rd', 'master', 'hello', 'freedom', 'whatever', 'trustno1', '000000', 'qwerty123', '1q2w3e4r',
    'zaq12wsx', 'password1', 'admin123', 'changeme', 'secret', 'azerty', 'test', 'user', 'root', 'abcd1234',
    '1234', '12345', '1234567', '1234567890', 'sayang', 'malaysia', 'bismillah']);
  const RUNS = ['abcdefghijklmnopqrstuvwxyz', '0123456789', 'qwertyuiop', 'asdfghjkl', 'zxcvbnm']
    .flatMap((r) => [r, [...r].reverse().join('')]);
  const LEET = { '0': 'o', '1': 'l', '3': 'e', '4': 'a', '5': 's', '7': 't', '@': 'a', '$': 's', '!': 'i' };

  const pw = $('#pw'), meter = $('#meter'), bar = $('#meter-bar'), verdict = $('#verdict');
  const facts = $('#facts'), findings = $('#findings'), recs = $('#recs');

  function sequences(s) {
    const hits = [];
    let i = 0;
    while (i <= s.length - 4) {
      let best = 0;
      for (const run of RUNS) {
        if (!run.includes(s.slice(i, i + 4))) continue;
        let n = 4;
        while (i + n < s.length && run.includes(s.slice(i, i + n + 1))) n++;
        best = Math.max(best, n);
      }
      if (best) { hits.push(s.slice(i, i + best)); i += best; } else i++;
    }
    return hits;
  }

  function analyze(p) {
    const lower = p.toLowerCase();
    const classes = {
      lower: /[a-z]/.test(p), upper: /[A-Z]/.test(p), digit: /\d/.test(p), symbol: /[^A-Za-z0-9]/.test(p),
    };
    const pool = (classes.lower ? 26 : 0) + (classes.upper ? 26 : 0) + (classes.digit ? 10 : 0) + (classes.symbol ? 33 : 0);
    const out = [];
    const tips = new Set();
    let penalty = 0;

    if (p.length < 8) { out.push(['bad', `Only ${p.length} characters. Short passwords fall quickly to brute force.`]); tips.add('Use at least 12 characters; a passphrase of four or more unrelated words works well.'); }
    else if (p.length < 12) { out.push(['warn', `${p.length} characters is acceptable but not generous.`]); tips.add('Aim for 12 characters or more.'); }
    else out.push(['ok', `${p.length} characters.`]);

    const kinds = Object.values(classes).filter(Boolean).length;
    if (kinds < 3) { out.push(['warn', `Uses ${kinds} character type${kinds === 1 ? '' : 's'}.`]); tips.add('Mixing letters, digits and symbols helps, but length matters more than variety.'); }
    else out.push(['ok', `Uses ${kinds} character types.`]);

    const exact = COMMON.has(lower);
    if (exact) { out.push(['bad', 'This is one of the most commonly used passwords.']); tips.add('Never use a password that appears on common-password lists. Choose something unique.'); }
    else {
      const norm = [...lower].map((c) => LEET[c] || c).join('');
      const word = [...COMMON].find((w) => w.length >= 4 && /[a-z]/.test(w) && (lower.includes(w) || norm.includes(w)));
      if (word) { out.push(['bad', `Contains the common word "${word}", possibly with letter substitutions.`]); tips.add('Substituting characters such as a for @ is well known to cracking tools and adds little strength.'); penalty += word.length * 0.75; }
    }

    const reps = p.match(/(.)\1{2,}/g) || [];
    if (reps.length) { out.push(['warn', `Repeated characters: ${reps.map((r) => r.slice(0, 6)).join(', ')}.`]); tips.add('Avoid runs of the same character.'); penalty += reps.reduce((n, r) => n + r.length - 1, 0); }
    if (/^(.{1,6}?)\1+$/.test(p) && p.length > 3) { out.push(['bad', 'The whole password is a short block repeated.']); tips.add('Repeating a short pattern multiplies length without adding real strength.'); penalty += p.length / 2; }

    const seqs = sequences(lower);
    if (seqs.length) { out.push(['warn', `Sequential or keyboard-walk patterns: ${seqs.join(', ')}.`]); tips.add('Avoid sequences like abcd, 1234 and qwerty.'); penalty += seqs.reduce((n, s) => n + s.length * 0.75, 0); }

    if (/(?:19|20)\d{2}/.test(p)) { out.push(['warn', 'Contains what looks like a year.']); tips.add('Dates and years are among the first things guessed. Leave them out.'); penalty += 2; }

    const distinct = new Set(p).size;
    if (distinct < p.length / 3) { out.push(['warn', `Only ${distinct} distinct character${distinct === 1 ? '' : 's'} in ${p.length}.`]); penalty += 2; }

    const bits = Math.max(0, p.length - penalty) * Math.log2(pool || 2);
    let label, cls;
    if (exact || bits < 28) [label, cls] = ['Very weak', 'bad'];
    else if (bits < 36) [label, cls] = ['Weak', 'bad'];
    else if (bits < 60) [label, cls] = ['Fair', 'warn'];
    else if (bits < 80) [label, cls] = ['Strong', 'ok'];
    else [label, cls] = ['Very strong', 'ok'];

    if (!tips.size) tips.add('Store it in a password manager and use it for one account only.');
    return { length: p.length, kinds, pool, bits, label, cls, out, tips: [...tips] };
  }

  function fill(list, items, render) {
    list.replaceChildren();
    items.forEach((it) => list.append(render(it)));
  }

  function reset() {
    meter.setAttribute('aria-valuenow', '0');
    bar.style.width = '0';
    bar.className = '';
    verdict.textContent = 'Enter a password to see its analysis.';
    facts.replaceChildren();
    fill(findings, ['No password entered.'], (t) => Object.assign(document.createElement('li'), { textContent: t, className: 'muted' }));
    fill(recs, ['Recommendations appear once there is something to check.'], (t) => Object.assign(document.createElement('li'), { textContent: t, className: 'muted' }));
  }

  pw.addEventListener('input', () => {
    if (!pw.value) return reset();
    const r = analyze(pw.value);
    const pct = Math.min(100, Math.round((r.bits / 100) * 100));
    meter.setAttribute('aria-valuenow', String(pct));
    bar.style.width = pct + '%';
    bar.className = r.cls;
    verdict.textContent = `${r.label}. Estimated entropy about ${Math.round(r.bits)} bits.`;
    facts.replaceChildren();
    [['Length', r.length], ['Character types', `${r.kinds} of 4`], ['Character pool', r.pool]].forEach(([k, v]) => {
      const d = document.createElement('div');
      const dt = Object.assign(document.createElement('dt'), { textContent: k });
      const dd = Object.assign(document.createElement('dd'), { textContent: v });
      d.append(dt, dd);
      facts.append(d);
    });
    fill(findings, r.out, ([sev, text]) => Object.assign(document.createElement('li'), { textContent: text, className: sev }));
    fill(recs, r.tips, (t) => Object.assign(document.createElement('li'), { textContent: t }));
  });

  $('#pw-toggle').addEventListener('click', (e) => {
    const show = pw.type === 'password';
    pw.type = show ? 'text' : 'password';
    e.currentTarget.textContent = show ? 'Hide' : 'Show';
    e.currentTarget.setAttribute('aria-pressed', String(show));
  });
})();
