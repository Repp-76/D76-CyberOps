(() => {
  const el = (id) => $('#otp-' + id), st = el('st');
  let secret = null, timer = null;

  function settings() {
    return { mode: el('mode').value, alg: el('alg').value, digits: Number(el('digits').value), period: Math.max(5, Number(el('period').value) || 30), counter: Number(el('counter').value) || 0 };
  }

  function readSecret() {
    const raw = el('secret').value.trim();
    if (!raw) { secret = null; return false; }
    try {
      let text = raw;
      if (/^otpauth:/i.test(raw)) {
        const u = OtpEngine.parseUri(raw);
        el('mode').value = u.mode; el('alg').value = u.alg; el('digits').value = String(u.digits); el('period').value = u.period; el('counter').value = u.counter;
        text = u.secret;
        el('secret').value = u.secret;
      }
      secret = OtpEngine.base32Decode(text);
      setStatus(st, '');
      return true;
    } catch (e) { secret = null; setStatus(st, e.message, false); return false; }
  }

  async function tick() {
    const s = settings();
    el('counter-row').hidden = s.mode !== 'hotp';
    if (!secret) { el('code').textContent = '-'.repeat(s.digits); el('left').textContent = ''; el('bar').style.width = '0'; return; }
    const now = Date.now();
    el('code').textContent = await (s.mode === 'totp' ? OtpEngine.totp(secret, { time: now, ...s }) : OtpEngine.hotp(secret, s.counter, s.digits, s.alg));
    if (s.mode === 'totp') {
      const left = s.period - ((now / 1000) % s.period);
      el('left').textContent = `New code in ${Math.ceil(left)} s`;
      el('bar').style.width = `${(left / s.period) * 100}%`;
    } else { el('left').textContent = 'Counter-based codes change only when the counter does.'; el('bar').style.width = '100%'; }
  }

  function start() {
    clearInterval(timer);
    timer = setInterval(tick, 1000);
    tick();
  }
  document.addEventListener('visibilitychange', () => (document.hidden ? clearInterval(timer) : start()));

  el('secret').addEventListener('input', () => { readSecret(); tick(); });
  ['mode', 'alg', 'digits', 'period', 'counter'].forEach((k) => el(k).addEventListener('input', tick));

  el('new').addEventListener('click', () => {
    const bytes = crypto.getRandomValues(new Uint8Array(20));
    const s = settings();
    const b32 = OtpEngine.base32Encode(bytes);
    el('secret').value = b32;
    readSecret();
    el('uri').value = OtpEngine.buildUri({ ...s, label: 'D76:test-user', secret: b32, issuer: 'D76' });
    el('uri-wrap').hidden = false;
    tick();
  });

  el('verify').addEventListener('click', async () => {
    const vst = el('vst');
    if (!readSecret()) return setStatus(vst, 'Enter a secret first.', false);
    const code = el('check').value.replace(/\s/g, '');
    if (!/^\d+$/.test(code)) return setStatus(vst, 'Enter the digits of the code.', false);
    const s = settings();
    const off = await OtpEngine.verify(secret, code, { ...s, window: Number(el('window').value) });
    if (off === null) setStatus(vst, 'No match. The code is wrong, expired, or the clock or counter has drifted further than the window.', false);
    else setStatus(vst, off === 0 ? 'Valid for the current step.' : `Valid, but ${Math.abs(off)} step(s) ${off < 0 ? 'in the past' : 'ahead'}. The clock or counter is out of sync.`, true);
  });
  start();
})();
