(() => {
  const out = $('#mh-out'), st = $('#mh-st');
  const result = (name, v) => h('li', {}, h('span', {}, name), h('b', { class: v === 'pass' ? 'ok' : v === null ? 'muted' : 'bad' }, v || 'not found'));
  $('#mh-run').addEventListener('click', () => runWith($('#mh-run'), st, 'Analyzing...', async () => {
    const r = await api('/api/forensics/mail', { method: 'POST', json: { text: $('#mh-in').value } });
    setStatus(st, '');
    const s = r.summary;
    fill(out,
      h('h2', {}, 'Findings'), findingsList(r.findings),
      h('p', { class: 'muted small' }, r.note),
      h('h2', {}, 'Message'), kvList([['From', s.from], ['To', s.to], ['Subject', s.subject], ['Date', s.date], ['Message-ID', s.message_id], ['Return-Path', s.return_path], ['Reply-To', s.reply_to], ['Mailer', s.mailer],
        ['First public IP in the chain', r.first_public_ip]]),
      h('h2', {}, 'Authentication'), h('ul', { class: 'kvlist' }, result('SPF', r.authentication.spf), result('DKIM', r.authentication.dkim), result('DMARC', r.authentication.dmarc)),
      r.dkim_signatures.length ? h('p', { class: 'muted small' }, 'DKIM signed by: ' + r.dkim_signatures.map((d) => `${d.domain} (selector ${d.selector})`).join(', ')) : null,
      r.hops.length ? h('div', {}, h('h2', {}, `Route (${r.hops.length} hops, oldest first)`), r.hops.map((hop, i) => h('div', { class: 'hop' }, h('span', { class: 'n' }, String(i + 1)),
        h('div', {}, h('div', {}, h('b', {}, hop.from || 'unknown'), ' to ', h('b', {}, hop.by || 'unknown'), hop.with ? ` via ${hop.with}` : ''),
          h('div', { class: 'muted small' }, [hop.ips.length ? 'IP ' + hop.ips.join(', ') : '', hop.time || '', hop.delay_seconds != null ? `after ${hop.delay_seconds} s` : ''].filter(Boolean).join('  |  ')))))) : null);
  }));
})();
