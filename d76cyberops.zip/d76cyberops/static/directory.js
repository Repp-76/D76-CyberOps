(() => {
  const q = $('#dir-q'), count = $('#dir-count');
  const rows = $$('.dir-group li');
  function apply() {
    const term = q.value.trim().toLowerCase();
    let shown = 0;
    rows.forEach((li) => { const ok = !term || li.dataset.text.includes(term); li.hidden = !ok; if (ok) shown++; });
    $$('.dir-group').forEach((g) => { g.hidden = !$$('li', g).some((li) => !li.hidden); });
    $('#dir-empty').hidden = shown > 0;
    count.textContent = term ? `${shown} of ${rows.length}` : `${rows.length} tools`;
  }
  q.addEventListener('input', apply);
  apply();
})();
