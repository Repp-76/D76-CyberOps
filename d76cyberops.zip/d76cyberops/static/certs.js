(() => {
  const input = $('#ce-in'), out = $('#ce-out'), st = $('#ce-st');
  $('#ce-file').addEventListener('change', async (e) => {
    const f = e.target.files[0];
    if (f) input.value = await f.text();
    e.target.value = '';
  });
  const fp = (label, v) => h('li', {}, h('span', {}, label), h('b', { class: 'code-sm' }, v, ' ', h('button', { class: 'btn sm', type: 'button', onclick: () => copyText(v) }, 'Copy')));
  function block(b) {
    const key = b.public_key;
    return h('section', { class: 'out-block' }, h('h2', {}, b.kind),
      b.findings ? findingsList(b.findings) : null,
      kvList([['Subject', b.subject], ['Issuer', b.issuer], ['Serial number', b.serial], ['Valid from', b.not_before], ['Valid until', b.not_after],
        ['Signature algorithm', b.signature_algorithm],
        ['Public key', key ? [key.algorithm, key.bits ? key.bits + ' bits' : '', key.curve || ''].filter(Boolean).join(', ') : null]]),
      b.san && b.san.length ? h('div', {}, h('h3', {}, 'Subject alternative names'), h('ul', { class: 'plain' }, b.san.map((s) => h('li', {}, h('code', {}, s))))) : null,
      b.extensions && b.extensions.length ? h('div', {}, h('h3', {}, 'Extensions'),
        dataTable(['Extension', 'Critical', 'Value'], b.extensions.map((e) => [e.name, e.critical ? 'Yes' : 'No', (e.value || []).join('; ')]))) : null,
      b.fingerprints ? h('div', {}, h('h3', {}, 'Fingerprints'), h('ul', { class: 'kvlist' }, fp('SHA-256', b.fingerprints.sha256), fp('SHA-1', b.fingerprints.sha1))) : null);
  }
  $('#ce-run').addEventListener('click', () => runWith($('#ce-run'), st, 'Decoding...', async () => {
    const r = await api('/api/crypto/pem', { method: 'POST', json: { text: input.value } });
    setStatus(st, `${r.blocks.length} block${r.blocks.length === 1 ? '' : 's'} decoded.`, true);
    fill(out, r.blocks.map(block));
  }));
})();
