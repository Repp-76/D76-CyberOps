(() => {
  const input = $('#oa-in'), out = $('#oa-out'), st = $('#oa-st');
  $('#oa-file').addEventListener('change', async (e) => {
    const f = e.target.files[0];
    if (f) input.value = await f.text();
    e.target.value = '';
  });
  $('#oa-run').addEventListener('click', () => runWith($('#oa-run'), st, 'Reviewing...', async () => {
    const r = await api('/api/web/openapi', { method: 'POST', json: { text: input.value } });
    setStatus(st, '');
    const filter = h('input', { type: 'search', placeholder: 'Filter operations', 'aria-label': 'Filter operations' });
    const wrap = h('div');
    const paint = () => {
      const q = filter.value.trim().toLowerCase();
      const rows = r.operations.filter((o) => !q || `${o.method} ${o.path} ${o.summary} ${o.tags.join(' ')}`.toLowerCase().includes(q))
        .map((o) => [h('code', {}, o.method), h('code', { class: 'code-sm' }, o.path), h('span', { class: o.authenticated ? 'ok' : 'warn' }, o.authenticated ? 'Declared' : 'None declared'), o.summary]);
      fill(wrap, rows.length ? dataTable(['Method', 'Path', 'Authentication', 'Summary'], rows) : h('p', { class: 'muted' }, 'No operations match.'));
    };
    filter.addEventListener('input', debounce(paint, 120));
    paint();
    fill(out,
      kvList([['Title', r.title], ['Version', r.version], ['Specification', r.spec_version], ['Operations', r.summary.operations],
        ['Without a security requirement', r.summary.without_security], ['Servers', r.servers.join(', ')]]),
      h('p', { class: 'muted small' }, r.note),
      h('h2', {}, 'Findings'), findingsList(r.findings),
      r.security_schemes.length ? h('div', {}, h('h2', {}, 'Security schemes'), dataTable(['Name', 'Type', 'Detail'], r.security_schemes.map((s) => [s.name, s.type, s.scheme]))) : null,
      h('h2', {}, 'Operations'), h('div', { class: 'filters' }, filter), wrap);
  }));
})();
