(() => {
  const gate = $('#tm-gate'), main = $('#tm-main'), screen = $('#tm-screen'), input = $('#tm-input'), prompt = $('#tm-prompt');
  const stopBtn = $('#tm-stop'), goBtn = $('#tm-go');
  let cwd = '~', hist = [], hi = 0, ctrl = null;
  const MAX_NODES = 2000;

  function line(text, cls) {
    screen.append(h('div', { class: cls || null }, text));
    while (screen.childNodes.length > MAX_NODES) screen.firstChild.remove();
    screen.scrollTop = screen.scrollHeight;
  }
  const short = (p) => p;

  async function enter() {
    let s;
    try { s = await api('/api/terminal/status'); } catch (e) { fill(gate, h('div', { class: 'notice' }, icon('alert'), h('span', {}, e.message))); return; }
    cwd = s.cwd; prompt.textContent = short(cwd) + ' $';
    if (!s.available) { fill(gate, h('p', { class: 'bad' }, 'The terminal has been disabled by the server (D76_TERMINAL=0).')); main.hidden = true; return; }
    if (!s.enabled) {
      main.hidden = true;
      fill(gate, h('div', { class: 'block' }, h('h2', {}, 'The terminal is off'), h('p', {}, `Turning it on lets commands from your allowlist run as your user on ${s.platform}, from this browser, at localhost only. There is no shell, so redirects, chaining and background jobs do not work, and the allowlist applies to every command.`),
        h('div', { class: 'actions' }, h('button', { class: 'btn primary', type: 'button', onclick: async () => { await api('/api/terminal/enable', { method: 'POST', json: { enabled: true } }); enter(); } }, 'Turn the terminal on'))));
      return;
    }
    fill(gate);
    main.hidden = false;
    $('#tm-policy').value = JSON.stringify(s.policy, null, 2);
    if (!screen.childNodes.length) line('D76 terminal. Type help to see the commands that are allowed.', 'meta');
    input.focus();
  }

  async function run(command) {
    line(`${cwd} $ ${command}`, 'cmd');
    ctrl = new AbortController();
    stopBtn.hidden = false; goBtn.disabled = true;
    try {
      const res = await fetch('/api/terminal/run', { method: 'POST', headers: { 'X-CSRF-Token': csrf, 'Content-Type': 'application/json' }, body: JSON.stringify({ command }), signal: ctrl.signal });
      if (!res.ok) { const d = await res.json().catch(() => ({})); line(d.error || `Request failed (${res.status}).`, 'e'); return; }
      const reader = res.body.getReader(), dec = new TextDecoder();
      let buf = '', pending = null;
      const emit = (e) => {
        if (e.t === 'out' || e.t === 'err') {
          pending = (pending || '') + e.d;
          const parts = pending.split('\n'); pending = parts.pop();
          parts.forEach((p) => line(p, e.t === 'err' ? 'e' : null));
          if (pending !== null && e.t === 'err' && pending) { line(pending, 'e'); pending = null; }
        } else if (e.t === 'cwd') { cwd = e.cwd; prompt.textContent = short(cwd) + ' $'; }
        else if (e.t === 'exit') {
          if (pending) { line(pending); pending = null; }
          const note = [e.timeout ? 'stopped after the time limit' : null, e.truncated ? 'output limit reached' : null].filter(Boolean).join(', ');
          if (e.code !== 0 || note) line(`[exit ${e.code === null ? '?' : e.code}${e.ms ? `, ${e.ms} ms` : ''}${note ? ', ' + note : ''}]`, 'meta');
        }
      };
      for (;;) {
        const { value, done } = await reader.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        const lines = buf.split('\n'); buf = lines.pop();
        lines.filter(Boolean).forEach((l) => emit(JSON.parse(l)));
      }
      if (pending) line(pending);
    } catch (e) {
      line(e.name === 'AbortError' ? '[stopped]' : 'Connection problem: ' + e.message, e.name === 'AbortError' ? 'meta' : 'e');
    } finally { stopBtn.hidden = true; goBtn.disabled = false; ctrl = null; input.focus(); }
  }

  $('#tm-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const cmd = input.value.trim();
    if (!cmd) return;
    if (ctrl) { line('A command is still running. Wait for it, or press Stop.', 'meta'); return; }
    input.value = '';
    hist.push(cmd); hi = hist.length;
    if (cmd === 'clear') { fill(screen); return; }
    run(cmd);
  });
  input.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowUp' && hi > 0) { e.preventDefault(); input.value = hist[--hi]; }
    else if (e.key === 'ArrowDown') { e.preventDefault(); input.value = hi < hist.length - 1 ? hist[++hi] : ((hi = hist.length), ''); }
    else if (e.key === 'c' && e.ctrlKey && ctrl) ctrl.abort();
  });
  stopBtn.addEventListener('click', () => ctrl && ctrl.abort());
  $('#tm-save').addEventListener('click', async () => {
    try { const r = await api('/api/terminal/policy', { method: 'PUT', json: JSON.parse($('#tm-policy').value) }); $('#tm-policy').value = JSON.stringify(r.policy, null, 2); setStatus($('#tm-pst'), 'Policy saved.', true); }
    catch (e) { setStatus($('#tm-pst'), e instanceof SyntaxError ? 'That is not valid JSON.' : e.message, false); }
  });
  $('#tm-reset').addEventListener('click', async () => { if (confirm('Restore the default allowlist?')) { const r = await api('/api/terminal/policy/reset', { method: 'POST' }); $('#tm-policy').value = JSON.stringify(r.policy, null, 2); setStatus($('#tm-pst'), 'Defaults restored.', true); } });
  $('#tm-off').addEventListener('click', async () => { await api('/api/terminal/enable', { method: 'POST', json: { enabled: false } }); enter(); });
  enter();
})();
