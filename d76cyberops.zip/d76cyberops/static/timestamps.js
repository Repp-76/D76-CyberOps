(() => {
  const out = $('#ts-out'), st = $('#ts-st'), input = $('#ts-in');
  async function decode() {
    const r = await api('/api/forensics/timestamp', { method: 'POST', json: { value: input.value } });
    setStatus(st, '');
    if (r.mode === 'date') {
      fill(out, h('p', {}, 'Read as ', h('code', {}, r.interpretation), '. As each format:'),
        dataTable(['Format', 'Value'], r.encodings.map((e) => [e.format, h('code', {}, e.value, ' ', h('button', { class: 'btn sm', type: 'button', onclick: () => copyText(e.value) }, 'Copy'))])));
    } else {
      const rows = [...r.results].sort((a, b) => Number(b.plausible) - Number(a.plausible));
      fill(out, h('p', { class: 'muted small' }, r.note),
        dataTable(['Format', 'Date (UTC)', 'Plausible'], rows.map((e) => [e.format, e.utc ? h('code', { class: e.plausible ? '' : 'muted' }, e.utc) : h('span', { class: 'muted' }, 'out of range'),
          e.plausible ? h('span', { class: 'ok' }, 'Yes') : h('span', { class: 'muted' }, 'No')])));
    }
  }
  const go = () => runWith($('#ts-run'), st, 'Decoding...', decode);
  $('#ts-run').addEventListener('click', go);
  input.addEventListener('keydown', (e) => e.key === 'Enter' && go());
  $('#ts-now').addEventListener('click', () => { input.value = new Date().toISOString().replace(/\.\d+Z$/, 'Z'); go(); });
})();
