(() => {
  const TABS = {
    describe: { label: 'Network details', fields: [['value', 'Network or address', '192.168.10.77/26 or 2001:db8::/48']], action: 'describe', render: netDetails },
    split: { label: 'Split', fields: [['value', 'Network', '10.0.0.0/24'], ['prefix', 'New prefix length', '26']], action: 'split',
      render: (r) => [h('p', {}, `${r.parent} splits into ${r.count} subnets.`), dataTable(['Subnet', 'First host', 'Last host', 'Usable hosts'], r.subnets.map((s) => [h('code', {}, s.cidr), s.first_host, s.last_host, s.usable_hosts]))] },
    summarize: { label: 'Summarize', fields: [['value', 'CIDR blocks (separated by spaces, commas or lines)', '10.0.0.0/25 10.0.0.128/25 192.168.1.0/24']], area: true, action: 'summarize',
      render: (r) => [h('p', {}, `${r.input_count} block(s) merge into ${r.result.length}:`), h('ul', { class: 'plain' }, r.result.map((x) => h('li', {}, h('code', {}, x))))] },
    range: { label: 'Range to CIDR', fields: [['start', 'First address', '10.0.0.5'], ['end', 'Last address', '10.0.0.20']], action: 'range',
      render: (r) => [h('p', {}, 'The smallest set of blocks that covers the range exactly:'), h('ul', { class: 'plain' }, r.result.map((x) => h('li', {}, h('code', {}, x))))] },
    contains: { label: 'Membership', fields: [['value', 'Network', '10.0.0.0/8'], ['addresses', 'Addresses to test', '10.1.2.3 11.0.0.1']], area: 'addresses', action: 'contains',
      render: (r) => [h('p', {}, 'Against ' + r.network), dataTable(['Address', 'Result'], r.results.map((x) => [h('code', {}, x.address), x.inside === null ? h('span', { class: 'bad' }, x.error) : h('span', { class: x.inside ? 'ok' : 'muted' }, x.inside ? 'Inside' : 'Outside')]))] },
    ip: { label: 'Address formats', fields: [['value', 'IP address', '203.0.113.9']], action: 'ip', render: ipDetails },
  };
  const tabsEl = $('#sn-tabs'), form = $('#sn-form'), out = $('#sn-out'), st = $('#sn-st');
  let key = 'describe';

  function netDetails(r) {
    return [kvList([['Network', r.cidr], ['Netmask', r.netmask], ['Wildcard', r.wildcard], ['Broadcast', r.broadcast], ['First usable', r.first_host], ['Last usable', r.last_host],
      ['Total addresses', r.addresses], ['Usable hosts', r.usable_hosts], ['Scope', r.scope], ['Netmask in binary', r.netmask_binary]])];
  }
  function ipDetails(r) {
    return [kvList([['Address', r.address], ['Compressed', r.compressed], ['Exploded', r.exploded], ['Integer', r.integer], ['Hex', r.hex], ['Binary', r.binary],
      ['IPv4-mapped IPv6', r.ipv4_mapped_ipv6 || r.ipv4_mapped], ['Reverse DNS name', r.reverse_pointer],
      ['Private', r.private ? 'Yes' : 'No'], ['Globally routable', r.global ? 'Yes' : 'No'], ['Loopback', r.loopback ? 'Yes' : 'No'], ['Link-local', r.link_local ? 'Yes' : 'No'], ['Multicast', r.multicast ? 'Yes' : 'No']])];
  }

  function build() {
    const t = TABS[key];
    fill(form, t.fields.map(([name, label, ph]) => h('div', {}, h('label', { for: 'sn-' + name }, label),
      (t.area === true || t.area === name) ? h('textarea', { id: 'sn-' + name, rows: 3, class: 'mono', placeholder: ph, spellcheck: 'false' })
        : h('input', { id: 'sn-' + name, class: 'mono', placeholder: ph, autocomplete: 'off', spellcheck: 'false' }))),
      h('div', {}, h('button', { class: 'btn primary', type: 'submit' }, 'Calculate')));
    fill(out);
    setStatus(st, '');
  }
  fill(tabsEl, Object.entries(TABS).map(([k, t]) => h('button', { type: 'button', role: 'tab', 'data-k': k }, t.label)));
  tabs(tabsEl, (k) => { key = k; build(); });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const t = TABS[key], body = { action: t.action };
    t.fields.forEach(([name]) => { body[name] = $('#sn-' + name).value; });
    try {
      const r = await api('/api/net/subnet', { method: 'POST', json: body });
      setStatus(st, '');
      fill(out, t.render(r));
    } catch (err) { fill(out); setStatus(st, err.message, false); }
  });
})();
