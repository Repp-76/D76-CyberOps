(() => {
  const out = $('#jwt-out'), st = $('#jwt-st');
  $('#jwt-run').addEventListener('click', () => runWith($('#jwt-run'), st, 'Inspecting...', async () => {
    const r = await api('/api/web/jwt', { method: 'POST', json: { token: $('#jwt-in').value, secret: $('#jwt-secret').value } });
    setStatus(st, '');
    const sig = r.signature;
    fill(out,
      h('div', { class: 'out-block' }, h('h2', {}, 'Findings'), findingsList(r.findings)),
      h('div', { class: 'out-block' }, h('h2', {}, 'Signature'),
        h('p', { class: sig.verified === true ? 'ok' : sig.verified === false ? 'bad' : 'muted' },
          sig.message || (sig.present ? 'Present. Enter a secret to verify it (HS256, HS384 and HS512 only).' : 'This token has no signature.'))),
      r.claims.length ? h('div', { class: 'out-block' }, h('h2', {}, 'Claims'),
        dataTable(['Claim', 'Value', 'Time (UTC)'], r.claims.map((c) => [h('code', {}, c.claim), c.value, c.time || '']))) : null,
      h('div', { class: 'out-block' }, h('h2', {}, 'Header'), h('pre', { class: 'json' }, JSON.stringify(r.header, null, 2))),
      h('div', { class: 'out-block' }, h('h2', {}, 'Payload'), h('pre', { class: 'json' }, JSON.stringify(r.payload, null, 2))));
  }));
})();
