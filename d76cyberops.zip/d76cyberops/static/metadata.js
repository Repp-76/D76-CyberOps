(() => {
  const input = $('#md-file'), out = $('#md-out'), st = $('#md-st');
  $('#md-run').addEventListener('click', () => runWith($('#md-run'), st, 'Reading...', async () => {
    const f = input.files[0];
    if (!f) throw new Error('Choose a file first.');
    const fd = new FormData();
    fd.append('file', f);
    const r = await api('/api/forensics/metadata', { method: 'POST', body: fd });
    setStatus(st, '');
    const groups = {};
    r.items.forEach((i) => (groups[i.group] = groups[i.group] || []).push(i));
    fill(out,
      h('div', { class: 'detail-head' }, h('h2', {}, f.name), h('span', { class: 'badge' }, r.type), h('span', { class: 'badge' }, fmtBytes(f.size))),
      r.flags.length ? findingsList(r.flags.map((m) => ({ severity: 'warn', message: m }))) : h('p', { class: 'ok' }, r.note || 'No identifying metadata found.'),
      Object.entries(groups).map(([g, items]) => h('div', { class: 'out-block' }, h('h3', {}, g), kvList(items.map((i) => [i.key, i.value])))),
      r.strippable ? h('div', { class: 'actions' }, h('button', { class: 'btn primary', type: 'button', onclick: () => clean(f) }, icon('download'), 'Save a cleaned copy'),
        h('span', { class: 'muted small' }, 'Removes EXIF, IPTC, XMP and text chunks. The original file is not touched.'))
        : h('p', { class: 'muted' }, 'Cleaning is available for JPEG and PNG. For documents, remove properties with the application that created them (for example Inspect Document in Word).'));
  }));

  async function clean(f) {
    const fd = new FormData();
    fd.append('file', f);
    try {
      const res = await fetch('/api/forensics/metadata/clean', { method: 'POST', headers: { 'X-CSRF-Token': csrf }, body: fd });
      if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || 'Cleaning failed.');
      const name = (res.headers.get('Content-Disposition') || '').match(/filename="([^"]+)"/);
      download(name ? name[1] : 'clean-file', await res.blob(), 'application/octet-stream');
      toast('Cleaned copy saved.');
    } catch (e) { toast(e.message, true); }
  }
})();
