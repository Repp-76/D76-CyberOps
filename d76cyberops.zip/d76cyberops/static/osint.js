(() => {
  const KINDS = [['person', 'Person'], ['organization', 'Organization'], ['domain', 'Domain'], ['website', 'Website'],
    ['username', 'Username'], ['url', 'URL'], ['note', 'Note']];
  const kindLabel = Object.fromEntries(KINDS);
  const sel = $('#os-case'), body = $('#os-body'), actions = $('#os-actions');
  let cases = [], cur = null, entities = [], relations = [], tab = 'entities', selected = null;
  const filter = { q: '', kind: '', tag: '', bm: false };

  const caseFields = [
    { name: 'title', label: 'Research case title', required: true, max: 200 },
    { name: 'status', label: 'Status', type: 'select', options: [['open', 'Open'], ['in review', 'In review'], ['closed', 'Closed']] },
    { name: 'investigator', label: 'Researcher', max: 120 },
    { name: 'tags', label: 'Tags', hint: 'Comma separated' },
    { name: 'description', label: 'Question and scope', type: 'textarea', rows: 5, hint: 'What are you trying to find out, and what is off limits?' },
  ];
  const entityFields = [
    { name: 'kind', label: 'Type', type: 'select', options: KINDS },
    { name: 'label', label: 'Name or label', required: true, max: 300 },
    { name: 'value', label: 'Value', hint: 'Domain, username, URL or other identifier', max: 1000 },
    { name: 'source_url', label: 'Source URL', type: 'url', hint: 'Where this came from', max: 1000 },
    { name: 'evidence', label: 'Evidence reference', hint: 'For example a CaseVault record or archived copy', max: 1000 },
    { name: 'notes', label: 'Notes', type: 'textarea', rows: 5 },
    { name: 'tags', label: 'Tags', hint: 'Comma separated' },
    { name: 'bookmarked', label: 'Bookmark this entity', type: 'checkbox' },
  ];

  async function loadCases(selectId) {
    try { cases = (await R.list('cases', { kind: 'research' })).items; } catch (e) { toast(e.message, true); return; }
    fill(sel, ...cases.map((c) => h('option', { value: c.id }, c.title)));
    sel.disabled = !cases.length;
    if (!cases.length) { cur = null; render(); return; }
    const id = selectId || (cur && cases.some((c) => c.id === cur.id) ? cur.id : cases[0].id);
    sel.value = id;
    await openCase(id);
  }

  async function openCase(id) {
    try {
      const [e, r] = await Promise.all([R.list('entities', { case_id: id }), R.list('relations', { case_id: id })]);
      entities = e.items;
      relations = r.items;
    } catch (err) { toast(err.message, true); return; }
    cur = cases.find((c) => c.id === Number(id));
    selected = null;
    history.replaceState(null, '', '#case=' + id);
    render();
  }

  const reload = () => R.list('cases', { kind: 'research' }).then((r) => { cases = r.items; return openCase(cur.id); });

  function render() {
    fill(actions, );
    if (!cur) {
      fill(body, emptyState('No research cases yet', 'Create a case to start collecting entities and linking them together.',
        h('button', { class: 'btn primary', type: 'button', onclick: newCase }, 'New research case')));
      return;
    }
    fill(actions, 
      h('button', { class: 'btn', type: 'button', onclick: editCase }, 'Edit case'),
      [['md', 'Markdown'], ['html', 'HTML'], ['json', 'JSON']].map(([f, l]) =>
        h('a', { class: 'btn', href: `/api/cases/${cur.id}/export?format=${f}`, download: '' }, icon('download'), l)),
      h('button', { class: 'btn danger', type: 'button', onclick: deleteCase }, 'Delete case'));
    const tabs = [['entities', `Entities (${entities.length})`], ['map', 'Relationship map'], ['about', 'Case details']];
    fill(body, 
      h('div', { class: 'subtabs', role: 'tablist' }, tabs.map(([k, l]) =>
        h('button', { type: 'button', role: 'tab', 'aria-selected': String(tab === k), onclick: () => { tab = k; render(); } }, l))),
      tab === 'entities' ? entitiesPane() : tab === 'map' ? mapPane() : aboutPane());
  }

  const aboutPane = () => h('div', {},
    h('ul', { class: 'kvlist' },
      h('li', {}, h('span', {}, 'Status'), h('b', {}, cur.status)),
      h('li', {}, h('span', {}, 'Researcher'), h('b', {}, cur.investigator || 'Not set')),
      h('li', {}, h('span', {}, 'Created'), h('b', {}, fmtDate(cur.created))),
      h('li', {}, h('span', {}, 'Tags'), h('b', {}, cur.tags ? tagChips(cur.tags) : 'None'))),
    h('h3', {}, 'Question and scope'), h('p', { class: 'prewrap' }, cur.description || 'Not recorded.'));

  function entitiesPane() {
    const tags = [...new Set(entities.flatMap((e) => (e.tags ? e.tags.split(',') : [])))].sort();
    const wrap = h('div', { id: 'os-table' });
    const search = h('input', { type: 'search', placeholder: 'Filter entities', 'aria-label': 'Filter entities', value: filter.q });
    const kind = h('select', { 'aria-label': 'Filter by type' }, h('option', { value: '' }, 'All types'), KINDS.map(([v, l]) => h('option', { value: v }, l)));
    const tag = h('select', { 'aria-label': 'Filter by tag' }, h('option', { value: '' }, 'All tags'), tags.map((t) => h('option', { value: t }, t)));
    const bm = h('input', { type: 'checkbox', id: 'os-bm' });
    kind.value = filter.kind; tag.value = filter.tag; bm.checked = filter.bm;
    const refresh = () => { filter.q = search.value; filter.kind = kind.value; filter.tag = tag.value; filter.bm = bm.checked; fill(wrap, table()); };
    search.addEventListener('input', debounce(refresh, 120));
    [kind, tag, bm].forEach((el) => el.addEventListener('change', refresh));
    wrap.append(table());
    return h('div', {},
      h('div', { class: 'actions' },
        h('button', { class: 'btn primary', type: 'button', onclick: () => entityDialog() }, 'Add entity'),
        h('button', { class: 'btn', type: 'button', onclick: relationDialog }, 'Link two entities'),
        h('button', { class: 'btn', type: 'button', onclick: exportCsv }, icon('download'), 'Entities CSV')),
      h('div', { class: 'filters' }, search, kind, tag, h('div', { class: 'check' }, bm, h('label', { for: 'os-bm' }, 'Bookmarked only'))),
      wrap, relationList());
  }

  function table() {
    const q = filter.q.trim().toLowerCase();
    const rows = entities.filter((e) =>
      (!filter.kind || e.kind === filter.kind) && (!filter.bm || e.bookmarked) &&
      (!filter.tag || (e.tags || '').split(',').includes(filter.tag)) &&
      (!q || [e.label, e.value, e.notes, e.tags, e.source_url].join(' ').toLowerCase().includes(q)));
    if (!entities.length) return emptyState('No entities yet', 'Add the people, organizations, domains and accounts relevant to this case.');
    if (!rows.length) return h('p', { class: 'muted' }, 'No entities match the current filters.');
    return h('div', { class: 'tablewrap' }, h('table', {},
      h('thead', {}, h('tr', {}, ['Type', 'Entity', 'Source', 'Tags', 'Added', 'Actions'].map((t) => h('th', { scope: 'col' }, t)))),
      h('tbody', {}, rows.map((e) => h('tr', {},
        h('td', {}, kindLabel[e.kind] || e.kind),
        h('td', {}, h('b', {}, e.label), e.value ? h('span', { class: 'sub' }, e.value) : null,
          e.evidence ? h('span', { class: 'sub' }, 'Evidence: ' + e.evidence) : null),
        h('td', {}, sourceLink(e.source_url)), h('td', {}, tagChips(e.tags)), h('td', { class: 'num' }, fmtDate(e.created)),
        h('td', {}, h('div', { class: 'actions' },
          h('button', { class: 'btn sm', type: 'button', 'aria-pressed': String(!!e.bookmarked), onclick: async () => {
            try { await R.update('entities', e.id, { bookmarked: e.bookmarked ? 0 : 1 }); reload(); } catch (err) { toast(err.message, true); }
          } }, e.bookmarked ? 'Bookmarked' : 'Bookmark'),
          h('button', { class: 'btn sm', type: 'button', onclick: () => entityDialog(e) }, 'Edit'),
          h('button', { class: 'btn sm danger', type: 'button', onclick: () => removeEntity(e) }, 'Delete'))))))));
  }

  function sourceLink(url) {
    if (!url) return '';
    try { return h('a', { href: url, target: '_blank', rel: 'noopener noreferrer' }, new URL(url).hostname); } catch { return url; }
  }

  function relationList() {
    const name = Object.fromEntries(entities.map((e) => [e.id, e.label]));
    if (!relations.length) return h('div', {}, h('h3', {}, 'Relationships'), h('p', { class: 'muted' }, 'None yet. Use "Link two entities" to record how they connect.'));
    return h('div', {}, h('h3', {}, `Relationships (${relations.length})`), relations.map((r) => h('div', { class: 'rel' },
      h('b', {}, name[r.src] || '?'), h('em', {}, r.label || 'related to'), h('b', {}, name[r.dst] || '?'),
      h('button', { class: 'btn sm danger', type: 'button', onclick: async () => {
        try { await R.remove('relations', r.id); reload(); } catch (e) { toast(e.message, true); }
      } }, 'Remove'))));
  }

  function mapPane() {
    const nodes = entities.slice(0, 60);
    if (!nodes.length) return emptyState('Nothing to map yet', 'Add entities and link them to see the relationship map.');
    const W = 780, H = 540, cx = W / 2, cy = H / 2, r = Math.min(W, H) / 2 - 90;
    const pos = new Map(nodes.map((n, i) => {
      const a = (2 * Math.PI * i) / nodes.length - Math.PI / 2;
      return [n.id, { x: cx + r * Math.cos(a), y: cy + r * Math.sin(a), a }];
    }));
    const hot = (rel) => selected && (rel.src === selected || rel.dst === selected);
    const edges = relations.filter((rel) => pos.has(rel.src) && pos.has(rel.dst)).map((rel) => {
      const p = pos.get(rel.src), q = pos.get(rel.dst);
      return s('g', {}, s('line', { x1: p.x, y1: p.y, x2: q.x, y2: q.y, class: hot(rel) ? 'hot' : '' }),
        rel.label ? s('text', { x: (p.x + q.x) / 2, y: (p.y + q.y) / 2 - 4, class: 'elabel' }, rel.label) : null);
    });
    const shapes = nodes.map((n) => {
      const p = pos.get(n.id), cos = Math.cos(p.a);
      const label = n.label.length > 24 ? n.label.slice(0, 23) + '...' : n.label;
      return s('g', {
        class: 'node' + (selected === n.id ? ' sel' : ''), tabindex: 0, role: 'button', 'aria-label': `${kindLabel[n.kind]}: ${n.label}`,
        onclick: () => { selected = n.id; render(); },
        onkeydown: (ev) => { if (ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); selected = n.id; render(); } },
      }, s('circle', { cx: p.x, cy: p.y, r: 9, class: 'k-' + n.kind }),
        s('text', { x: p.x + Math.cos(p.a) * 16, y: p.y + Math.sin(p.a) * 16 + 4, class: 'nlabel',
          'text-anchor': Math.abs(cos) < 0.25 ? 'middle' : cos > 0 ? 'start' : 'end' }, label),
        s('title', {}, n.label));
    });
    const sel = entities.find((e) => e.id === selected);
    const name = Object.fromEntries(entities.map((e) => [e.id, e.label]));
    const links = relations.filter((rel) => hot(rel));
    return h('div', {},
      h('div', { class: 'legend' }, KINDS.map(([k, l]) => h('span', {}, s('svg', { width: 10, height: 10, 'aria-hidden': 'true' }, s('circle', { cx: 5, cy: 5, r: 5, class: 'k-' + k })), ' ', l))),
      s('svg', { viewBox: `0 0 ${W} ${H}`, class: 'graph', role: 'group', 'aria-label': 'Relationship map' }, edges, shapes),
      entities.length > 60 ? h('p', { class: 'muted' }, 'The map shows the first 60 entities.') : null,
      sel ? h('div', { class: 'entry' }, h('h3', {}, sel.label), h('small', {}, kindLabel[sel.kind]),
        sel.value ? h('p', {}, sel.value) : null, sel.notes ? h('p', { class: 'prewrap' }, sel.notes) : null,
        links.map((rel) => h('div', {}, `${name[rel.src]} - ${rel.label || 'related to'} - ${name[rel.dst]}`)))
        : h('p', { class: 'muted' }, 'Select an entity to see its details and highlight its links.'));
  }

  const newCase = () => formDialog({
    title: 'New research case', fields: caseFields, submit: 'Create case',
    save: async (v) => (await R.create('cases', { ...v, kind: 'research' })).item,
  }).then((item) => item && loadCases(item.id));

  const editCase = () => formDialog({
    title: 'Edit research case', fields: caseFields, values: cur, save: (v) => R.update('cases', cur.id, v),
  }).then((ok) => ok && loadCases(cur.id));

  async function deleteCase() {
    if (!confirm(`Delete "${cur.title}" with all of its entities and relationships? This cannot be undone.`)) return;
    try { await R.remove('cases', cur.id); cur = null; history.replaceState(null, '', location.pathname); loadCases(); } catch (e) { toast(e.message, true); }
  }

  const entityDialog = (e) => formDialog({
    title: e ? 'Edit entity' : 'Add entity', fields: entityFields, values: e || {},
    save: (v) => (e ? R.update('entities', e.id, v) : R.create('entities', { ...v, case_id: cur.id })),
  }).then((ok) => ok && reload());

  async function removeEntity(e) {
    if (!confirm(`Delete "${e.label}" and any relationships that involve it?`)) return;
    try { await R.remove('entities', e.id); reload(); } catch (err) { toast(err.message, true); }
  }

  function relationDialog() {
    if (entities.length < 2) return toast('Add at least two entities first.', true);
    const opts = entities.map((e) => [e.id, `${e.label} (${kindLabel[e.kind]})`]);
    formDialog({
      title: 'Link two entities', submit: 'Add relationship',
      fields: [
        { name: 'src', label: 'From', type: 'select', options: opts },
        { name: 'label', label: 'Relationship', hint: 'For example "owns", "registered by" or "works for"', max: 120 },
        { name: 'dst', label: 'To', type: 'select', options: opts, default: opts[1][0] },
      ],
      save: (v) => R.create('relations', { ...v, case_id: cur.id }),
    }).then((ok) => ok && reload());
  }

  function exportCsv() {
    const rows = [['type', 'label', 'value', 'source_url', 'evidence', 'tags', 'bookmarked', 'created']];
    entities.forEach((e) => rows.push([e.kind, e.label, e.value, e.source_url, e.evidence, e.tags, e.bookmarked ? 'yes' : 'no', e.created]));
    download(`${cur.title.replace(/[^a-z0-9]+/gi, '-').toLowerCase()}-entities.csv`, toCsv(rows), 'text/csv');
  }

  sel.addEventListener('change', () => openCase(sel.value));
  $('#os-new').addEventListener('click', newCase);
  const id = hashParams().get('case');
  loadCases(id ? Number(id) : undefined);
})();
