(() => {
  let mode = 'redact';
  tabs($('#rd-tabs'), (k) => { mode = k; $('#rd-redact').hidden = k !== 'redact'; $('#rd-urls').hidden = k !== 'urls'; });

  $('#rd-run').addEventListener('click', () => {
    const st = $('#rd-st'), text = $('#rd-in').value;
    if (!text.trim()) return setStatus(st, 'Enter some text first.', false);
    const enabled = $$('[data-d]').filter((c) => c.checked).map((c) => c.dataset.d);
    const r = RedactEngine.redact(text, enabled, $('#rd-words').value.split('\n'));
    $('#rd-out').value = r.text;
    $('#rd-outwrap').hidden = false;
    const names = { key: 'secrets', card: 'card numbers', ic: 'IC numbers', email: 'email addresses', phone: 'phone numbers', ip: 'IP addresses', words: 'listed words' };
    const parts = Object.entries(r.counts).filter(([, n]) => n).map(([k, n]) => `${n} ${names[k]}`);
    setStatus(st, r.total ? `Redacted ${parts.join(', ')}. Read the result before sharing; pattern matching can miss things.` : 'Nothing matched. That does not prove the text is free of personal data.', true);
  });

  $('#ru-run').addEventListener('click', () => {
    const st = $('#ru-st'), text = $('#ru-in').value;
    if (!text.trim()) return setStatus(st, 'Paste some links first.', false);
    const r = RedactEngine.cleanText(text, $('#ru-all').checked);
    $('#ru-out').value = r.text;
    $('#ru-outwrap').hidden = false;
    setStatus(st, r.links ? `Cleaned ${r.links} link(s) and removed ${r.params} parameter(s).` : 'No links found.', r.links > 0);
  });
})();
