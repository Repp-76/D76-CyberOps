// Pattern-based redaction and tracking-parameter removal. Pure functions; nothing leaves the browser.
(function (g) {
  const luhn = (digits) => { let sum = 0, alt = false; for (let i = digits.length - 1; i >= 0; i--) { let n = +digits[i]; if (alt && (n *= 2) > 9) n -= 9; sum += n; alt = !alt; } return sum % 10 === 0; };
  const daysIn = (m, y) => new Date(y, m, 0).getDate();
  const validDate = (yy, mm, dd) => mm >= 1 && mm <= 12 && dd >= 1 && (dd <= daysIn(mm, 1900 + yy) || dd <= daysIn(mm, 2000 + yy));

  const KEY_PATTERNS = [
    /AKIA[0-9A-Z]{16}/g, /gh[pousr]_[A-Za-z0-9]{36,}/g, /xox[baprs]-[A-Za-z0-9-]{10,}/g, /AIza[0-9A-Za-z_-]{35}/g, /sk_live_[0-9a-zA-Z]{20,}/g,
    /eyJ[\w-]{10,}\.[\w-]{10,}\.[\w-]{10,}/g, /-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]*?-----END [A-Z ]*PRIVATE KEY-----/g,
  ];
  const GENERIC_KEY = /\b((?:api[_-]?key|secret|token|passwd|password)\s*[:=]\s*['"]?)([A-Za-z0-9_\-/+=]{12,})/gi;

  const DETECTORS = {
    key: (t, c) => {
      KEY_PATTERNS.forEach((re) => { t = t.replace(re, () => { c.key++; return '[SECRET]'; }); });
      return t.replace(GENERIC_KEY, (m, label) => { c.key++; return label + '[SECRET]'; });
    },
    card: (t, c) => t.replace(/\b(?:\d[ -]?){12,18}\d\b/g, (m) => {
      const d = m.replace(/\D/g, '');
      if (d.length < 13 || d.length > 19 || !luhn(d)) return m;
      c.card++;
      return `[CARD ending ${d.slice(-4)}]`;
    }),
    ic: (t, c) => t.replace(/(?<![\d-])(\d{2})(\d{2})(\d{2})-?(\d{2})-?(\d{4})(?![\d-])/g, (m, yy, mm, dd) => {
      if (!validDate(+yy, +mm, +dd)) return m;
      c.ic++;
      return '[IC NUMBER]';
    }),
    email: (t, c) => t.replace(/[\w.+-]+@[\w-]+(?:\.[\w-]+)+/g, () => { c.email++; return '[EMAIL]'; }),
    phone: (t, c) => t.replace(/(?<![\w.])(?:\+?60|0)1\d[- ]?\d{3,4}[- ]?\d{4}(?!\d)|(?<![\w.])0[3-9][- ]?\d{7,8}(?!\d)|(?<![\w.])\+\d{1,3}[ -]?\(?\d{1,4}\)?[ -]?\d{3,4}[ -]?\d{3,4}(?!\d)/g, () => { c.phone++; return '[PHONE]'; }),
    ip: (t, c) => t.replace(/\b(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)\b/g, () => { c.ip++; return '[IP]'; }),
  };
  const ORDER = ['key', 'card', 'ic', 'email', 'phone', 'ip'];

  function redact(text, enabled, words = []) {
    const counts = { key: 0, card: 0, ic: 0, email: 0, phone: 0, ip: 0, words: 0 };
    for (const k of ORDER) if (enabled.includes(k)) text = DETECTORS[k](text, counts);
    for (const w of words.map((x) => x.trim()).filter(Boolean)) {
      const re = new RegExp('(?<![\\p{L}\\p{N}])' + w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '(?![\\p{L}\\p{N}])', 'giu');
      text = text.replace(re, () => { counts.words++; return '[REDACTED]'; });
    }
    return { text, counts, total: Object.values(counts).reduce((a, b) => a + b, 0) };
  }

  const TRACKERS = new Set(['fbclid', 'gclid', 'dclid', 'gbraid', 'wbraid', 'msclkid', 'mc_cid', 'mc_eid', 'igshid', 'yclid', 'twclid', 'ttclid',
    'li_fat_id', 'vero_id', 'mkt_tok', '_ga', '_gl', 'spm', 'scid', 'oly_enc_id', 'oly_anon_id', 'rb_clickid', 'ref_src', 'pk_campaign', 'pk_kwd', 'pk_source']);
  const isTracker = (name) => { const n = name.toLowerCase(); return TRACKERS.has(n) || n.startsWith('utm_') || n.startsWith('hsa_'); };

  function cleanUrl(raw, removeAll = false) {
    let u;
    try { u = new URL(raw); } catch { return null; }
    const removed = [];
    for (const k of [...u.searchParams.keys()]) {
      if (removeAll || isTracker(k)) { removed.push(k); u.searchParams.delete(k); }
    }
    return { url: u.toString(), removed };
  }

  function cleanText(text, removeAll = false) {
    let links = 0, params = 0;
    const out = text.replace(/https?:\/\/[^\s<>"']+/g, (m) => {
      const trail = (m.match(/[.,;:!?)]+$/) || [''])[0];
      const r = cleanUrl(m.slice(0, m.length - trail.length), removeAll);
      if (!r) return m;
      links++;
      params += r.removed.length;
      return r.url + trail;
    });
    return { text: out, links, params };
  }

  g.RedactEngine = { redact, cleanUrl, cleanText, luhn };
})(typeof window !== 'undefined' ? window : globalThis);
