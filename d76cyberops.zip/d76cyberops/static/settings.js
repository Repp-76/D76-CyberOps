$('#appearance').addEventListener('submit', async (e) => {
  e.preventDefault();
  try {
    const res = await api('/api/settings', {
      method: 'POST',
      json: { theme: $('#theme').value, debug: $('#debug').checked },
    });
    document.documentElement.dataset.theme = res.settings.theme;
    toast('Settings saved');
  } catch (err) {
    toast(err.message, true);
  }
});

$('#importForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const status = $('#importStatus');
  const fd = new FormData();
  fd.append('file', $('#importFile').files[0]);
  try {
    const res = await api('/api/import', { method: 'POST', body: fd });
    const total = Object.values(res.imported).reduce((a, b) => a + b, 0);
    setStatus(status, `Imported ${total} record${total === 1 ? '' : 's'}. Reload to see updated settings.`, true);
  } catch (err) {
    setStatus(status, err.message, false);
  }
});

$('#resetForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  try {
    await api('/api/reset', {
      method: 'POST',
      json: { confirm: $('#resetConfirm').value.trim(), scope: $('#resetScope').value },
    });
    toast('Data deleted');
    setTimeout(() => location.reload(), 600);
  } catch (err) {
    toast(err.message, true);
  }
});
