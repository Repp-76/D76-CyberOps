(() => {
  const LANGS = ['html', 'css', 'javascript', 'python', 'json', 'sql', 'bash', 'markdown', 'text'];
  const list = $('#sn-list'), detail = $('#sn-detail');
  const q = $('#sn-q'), langSel = $('#sn-lang'), catSel = $('#sn-cat'), fav = $('#sn-fav'), fileIn = $('#sn-file');
  let snippets = [], current = null;

  // Token rules for the built-in highlighter. Languages without rules are shown as plain text.
  const HL = {
    javascript: { c: /\/\/.*|\/\*[\s\S]*?\*\//, kw: 'const let var function return if else for while do class extends new import from export default async await try catch finally throw switch case break continue this typeof instanceof null true false undefined of in' },
    python: { c: /#.*/, kw: 'def class return if elif else for while import from as try except finally raise with lambda pass break continue None True False and or not in is yield async await global' },
    sql: { c: /--.*|\/\*[\s\S]*?\*\//, kw: 'select from where insert into values update set delete create table alter drop join left right inner outer on group by order having limit offset and or not null as distinct union index primary key foreign references', ci: true },
    bash: { c: /#.*/, kw: 'if then else elif fi for while do done case esac function in echo export cd ls grep sudo' },
    css: { c: /\/\*[\s\S]*?\*\// },
    json: { kw: 'true false null' },
    html: { c: /<!--[\s\S]*?-->/, tag: true },
  };

  function highlight(code, lang) {
    const spec = HL[lang], frag = document.createDocumentFragment();
    if (!spec) { frag.append(code); return frag; }
    const parts = [];
    if (spec.c) parts.push(`(?<c>${spec.c.source})`);
    if (spec.tag) parts.push('(?<t></?[A-Za-z][^>]*>)');
    else parts.push('(?<s>"(?:\\\\.|[^"\\\\])*"|\'(?:\\\\.|[^\'\\\\])*\'|`(?:\\\\.|[^`\\\\])*`)', '(?<n>\\b\\d+(?:\\.\\d+)?\\b)');
    if (spec.kw) parts.push(`(?<k>\\b(?:${spec.kw.split(' ').join('|')})\\b)`);
    const re = new RegExp(parts.join('|'), spec.ci ? 'gi' : 'g');
    let last = 0, m;
    while ((m = re.exec(code))) {
      if (m.index > last) frag.append(code.slice(last, m.index));
      const kind = Object.keys(m.groups).find((k) => m.groups[k] !== undefined);
      frag.append(h('span', { class: 'tk-' + kind }, m[0]));
      last = m.index + m[0].length;
    }
    frag.append(code.slice(last));
    return frag;
  }

  function detect(code) {
    const t = code.trim();
    if (!t) return 'text';
    if (/^[[{][\s\S]*[\]}]$/.test(t)) { try { JSON.parse(t); return 'json'; } catch { /* not JSON */ } }
    if (/^<!doctype html|^<html|<\/(div|p|body|head|span|a|ul|script|table)>/i.test(t)) return 'html';
    if (/^#!.*\b(ba|z)?sh\b|^\s*(sudo|apt|apt-get|cd|ls|echo|export|chmod|chown|grep|curl|git)\s/m.test(t)) return 'bash';
    if (/^\s*(select|insert\s+into|update|delete\s+from|create\s+table|alter\s+table)\b/im.test(t)) return 'sql';
    if (/\b(const|let|var)\s+\w+\s*=|=>|console\.|document\.|require\(|^import .+ from ['"]|\bfunction\b/m.test(t)) return 'javascript';
    if (/^\s*(def \w+|class \w+(\(.*\))?:|import \w+|from \w+ import|print\()/m.test(t)) return 'python';
    if (/[.#@]?[\w-]+\s*\{[^}]*:[^}]*\}/.test(t)) return 'css';
    if (/^#{1,6}\s|^\s*[-*]\s|\*\*.+\*\*/m.test(t)) return 'markdown';
    return 'text';
  }

  const fields = (existing) => [
    { name: 'title', label: 'Title', required: true, max: 200 },
    { name: 'language', label: 'Language', type: 'select', options: [['auto', 'Detect automatically'], ...LANGS.map((l) => [l, l])], default: existing ? existing.language : 'auto' },
    { name: 'category', label: 'Category', max: 60, hint: 'For example Recon, Utilities or Notes' },
    { name: 'tags', label: 'Tags', hint: 'Comma separated' },
    { name: 'body', label: 'Code', type: 'textarea', rows: 12, required: true },
  ];

  async function load() {
    try { snippets = (await R.list('snippets')).items; } catch (e) { fill(list, h('li', { class: 'bad pad' }, e.message)); return; }
    const langs = [...new Set(snippets.map((s) => s.language))].sort(), cats = [...new Set(snippets.map((s) => s.category).filter(Boolean))].sort();
    const keep = [langSel.value, catSel.value];
    fill(langSel, h('option', { value: '' }, 'All languages'), langs.map((l) => h('option', { value: l }, l)));
    fill(catSel, h('option', { value: '' }, 'All categories'), cats.map((c) => h('option', { value: c }, c)));
    langSel.value = langs.includes(keep[0]) ? keep[0] : '';
    catSel.value = cats.includes(keep[1]) ? keep[1] : '';
    paintList();
    if (current) { current = snippets.find((s) => s.id === current.id) || null; paintDetail(); }
  }

  function paintList() {
    const term = q.value.trim().toLowerCase();
    const rows = snippets.filter((s) => (!langSel.value || s.language === langSel.value) && (!catSel.value || s.category === catSel.value)
      && (!fav.checked || s.favorite) && (!term || [s.title, s.body, s.tags, s.category].join(' ').toLowerCase().includes(term)));
    fill(list, ...(rows.length ? rows.map((s) => h('li', {}, h('button', {
      type: 'button', class: 'item' + (current && current.id === s.id ? ' on' : ''), onclick: () => select(s.id),
    }, h('b', {}, (s.favorite ? 'Favorite: ' : '') + s.title), h('small', {}, [s.language, s.category].filter(Boolean).join(', '))))) :
      [h('li', { class: 'muted pad' }, snippets.length ? 'No snippets match these filters.' : 'No snippets yet. Create one or import a JSON file.')]));
  }

  function select(id) {
    current = snippets.find((s) => s.id === id) || null;
    history.replaceState(null, '', current ? '#snippet=' + id : location.pathname);
    paintList();
    paintDetail();
  }

  function paintDetail() {
    const s = current;
    if (!s) { fill(detail, emptyState('Select a snippet', 'Pick a snippet from the list, or create a new one.')); return; }
    fill(detail, 
      h('div', { class: 'detail-head' }, h('h2', {}, s.title), h('span', { class: 'badge' }, s.language), s.category ? h('span', { class: 'badge' }, s.category) : null),
      h('div', {}, tagChips(s.tags)),
      h('div', { class: 'actions' },
        h('button', { class: 'btn', type: 'button', onclick: () => copyText(s.body) }, icon('copy'), 'Copy code'),
        h('button', { class: 'btn', type: 'button', 'aria-pressed': String(!!s.favorite), onclick: async () => {
          try { await R.update('snippets', s.id, { favorite: s.favorite ? 0 : 1 }); load(); } catch (e) { toast(e.message, true); }
        } }, s.favorite ? 'Remove favorite' : 'Mark favorite'),
        h('button', { class: 'btn', type: 'button', onclick: () => dialog(s) }, 'Edit'),
        h('button', { class: 'btn danger', type: 'button', onclick: () => remove(s) }, 'Delete')),
      h('pre', { class: 'code' }, h('code', {}, highlight(s.body, s.language))),
      h('p', { class: 'muted small' }, `Updated ${fmtDate(s.updated)}. Snippets are never executed.`));
  }

  const dialog = (s) => formDialog({
    title: s ? 'Edit snippet' : 'New snippet', fields: fields(s), values: s || {},
    save: async (v) => {
      const body = { ...v, language: v.language === 'auto' ? detect(v.body) : v.language };
      return (s ? await R.update('snippets', s.id, body) : await R.create('snippets', body)).item;
    },
  }).then(async (item) => { if (item) { await load(); select(item.id); } });

  async function remove(s) {
    if (!confirm(`Delete "${s.title}"? This cannot be undone.`)) return;
    try { await R.remove('snippets', s.id); current = null; history.replaceState(null, '', location.pathname); await load(); paintDetail(); } catch (e) { toast(e.message, true); }
  }

  fileIn.addEventListener('change', async () => {
    const file = fileIn.files[0];
    fileIn.value = '';
    if (!file) return;
    let data;
    try { data = JSON.parse(await file.text()); } catch { return toast('That file is not valid JSON.', true); }
    if (!Array.isArray(data) || data.length > 500) return toast('Expected a JSON array of up to 500 snippets.', true);
    let ok = 0, bad = 0;
    for (const item of data) {
      const body = String(item.body ?? item.code ?? '');
      const lang = LANGS.includes(item.language) ? item.language : detect(body);
      try {
        await R.create('snippets', { title: item.title || 'Untitled', language: lang, body, tags: Array.isArray(item.tags) ? item.tags.join(',') : item.tags || '', category: item.category || '' });
        ok++;
      } catch { bad++; }
    }
    toast(`Imported ${ok} snippet${ok === 1 ? '' : 's'}${bad ? `, skipped ${bad} invalid` : ''}.`, !ok);
    load();
  });

  $('#sn-import').addEventListener('click', () => fileIn.click());
  $('#sn-json').addEventListener('click', () => snippets.length
    ? download('codevault-snippets.json', JSON.stringify(snippets.map(({ title, language, category, tags, body, favorite }) => ({ title, language, category, tags, body, favorite })), null, 2), 'application/json')
    : toast('There are no snippets to export.', true));
  $('#sn-md').addEventListener('click', () => snippets.length
    ? download('codevault-snippets.md', snippets.map((s) => `## ${s.title}\n\n*${s.language}${s.category ? ', ' + s.category : ''}${s.tags ? ', tags: ' + s.tags : ''}*\n\n\`\`\`${s.language}\n${s.body}\n\`\`\`\n`).join('\n'), 'text/markdown')
    : toast('There are no snippets to export.', true));
  $('#sn-new').addEventListener('click', () => dialog());
  q.addEventListener('input', debounce(paintList, 120));
  [langSel, catSel, fav].forEach((el) => el.addEventListener('change', paintList));
  paintDetail();
  load().then(() => { const id = hashParams().get('snippet'); if (id) select(Number(id)); });
})();
