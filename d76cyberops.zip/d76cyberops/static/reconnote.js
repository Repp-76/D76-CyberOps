(() => {
  const list = $('#rn-list'), detail = $('#rn-detail'), q = $('#rn-q');
  let notes = [], current = null;

  const SECTIONS = [['scope', 'Scope'], ['authorization', 'Authorization reference'], ['observations', 'Observations'],
    ['urls', 'URLs'], ['dns', 'DNS findings'], ['tech', 'Technology observations'],
    ['files', 'Screenshots and file references'], ['notes', 'Other notes']];
  const fields = [
    { name: 'target', label: 'Target', required: true, max: 300, hint: 'Domain, host, application or system name' },
    { name: 'assessed_on', label: 'Assessment date', type: 'date' },
    { name: 'scope', label: 'Scope', type: 'textarea', rows: 3, required: true, hint: 'What is in scope and what is not' },
    { name: 'authorization', label: 'Authorization reference', required: true, max: 500, hint: 'Who approved this work, and where that is recorded. Assess only systems you own or have permission to test.' },
    { name: 'observations', label: 'Observations', type: 'textarea', rows: 6 },
    { name: 'urls', label: 'URLs', type: 'textarea', rows: 3, hint: 'One per line' },
    { name: 'dns', label: 'DNS findings', type: 'textarea', rows: 3 },
    { name: 'tech', label: 'Technology observations', type: 'textarea', rows: 3 },
    { name: 'files', label: 'Screenshots and file references', type: 'textarea', rows: 2, hint: 'File names or storage locations, not the files themselves' },
    { name: 'notes', label: 'Other notes', type: 'textarea', rows: 3 },
  ];

  async function load() {
    try { notes = (await R.list('recon')).items; } catch (e) { fill(list, h('li', { class: 'bad pad' }, e.message)); return; }
    paintList();
    if (current) { current = notes.find((n) => n.id === current.id) || null; paintDetail(); }
  }

  function paintList() {
    const term = q.value.trim().toLowerCase();
    const rows = notes.filter((n) => !term || [n.target, n.scope, n.observations, n.notes].join(' ').toLowerCase().includes(term));
    fill(list, ...(rows.length ? rows.map((n) => h('li', {}, h('button', {
      type: 'button', class: 'item' + (current && current.id === n.id ? ' on' : ''), onclick: () => select(n.id),
    }, h('b', {}, n.target), h('small', {}, n.assessed_on || fmtDate(n.created))))) : [h('li', { class: 'muted pad' },
      notes.length ? 'No notes match your search.' : 'No notes yet. Create the first one.')]));
  }

  function select(id) {
    current = notes.find((n) => n.id === id) || null;
    history.replaceState(null, '', current ? '#note=' + id : location.pathname);
    paintList();
    paintDetail();
  }

  const linkify = (text) => text.split('\n').map((line) => {
    const t = line.trim();
    return h('div', {}, /^https?:\/\/\S+$/.test(t) ? h('a', { href: t, target: '_blank', rel: 'noopener noreferrer' }, t) : line);
  });

  function paintDetail() {
    const n = current;
    if (!n) { fill(detail, emptyState('Select a note', 'Pick a note from the list, or create a new one.')); return; }
    fill(detail, 
      h('div', { class: 'detail-head' }, h('h2', {}, n.target), n.assessed_on ? h('span', { class: 'badge' }, n.assessed_on) : null),
      h('div', { class: 'actions' },
        h('button', { class: 'btn', type: 'button', onclick: () => dialog(n) }, 'Edit'),
        h('button', { class: 'btn', type: 'button', onclick: () => exportMd(n) }, icon('download'), 'Markdown'),
        h('button', { class: 'btn', type: 'button', onclick: () => download(`${slug(n)}.json`, JSON.stringify(n, null, 2), 'application/json') }, icon('download'), 'JSON'),
        h('button', { class: 'btn danger', type: 'button', onclick: () => remove(n) }, 'Delete')),
      SECTIONS.filter(([k]) => n[k]).map(([k, label]) => h('section', { class: 'entry' }, h('h3', {}, label),
        k === 'urls' ? h('div', { class: 'prewrap' }, linkify(n[k])) : h('p', { class: 'prewrap' }, n[k]))),
      h('p', { class: 'muted small' }, `Created ${fmtDate(n.created)}, updated ${fmtDate(n.updated)}`));
  }

  const slug = (n) => n.target.replace(/[^a-z0-9]+/gi, '-').replace(/^-|-$/g, '').toLowerCase().slice(0, 40) || 'recon-note';

  function exportMd(n) {
    const parts = [`# Recon note: ${n.target}`, '', n.assessed_on ? `Date: ${n.assessed_on}` : ''];
    SECTIONS.forEach(([k, label]) => n[k] && parts.push('', `## ${label}`, '', n[k]));
    parts.push('', '---', 'Exported from D76 CyberOps ReconNote. Contents were entered by the user.');
    download(`${slug(n)}.md`, parts.join('\n'), 'text/markdown');
  }

  const dialog = (n) => formDialog({
    title: n ? 'Edit recon note' : 'New recon note', fields: fields, values: n || { assessed_on: new Date().toISOString().slice(0, 10) },
    save: async (v) => (n ? (await R.update('recon', n.id, v)).item : (await R.create('recon', v)).item),
  }).then(async (item) => { if (item) { await load(); select(item.id); } });

  async function remove(n) {
    if (!confirm(`Delete the recon note for "${n.target}"? This cannot be undone.`)) return;
    try { await R.remove('recon', n.id); current = null; history.replaceState(null, '', location.pathname); await load(); paintDetail(); } catch (e) { toast(e.message, true); }
  }

  $('#rn-new').addEventListener('click', () => dialog());
  q.addEventListener('input', debounce(paintList, 120));
  paintDetail();
  load().then(() => { const id = hashParams().get('note'); if (id) select(Number(id)); });
})();
