"""Parses text logs (web access logs, syslog, JSON lines, timestamped text) and highlights potential anomalies."""
import ipaddress
import json
import re
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone
from urllib.parse import unquote

MAX_BYTES = 100 * 1024 * 1024
MAX_ENTRIES = 20000
UTC = timezone.utc

ACCESS = re.compile(r'^(\S+) \S+ \S+ \[([^\]]+)\] "(\S+) (\S+)(?: [^"]*)?" (\d{3}) (\S+)')
SYSLOG = re.compile(r"^([A-Z][a-z]{2})\s+(\d{1,2}) (\d\d:\d\d:\d\d) (\S+) ([^:\[\s]+)(?:\[\d+\])?: (.*)$")
ISO = re.compile(r"^\[?(\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:[.,]\d+)?(?:Z|[+-]\d{2}:?\d{2})?)\]?\s*(.*)$")
LEVEL = re.compile(r"\b(DEBUG|INFO|NOTICE|WARN(?:ING)?|ERROR|ERR|CRIT(?:ICAL)?|FATAL|ALERT|EMERG)\b", re.I)
IPV4 = re.compile(r"(?<![\w.])(?:\d{1,3}\.){3}\d{1,3}(?![\w.])")
IPV6 = re.compile(r"(?<![\w:])(?:[0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{0,4}(?![\w:])")
ERRWORDS = re.compile(r"\b(error|failed|failure|denied|refused|timed? ?out|panic|critical|fatal|exception|segfault|traceback)\b", re.I)
AUTH_FAIL = re.compile(r"failed password|authentication failure|invalid user|failed login|login failed|incorrect password|bad password", re.I)
PROBE = re.compile(r"(/\.env|/\.git/|/wp-login\.php|/wp-admin|/xmlrpc\.php|/phpmyadmin|/pma/|/cgi-bin/|/\.aws/|/config\.php|/server-status|/actuator|/console\b|/admin(?:/|$))", re.I)
INJECT = re.compile(r"(\.\./|\.\.\\|%2e%2e|union\s+select|<script|%3cscript|'\s*or\s*'?1|/etc/passwd|cmd=|;\s*wget\s)", re.I)
MONTHS = {m: i for i, m in enumerate(["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"], 1)}
LEVELS = {"debug": "debug", "info": "info", "notice": "info", "warn": "warn", "warning": "warn", "error": "error", "err": "error", "crit": "error",
          "critical": "error", "fatal": "error", "alert": "error", "emerg": "error"}


def valid_ip(s):
    try:
        ipaddress.ip_address(s)
        return True
    except ValueError:
        return False


def find_ip(text):
    for m in IPV4.findall(text):
        if valid_ip(m):
            return m
    for m in IPV6.findall(text):
        if valid_ip(m):
            return m
    return None


def parse_iso(s):
    s = s.replace(",", ".").replace("Z", "+00:00")
    s = re.sub(r"([+-]\d{2})(\d{2})$", r"\1:\2", s)
    try:
        dt = datetime.fromisoformat(s)
    except ValueError:
        return None
    return (dt if dt.tzinfo else dt.replace(tzinfo=UTC)).astimezone(UTC)


def parse_line(line, now):
    m = ACCESS.match(line)
    if m:
        try:
            ts = datetime.strptime(m.group(2), "%d/%b/%Y:%H:%M:%S %z").astimezone(UTC)
        except ValueError:
            ts = None
        status = int(m.group(5))
        return {"format": "access", "ts": ts, "ip": m.group(1) if valid_ip(m.group(1)) else None, "method": m.group(3), "path": m.group(4), "status": status,
                "level": "error" if status >= 500 else "warn" if status >= 400 else "info"}
    if line.startswith("{"):
        try:
            d = json.loads(line)
            if isinstance(d, dict):
                get = lambda *keys: next((d[k] for k in keys if k in d and d[k] not in (None, "")), None)
                ts_raw = get("time", "timestamp", "@timestamp", "ts", "datetime")
                lvl = str(get("level", "severity", "lvl") or "").lower()
                msg = str(get("message", "msg", "log") or line)
                ip = get("ip", "remote_addr", "client_ip", "src_ip", "clientip")
                ts = parse_iso(str(ts_raw)) if isinstance(ts_raw, str) else (datetime.fromtimestamp(ts_raw / (1000 if ts_raw > 1e11 else 1), UTC) if isinstance(ts_raw, (int, float)) else None)
                return {"format": "json", "ts": ts, "ip": str(ip) if ip and valid_ip(str(ip)) else find_ip(msg), "level": LEVELS.get(lvl) or ("error" if ERRWORDS.search(msg) else "info"), "text": msg,
                        "status": get("status", "status_code") if isinstance(get("status", "status_code"), int) else None}
        except ValueError:
            pass
    m = SYSLOG.match(line)
    if m and m.group(1) in MONTHS:
        try:
            ts = datetime(now.year, MONTHS[m.group(1)], int(m.group(2)), *map(int, m.group(3).split(":")), tzinfo=UTC)
            if ts > now + timedelta(days=1):
                ts = ts.replace(year=now.year - 1)
        except ValueError:
            ts = None
        msg = m.group(6)
        lv = LEVEL.search(msg)
        return {"format": "syslog", "ts": ts, "ip": find_ip(msg), "level": LEVELS[lv.group(1).lower()] if lv else "error" if ERRWORDS.search(msg) else "info", "text": f"{m.group(5)}: {msg}"}
    m = ISO.match(line)
    if m:
        lv = LEVEL.search(m.group(2))
        return {"format": "timestamped", "ts": parse_iso(m.group(1)), "ip": find_ip(m.group(2)), "level": LEVELS[lv.group(1).lower()] if lv else "error" if ERRWORDS.search(m.group(2)) else "info", "text": m.group(2)}
    lv = LEVEL.search(line)
    return {"format": "unstructured", "ts": None, "ip": find_ip(line), "level": LEVELS[lv.group(1).lower()] if lv else "error" if ERRWORDS.search(line) else "info", "text": line}


def analyze(lines, now=None):
    now = now or datetime.now(UTC)
    entries, formats, levels, statuses = [], Counter(), Counter(), Counter()
    ips = Counter()
    ts_all, buckets_src = [], []
    per_ip = defaultdict(lambda: defaultdict(list))
    total = blank = 0
    requests = errors5 = 0
    assumed_year = False
    for n, raw in enumerate(lines, 1):
        line = raw.rstrip("\r\n")
        if not line.strip():
            blank += 1
            continue
        total += 1
        e = parse_line(line, now)
        formats[e["format"]] += 1
        levels[e["level"]] += 1
        if e["format"] == "syslog":
            assumed_year = True
        text = e.get("text") or f"{e.get('method', '')} {e.get('path', '')} {e.get('status', '')}"
        if e.get("status"):
            statuses[e["status"]] += 1
        if e["format"] == "access":
            requests += 1
            errors5 += e["status"] >= 500
        if e["ip"]:
            ips[e["ip"]] += 1
        if e["ts"]:
            ts_all.append(e["ts"])
            buckets_src.append((e["ts"], e["level"] == "error"))
        sample = {"line": n, "text": line[:300]}
        ip = e["ip"] or "unknown"
        if AUTH_FAIL.search(line):
            per_ip[ip]["auth"].append(sample)
        if e.get("status") in (401, 403):
            per_ip[ip]["denied"].append(sample)
        if e.get("status") == 404:
            per_ip[ip]["notfound"].append(sample)
        if e["format"] == "access":
            decoded = unquote(e["path"])
            if PROBE.search(decoded):
                per_ip[ip]["probe"].append(sample)
            if INJECT.search(decoded):
                per_ip[ip]["inject"].append(sample)
        if len(entries) < MAX_ENTRIES:
            entries.append({"n": n, "ts": e["ts"].isoformat(timespec="seconds") if e["ts"] else None, "ip": e["ip"], "level": e["level"], "status": e.get("status"),
                            "method": e.get("method"), "path": e.get("path"), "text": (text if e["format"] != "access" else line)[:400]})
    anomalies = []
    rules = [("auth", 5, "Repeated failed authentication", "failed authentication events"), ("denied", 10, "Repeated HTTP 401 or 403 responses", "denied requests"),
             ("notfound", 20, "Burst of HTTP 404 responses", "requests for missing pages"), ("probe", 1, "Requests for commonly probed paths", "requests for paths such as admin panels or config files"),
             ("inject", 1, "Injection-like patterns in request paths", "requests containing traversal, script or SQL-like fragments")]
    for ip, kinds in per_ip.items():
        for key, threshold, title, noun in rules:
            hits = kinds.get(key, [])
            if len(hits) >= threshold:
                where = "from " + ip if ip != "unknown" else "with no address recorded"
                anomalies.append({"kind": key, "title": f"Potential anomaly: {title.lower()}", "ip": None if ip == "unknown" else ip, "count": len(hits),
                                  "detail": f"{len(hits)} {noun} {where}. This is a pattern worth checking, not proof of malicious activity.", "samples": hits[:5]})
    if requests >= 20 and errors5 / requests >= 0.1:
        anomalies.append({"kind": "server_errors", "title": "Potential anomaly: elevated server errors", "ip": None, "count": errors5,
                          "detail": f"{errors5} of {requests} web requests ({100 * errors5 / requests:.0f}%) returned HTTP 5xx.", "samples": []})
    anomalies.sort(key=lambda a: -a["count"])
    timeline, first, last = [], None, None
    if ts_all:
        first, last = min(ts_all), max(ts_all)
        span = max((last - first).total_seconds(), 1)
        size = next((s for s in (60, 300, 900, 3600, 6 * 3600, 86400, 7 * 86400) if span / s <= 48), 30 * 86400)
        counts, errs = Counter(), Counter()
        for ts, is_err in buckets_src:
            b = int(ts.timestamp() // size) * size
            counts[b] += 1
            errs[b] += is_err
        timeline = [{"t": datetime.fromtimestamp(b, UTC).isoformat(timespec="seconds"), "n": counts[b], "errors": errs[b]} for b in sorted(counts)]
        timeline_size = size
    else:
        timeline_size = None
    return {"lines": total, "blank_lines": blank, "formats": dict(formats), "levels": dict(levels), "first": first.isoformat(timespec="seconds") if first else None,
            "last": last.isoformat(timespec="seconds") if last else None, "timeline": timeline, "bucket_seconds": timeline_size,
            "top_ips": [{"ip": ip, "count": c, "private": valid_ip(ip) and not ipaddress.ip_address(ip).is_global} for ip, c in ips.most_common(10)],
            "statuses": sorted(([s, c] for s, c in statuses.items())), "anomalies": anomalies, "entries": entries, "entries_truncated": total > MAX_ENTRIES,
            "notes": (["Syslog lines carry no year, so the current year is assumed."] if assumed_year else []) + (["Timestamps without a timezone are treated as UTC."] if "timestamped" in formats else [])}
