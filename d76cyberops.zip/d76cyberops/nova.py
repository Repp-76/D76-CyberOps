"""D76 Nova: a command-line and web assistant for developer and security tasks.
API keys come from environment variables (or a key file) only. They are never stored or returned."""
import argparse
import json
import os
import re
import stat
import sys
import urllib.parse

import netutil

TASKS = {
    "ask": ("Ask a question", "You are Nova, a careful senior engineer and security practitioner. Answer clearly and concisely. If something is uncertain, say so."),
    "explain": ("Explain code", "Explain what this code does, step by step, for a competent developer. Point out bugs, risky patterns and anything surprising. Be concise."),
    "document": ("Write documentation", "Write clear documentation for this code: purpose, parameters, return values, examples and caveats. Use Markdown. Do not invent behaviour the code does not have."),
    "error": ("Analyze an error", "Diagnose this error message or stack trace. Give the most likely causes in order, how to confirm each, and the fix. Be specific."),
    "log": ("Summarize a log", "Summarize this log: what happened, in what order, the notable errors, and anything that looks anomalous. Do not claim malicious activity without evidence; say 'possible' and cite the lines."),
    "concept": ("Explain a security concept", "Explain this security concept for a practitioner: what it is, how the attack or defence works, a realistic example, and how to defend. Defensive focus; no step-by-step attack instructions."),
    "tests": ("Generate test cases", "Write thorough test cases for this code, including edge cases and failure paths. Use the idiomatic test framework for the language and explain what each test checks."),
    "review": ("Review for security", "Review this code for security problems. List each issue with severity, where it is, why it matters and a concrete fix. Do not pad with generic advice."),
    "format": ("Format code", "Reformat this code cleanly and consistently using the conventions of its language. Do not change behaviour. Return only the formatted code in one code block."),
}
SCAFFOLD_PROMPT = ("You create small, working project skeletons. Reply with ONLY a JSON object: {\"files\": [{\"path\": \"relative/path\", \"content\": \"...\"}]}. "
                   "Use relative paths only, at most 25 files, no binary files, no secrets. Include a short README.")
SECRET_PATTERNS = [re.compile(p) for p in (r"\bAKIA[0-9A-Z]{16}\b", r"\bgh[pousr]_[A-Za-z0-9]{36,}\b", r"\bxox[baprs]-[A-Za-z0-9-]{10,}", r"\bAIza[0-9A-Za-z_-]{35}\b", r"\bsk_live_[0-9a-zA-Z]{20,}",
                                            r"\bsk-[A-Za-z0-9_-]{20,}", r"\beyJ[\w-]{10,}\.[\w-]{10,}\.[\w-]{10,}", r"-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]*?-----END [A-Z ]*PRIVATE KEY-----")]
GENERIC = re.compile(r"(?i)\b((?:api[_-]?key|secret|token|passwd|password|authorization)\s*[:=]\s*['\"]?(?:Bearer\s+)?)([A-Za-z0-9_\-/+=.]{8,})")
MAX_INPUT = 100_000
LOOPBACK = {"localhost", "127.0.0.1", "::1"}


class NovaError(ValueError):
    pass


def mask_secrets(text):
    n = 0

    def sub(m):
        nonlocal n
        n += 1
        return "[SECRET]"

    for rx in SECRET_PATTERNS:
        text = rx.sub(sub, text)

    def generic(m):
        nonlocal n
        n += 1
        return m.group(1) + "[SECRET]"
    return GENERIC.sub(generic, text), n


def key_file_warning(path):
    try:
        mode = os.stat(path).st_mode
        return "The key file can be read by other users; run chmod 600 on it." if os.name == "posix" and mode & (stat.S_IRGRP | stat.S_IROTH) else None
    except OSError:
        return None


def get_config(stored=None):
    stored = stored or {}
    provider = os.environ.get("D76_NOVA_PROVIDER") or stored.get("provider") or ("anthropic" if os.environ.get("ANTHROPIC_API_KEY") else "openai")
    if provider not in ("anthropic", "openai"):
        raise NovaError("The provider must be 'anthropic' or 'openai' (any OpenAI-compatible server).")
    base = (os.environ.get("D76_NOVA_BASE_URL") or stored.get("base_url") or "").strip().rstrip("/")
    key, source = None, None
    if os.environ.get("D76_NOVA_API_KEY"):
        key, source = os.environ["D76_NOVA_API_KEY"], "D76_NOVA_API_KEY"
    elif os.environ.get("D76_NOVA_KEY_FILE"):
        try:
            with open(os.environ["D76_NOVA_KEY_FILE"]) as fh:
                key, source = fh.readline().strip(), "D76_NOVA_KEY_FILE"
        except OSError:
            raise NovaError("D76_NOVA_KEY_FILE is set but the file cannot be read.") from None
    elif provider == "anthropic" and os.environ.get("ANTHROPIC_API_KEY"):
        key, source = os.environ["ANTHROPIC_API_KEY"], "ANTHROPIC_API_KEY"
    elif provider == "openai" and os.environ.get("OPENAI_API_KEY"):
        key, source = os.environ["OPENAI_API_KEY"], "OPENAI_API_KEY"
    default_base = "https://api.anthropic.com" if provider == "anthropic" else "https://api.openai.com/v1"
    url = base or default_base
    host = urllib.parse.urlsplit(url).hostname or ""
    if not url.startswith(("https://", "http://")):
        raise NovaError("The base URL must start with https:// (or http:// for a local server).")
    if url.startswith("http://") and host not in LOOPBACK:
        raise NovaError("Plain http:// is only allowed for a server on this machine (localhost).")
    try:
        max_tokens = max(100, min(8000, int(os.environ.get("D76_NOVA_MAX_TOKENS") or stored.get("max_tokens") or 1500)))
    except ValueError:
        max_tokens = 1500
    return {"provider": provider, "model": os.environ.get("D76_NOVA_MODEL") or stored.get("model") or "", "base_url": url, "host": host, "key": key, "key_source": source,
            "max_tokens": max_tokens, "local": host in LOOPBACK, "private_ok": host in LOOPBACK or bool(os.environ.get("D76_NOVA_BASE_URL")),
            "key_file_warning": key_file_warning(os.environ["D76_NOVA_KEY_FILE"]) if os.environ.get("D76_NOVA_KEY_FILE") else None}


def status(stored=None):
    try:
        c = get_config(stored)
    except NovaError as e:
        return {"configured": False, "problem": str(e)}
    need_key = not c["local"]
    configured = bool(c["model"]) and (bool(c["key"]) or not need_key)
    problems = []
    if not c["model"]:
        problems.append("Choose a model (D76_NOVA_MODEL or the settings below).")
    if need_key and not c["key"]:
        problems.append("No API key found. Set D76_NOVA_API_KEY, or ANTHROPIC_API_KEY / OPENAI_API_KEY, or point D76_NOVA_KEY_FILE at a file that holds it.")
    return {"configured": configured, "provider": c["provider"], "model": c["model"], "host": c["host"], "key_source": c["key_source"], "local": c["local"], "problems": problems,
            "key_file_warning": c["key_file_warning"]}


def call(cfg, system, user):
    if cfg["provider"] == "anthropic":
        url, headers = cfg["base_url"] + "/v1/messages", {"x-api-key": cfg["key"] or "", "anthropic-version": "2023-06-01", "content-type": "application/json"}
        body = {"model": cfg["model"], "max_tokens": cfg["max_tokens"], "system": system, "messages": [{"role": "user", "content": user}]}
    else:
        url, headers = cfg["base_url"] + "/chat/completions", {"content-type": "application/json"}
        if cfg["key"]:
            headers["authorization"] = "Bearer " + cfg["key"]
        body = {"model": cfg["model"], "max_tokens": cfg["max_tokens"], "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}]}
    try:
        r = netutil.request(url, "POST", headers, json.dumps(body).encode(), cfg["private_ok"], 90, True, 4 * 1024 * 1024)
    except netutil.NetError as e:
        raise NovaError(f"Could not reach {cfg['host']}: {e}") from None
    try:
        data = json.loads(r["body"] or b"{}")
    except ValueError:
        data = {}
    if r["status"] != 200:
        detail = (data.get("error") or {}) if isinstance(data, dict) else {}
        msg = detail.get("message") if isinstance(detail, dict) else str(detail)
        hint = " Check the API key and model name." if r["status"] in (401, 403, 404) else " Try again shortly." if r["status"] in (429, 500, 502, 503, 529) else ""
        raise NovaError(f"{cfg['host']} answered HTTP {r['status']}" + (f": {str(msg)[:200]}" if msg else ".") + hint)
    try:
        if cfg["provider"] == "anthropic":
            return "".join(b.get("text", "") for b in data["content"] if b.get("type") == "text")
        return data["choices"][0]["message"]["content"]
    except (KeyError, IndexError, TypeError):
        raise NovaError("The provider's reply was not in the expected format.") from None


def run_task(task, text, stored=None, mask=True, language=""):
    if task not in TASKS:
        raise NovaError("Unknown task.")
    text = (text or "").strip()
    if not text:
        raise NovaError("Enter some text first.")
    if len(text) > MAX_INPUT:
        raise NovaError(f"The input is larger than {MAX_INPUT // 1000} KB.")
    cfg = get_config(stored)
    st = status(stored)
    if not st["configured"]:
        raise NovaError(" ".join(st["problems"]))
    masked = 0
    if mask:
        text, masked = mask_secrets(text)
    user = (f"Language: {language}\n\n" if language else "") + text
    return {"text": call(cfg, TASKS[task][1], user), "provider": cfg["provider"], "model": cfg["model"], "host": cfg["host"], "masked": masked}


def safe_files(raw):
    """Parses and validates a scaffold reply. Returns [(relative_path, content)]."""
    raw = raw.strip()
    m = re.search(r"```(?:json)?\s*(\{.*\})\s*```", raw, re.S)
    try:
        data = json.loads(m.group(1) if m else raw[raw.index("{"):raw.rindex("}") + 1])
        files = data["files"]
    except (ValueError, KeyError):
        raise NovaError("The model did not return a usable file list. Try again with a clearer description.") from None
    if not isinstance(files, list) or not 1 <= len(files) <= 25:
        raise NovaError("The model returned an unexpected number of files.")
    out, seen = [], set()
    for f in files:
        path, content = str(f.get("path", "")).replace("\\", "/"), f.get("content")
        parts = path.split("/")
        if not path or path.startswith("/") or ".." in parts or any(p in ("", ".") for p in parts) or re.match(r"^[A-Za-z]:", path) or len(path) > 150 or "\x00" in path:
            raise NovaError(f"The model proposed an unsafe file path ({path[:60]!r}); nothing was created.")
        if not isinstance(content, str) or len(content) > 100_000 or path in seen:
            raise NovaError("The model returned an invalid or duplicate file; nothing was created.")
        seen.add(path)
        out.append((path, content))
    return out


def scaffold(description, stored=None):
    cfg = get_config(stored)
    st = status(stored)
    if not st["configured"]:
        raise NovaError(" ".join(st["problems"]))
    desc, masked = mask_secrets((description or "").strip())
    if not desc:
        raise NovaError("Describe the project first.")
    return safe_files(call(cfg, SCAFFOLD_PROMPT, desc))


def write_files(files, out_dir, force=False):
    root = os.path.realpath(out_dir)
    os.makedirs(root, exist_ok=True)
    written = []
    for rel, content in files:
        dest = os.path.realpath(os.path.join(root, *rel.split("/")))
        if os.path.commonpath([dest, root]) != root:
            raise NovaError(f"Refusing to write outside the output folder: {rel}")
        if os.path.exists(dest) and not force:
            raise NovaError(f"{rel} already exists. Use --force to overwrite, or choose another folder.")
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        with open(dest, "w", encoding="utf-8") as fh:
            fh.write(content)
        written.append(rel)
    return written


def read_input(arg):
    if arg == "-" or arg is None:
        data = sys.stdin.read()
    elif os.path.isfile(arg):
        with open(arg, "r", encoding="utf-8", errors="replace") as fh:
            data = fh.read(MAX_INPUT + 1)
    else:
        data = arg
    return data


def main(argv=None):
    ap = argparse.ArgumentParser(prog="nova", description="D76 Nova: AI help for code, errors, logs and security questions. Keys are read from the environment.")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("status", help="show the provider configuration (never the key)")
    for name, (label, _) in TASKS.items():
        p = sub.add_parser(name, help=label)
        p.add_argument("input", nargs="?", help="a file, text, or - for standard input")
        p.add_argument("--no-mask", action="store_true", help="send the text exactly as written (secrets are masked by default)")
    sc = sub.add_parser("scaffold", help="create project files from a description")
    sc.add_argument("description")
    sc.add_argument("--out", required=True, help="folder to create the files in")
    sc.add_argument("--force", action="store_true", help="overwrite files that already exist")
    args = ap.parse_args(argv)
    try:
        stored = None
        try:
            import db
            stored = json.loads(db.get_settings().get("nova_config", "{}"))
        except Exception:
            stored = None
        if args.cmd == "status":
            print(json.dumps(status(stored), indent=2))
            return 0
        if args.cmd == "scaffold":
            written = write_files(scaffold(args.description, stored), args.out, args.force)
            print("Created:\n  " + "\n  ".join(written))
            return 0
        r = run_task(args.cmd, read_input(args.input), stored, not args.no_mask)
        if r["masked"]:
            print(f"[{r['masked']} secret(s) masked before sending]", file=sys.stderr)
        print(r["text"])
        return 0
    except NovaError as e:
        print(f"nova: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
