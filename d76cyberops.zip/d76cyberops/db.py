import os
import sqlite3
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path

DATA_DIR = Path(os.environ.get("D76_DATA", Path(__file__).parent / "data"))
DB_PATH = DATA_DIR / "d76.db"

# Order matters for restore (parents first).
TABLES = ["activity", "cases", "notes", "evidence", "entities", "relations", "snippets", "projects",
          "tasks", "task_history", "kb_articles", "recon", "reports"]
DEFAULTS = {"theme": "dark", "debug": "0"}
ACTIVITY_CAP = 2000

SCHEMA = """
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS activity (
    id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT NOT NULL, tool TEXT NOT NULL, event TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS cases (
    id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, description TEXT DEFAULT '',
    status TEXT DEFAULT 'open', tags TEXT DEFAULT '', investigator TEXT DEFAULT '', kind TEXT DEFAULT 'case',
    created TEXT NOT NULL, updated TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS notes (
    id INTEGER PRIMARY KEY AUTOINCREMENT, case_id INTEGER REFERENCES cases(id) ON DELETE CASCADE,
    title TEXT NOT NULL, body TEXT DEFAULT '', tags TEXT DEFAULT '', created TEXT NOT NULL, updated TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS evidence (
    id INTEGER PRIMARY KEY AUTOINCREMENT, case_id INTEGER NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
    title TEXT NOT NULL, description TEXT DEFAULT '', file_name TEXT DEFAULT '', file_size INTEGER DEFAULT 0,
    sha256 TEXT DEFAULT '', file_ref TEXT DEFAULT '', collected_by TEXT DEFAULT '', status TEXT DEFAULT 'collected',
    tags TEXT DEFAULT '', last_check TEXT, last_result TEXT, created TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS entities (
    id INTEGER PRIMARY KEY AUTOINCREMENT, case_id INTEGER NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
    kind TEXT NOT NULL, label TEXT NOT NULL, value TEXT DEFAULT '', source_url TEXT DEFAULT '',
    evidence TEXT DEFAULT '', notes TEXT DEFAULT '', tags TEXT DEFAULT '', bookmarked INTEGER DEFAULT 0,
    created TEXT NOT NULL, updated TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS relations (
    id INTEGER PRIMARY KEY AUTOINCREMENT, case_id INTEGER NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
    src INTEGER NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
    dst INTEGER NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
    label TEXT DEFAULT '', created TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS snippets (
    id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, language TEXT DEFAULT 'text',
    body TEXT NOT NULL, tags TEXT DEFAULT '', category TEXT DEFAULT '', favorite INTEGER DEFAULT 0,
    created TEXT NOT NULL, updated TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS projects (
    id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, description TEXT DEFAULT '',
    created TEXT NOT NULL, updated TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, notes TEXT DEFAULT '',
    status TEXT DEFAULT 'backlog', priority TEXT DEFAULT 'normal', tags TEXT DEFAULT '',
    due TEXT, project_id INTEGER REFERENCES projects(id) ON DELETE CASCADE,
    created TEXT NOT NULL, updated TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS task_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    task_id INTEGER, ts TEXT NOT NULL, event TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS kb_articles (
    id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, category TEXT DEFAULT '',
    body TEXT NOT NULL, tags TEXT DEFAULT '', read INTEGER DEFAULT 0, bookmarked INTEGER DEFAULT 0,
    created TEXT NOT NULL, updated TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS recon (
    id INTEGER PRIMARY KEY AUTOINCREMENT, target TEXT NOT NULL, scope TEXT DEFAULT '', assessed_on TEXT DEFAULT '',
    authorization TEXT DEFAULT '', observations TEXT DEFAULT '', urls TEXT DEFAULT '', dns TEXT DEFAULT '',
    tech TEXT DEFAULT '', files TEXT DEFAULT '', notes TEXT DEFAULT '', created TEXT NOT NULL, updated TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS reports (
    id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, kind TEXT DEFAULT '',
    path TEXT DEFAULT '', created TEXT NOT NULL);
"""

# Columns added after phase 1 shipped, for databases created by the older schema.
MIGRATIONS = [
    ("cases", "investigator", "TEXT DEFAULT ''"),
    ("cases", "kind", "TEXT DEFAULT 'case'"),
    ("snippets", "category", "TEXT DEFAULT ''"),
    ("tasks", "project_id", "INTEGER REFERENCES projects(id) ON DELETE CASCADE"),
]


def now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def connect():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init():
    with closing(connect()) as conn, conn:
        conn.executescript(SCHEMA)
        for table, column, ddl in MIGRATIONS:
            if column not in {r[1] for r in conn.execute(f"PRAGMA table_info({table})")}:
                conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {ddl}")


def query(sql, args=()):
    with closing(connect()) as conn:
        return [dict(r) for r in conn.execute(sql, args)]


def run(sql, args=()):
    with closing(connect()) as conn, conn:
        return conn.execute(sql, args).lastrowid


def get_settings():
    values = dict(DEFAULTS)
    values.update({r["key"]: r["value"] for r in query("SELECT key, value FROM settings")})
    return values


def set_settings(values):
    with closing(connect()) as conn, conn:
        conn.executemany(
            "INSERT INTO settings (key, value) VALUES (?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
            list(values.items()),
        )


def log(tool, event):
    if event == "Tool opened":
        last = query("SELECT tool, event FROM activity ORDER BY id DESC LIMIT 1")
        if last and last[0]["tool"] == tool and last[0]["event"] == event:
            return
    run("INSERT INTO activity (ts, tool, event) VALUES (?, ?, ?)", (now(), tool, event))
    run("DELETE FROM activity WHERE id <= (SELECT MAX(id) FROM activity) - ?", (ACTIVITY_CAP,))


def dump():
    data = {"settings": get_settings()}
    for table in TABLES:
        data[table] = query(f"SELECT * FROM {table}")
    return data


def restore(data):
    """Merge rows from an export. Unknown tables/columns are ignored."""
    counts = {}
    with closing(connect()) as conn, conn:
        for table in TABLES:
            rows = data.get(table)
            if not isinstance(rows, list):
                continue
            cols = {r[1] for r in conn.execute(f"PRAGMA table_info({table})")}
            n = 0
            for row in rows:
                if not isinstance(row, dict):
                    continue
                keys = [k for k in row if k in cols]
                if not keys:
                    continue
                marks = ", ".join("?" for _ in keys)
                conn.execute(
                    f"INSERT OR REPLACE INTO {table} ({', '.join(keys)}) VALUES ({marks})",
                    [row[k] for k in keys],
                )
                n += 1
            counts[table] = n
    return counts


def wipe(everything):
    with closing(connect()) as conn, conn:
        tables = ["activity"] if not everything else list(reversed(TABLES))
        for table in tables:
            conn.execute(f"DELETE FROM {table}")
        if everything:
            conn.execute("DELETE FROM settings")
