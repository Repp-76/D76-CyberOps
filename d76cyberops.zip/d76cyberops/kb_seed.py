# Starter articles for the Knowledge Base. Seeded once; edit or delete freely.
ARTICLES = [
("The CIA triad and how to use it", "Cybersecurity", "fundamentals,risk", """\
Most security decisions come back to three properties.

- **Confidentiality**: only the right people can read the data. Controls: encryption, access control, need-to-know.
- **Integrity**: data has not been changed without detection. Controls: hashes, signatures, change logging, backups you can verify.
- **Availability**: the system works when needed. Controls: redundancy, capacity planning, tested restores.

## Using it

When you review a system, ask which property matters most for each asset. A public price list needs integrity and availability more than confidentiality. A password database needs all three, with confidentiality first.

Controls often pull against each other. Strict access rules protect confidentiality but can hurt availability during an incident. Write down the trade-off you chose and why."""),

("Documenting OSINT research so it can be repeated", "OSINT", "method,evidence", """\
Good OSINT notes let someone else reach the same result from the same sources.

## For every finding, record

1. The exact URL and the date and time (with timezone) you accessed it.
2. What you saw, in your own words, kept separate from your interpretation.
3. A saved copy: a screenshot or an archived page, with its SHA-256 hash.
4. How confident you are, and what would change your mind.

## Stay inside the lines

- Use publicly available information and lawful access only.
- Write down the scope and purpose of the research before you start.
- Do not log in to accounts that are not yours or bypass access controls.
- Treat personal data about private individuals with care and collect only what the question needs."""),

("DNS records you will meet most often", "Networking", "dns,basics", """\
| Record | Purpose |
|---|---|
| A / AAAA | Maps a name to an IPv4 / IPv6 address |
| CNAME | Alias to another name |
| MX | Mail servers for the domain, with priority |
| NS | Authoritative name servers |
| TXT | Free text, used for SPF, DKIM, DMARC and domain verification |
| SOA | Zone metadata: primary server, serial, refresh timers |
| PTR | Reverse lookup, address to name |

## Useful commands

```
dig example.com A +short
dig example.com MX
dig -x 203.0.113.10
```

TTL controls how long resolvers cache an answer. Lower it before a planned change, not during an outage."""),

("Linux file permissions in five minutes", "Linux", "permissions,chmod", """\
`ls -l` shows ten characters such as `-rwxr-x---`. The first is the type, then three triplets for owner, group and everyone else.

- `r` read = 4, `w` write = 2, `x` execute = 1
- `chmod 750 file` gives the owner 7 (rwx), the group 5 (r-x), others 0
- `chown user:group file` changes ownership

## Habits worth keeping

- Start from the least access that works. Avoid `chmod 777`.
- Keep private keys at `600` and your `.ssh` folder at `700`.
- Be careful with setuid and setgid bits (`4xxx`, `2xxx`): a program with them runs with its owner's rights.
- `umask 022` is a common default for new files."""),

("Validate input, escape output", "Programming", "input-validation,injection", """\
Two different jobs are often confused.

**Validation** decides whether input is acceptable: type, length, range, format. Prefer an allowlist of what you accept over a blocklist of what you fear.

**Escaping** makes data safe for the place it is going: HTML, a URL, a shell, an SQL statement. Do it at the point of output, using the library for that context.

## Rules of thumb

- Use parameterized queries for SQL. Never build queries by joining strings.
- Do not pass user input to a shell. If you must run a program, pass arguments as a list.
- Validate on the server even if the browser already did.
- Reject early and return a clear error rather than trying to repair bad input."""),

("Security headers worth setting", "Web Security", "headers,https,cookies", """\
Check these on any site you run.

- `Strict-Transport-Security`: tells browsers to use HTTPS only. Start with a short max-age, then raise it.
- `Content-Security-Policy`: limits where scripts, styles and images may load from. The strongest defence against injected scripts.
- `X-Content-Type-Options: nosniff`: stops browsers guessing file types.
- `frame-ancestors` (in CSP) or `X-Frame-Options`: controls who may embed your pages.
- `Referrer-Policy`: limits what URL information leaves your site.

## Cookies

Set `Secure`, `HttpOnly` and a `SameSite` value on session cookies. Keep them short-lived and rotate them at login."""),

("Evidence handling: hashing and chain of custody", "Digital Forensics", "evidence,hashing", """\
Evidence is only useful if you can show it has not changed.

1. **Hash at collection.** Calculate SHA-256 as soon as you have the file and record it with the time and who collected it.
2. **Work on copies.** Keep the original untouched and read-only.
3. **Log every handover.** Who held it, when, and why.
4. **Verify before you rely on it.** Re-hash and compare to the recorded value. A mismatch means stop and investigate.

MD5 and SHA-1 are fine for spotting accidental corruption but are not safe against deliberate tampering. Use SHA-256 or stronger for anything that may be disputed."""),

("Git habits that prevent leaked secrets", "Developer Tools", "git,secrets", """\
Secrets pushed to a repository should be treated as public, even if the repository is private.

- Keep real values in environment variables or a local `.env` file, and add `.env` to `.gitignore`.
- Commit a `.env.example` that shows the variable names with fake values.
- Run a secret scanner as a pre-commit hook so mistakes are caught before they leave your machine.

## If a secret was committed

1. **Revoke and rotate it first.** Removing it from history does not make it safe again.
2. Then clean the history if you need to, and force every collaborator to re-clone.

```
git log -p -S"API_KEY" -- .
```"""),

("Reducing your data footprint", "Privacy", "privacy,accounts", """\
Less data shared means less data that can leak.

- Give each service only what it needs. Skip optional profile fields.
- Use separate email addresses or aliases for different kinds of accounts.
- Turn on two-factor authentication, preferring an authenticator app or security key over SMS.
- Review app permissions on your phone every few months.
- Delete accounts you no longer use. Old accounts are a common way in.
- Use a password manager so every password is unique.

Check what a data breach exposed about you with a breach-notification service, then change the affected passwords."""),

("Spotting phishing", "Security Awareness", "phishing,email", """\
Phishing tries to hurry you into acting before you think.

## Warning signs

- The sender's address does not match the organization it claims to be.
- Urgency or threats: "act within 24 hours or lose access".
- A link whose real destination differs from its text. Hover or long-press to see it.
- Unexpected attachments, or requests for passwords, codes or payments.

## What to do

1. Do not click. Open the site yourself or call a number you already trust.
2. Never share one-time codes with anyone who contacts you.
3. Report it to your IT team or the service being imitated, then delete it.

If you already clicked and entered a password, change it right away and enable two-factor authentication."""),

("Using D76 CyberOps responsibly", "Security Awareness", "scope,authorization,d76", """\
D76 CyberOps is for work you are allowed to do.

- Only assess systems you own or have written permission to test. Record that permission in ReconNote's authorization field.
- Use public information obtained lawfully. D76 does not scrape, log in for you, or look people up automatically.
- Everything is stored on your machine. Export and back up the database yourself from Settings.
- Evidence files are hashed and never stored or modified by CaseVault.
- Keep the app on localhost. If you expose it through a tunnel, add authentication in front of it first."""),
]
