"""Security checklist definitions, real checks for authorized web targets, and report building."""
import json
import re

import inspector
import netutil

# id, category, severity, title, recommendation, automatic
ITEMS = [
    ("https_redirect", "HTTPS", "high", "Plain HTTP requests redirect to HTTPS", "Redirect every HTTP request to HTTPS with a permanent redirect at the web server or edge.", True),
    ("tls_valid", "HTTPS", "critical", "The certificate is valid, trusted and not close to expiry", "Use automated issuance and renewal, and alert well before expiry.", True),
    ("tls_versions", "HTTPS", "high", "Only TLS 1.2 and 1.3 are enabled", "Disable SSLv3, TLS 1.0 and 1.1 and check the result with a TLS scanner.", False),
    ("hsts", "HTTPS", "medium", "HTTP Strict Transport Security is set with a long lifetime", "Send Strict-Transport-Security with max-age of at least 15552000 and add includeSubDomains when ready.", True),
    ("csp", "Security Headers", "high", "A Content-Security-Policy is set", "Start with default-src 'self' and tighten it. Avoid 'unsafe-inline' for scripts.", True),
    ("xcto", "Security Headers", "medium", "X-Content-Type-Options is nosniff", "Send X-Content-Type-Options: nosniff.", True),
    ("framing", "Security Headers", "medium", "Framing is restricted", "Use frame-ancestors in the CSP, or X-Frame-Options.", True),
    ("referrer", "Security Headers", "low", "A Referrer-Policy is set", "Use strict-origin-when-cross-origin or stricter.", True),
    ("permissions", "Security Headers", "low", "A Permissions-Policy limits browser features", "Disable camera, microphone and geolocation if the site does not need them.", True),
    ("cookie_secure", "Cookies", "high", "Cookies carry the Secure flag", "Set Secure on every cookie so it is never sent over HTTP.", True),
    ("cookie_httponly", "Cookies", "high", "Session cookies carry HttpOnly", "Set HttpOnly on session and authentication cookies.", True),
    ("cookie_samesite", "Cookies", "medium", "Cookies set SameSite", "Use SameSite=Lax or Strict unless cross-site use is required.", True),
    ("cookie_scope", "Cookies", "low", "Session cookies are short-lived and narrowly scoped", "Limit lifetime, path and domain, and rotate the session at login.", False),
    ("auth_hash", "Authentication", "critical", "Passwords are stored with a slow salted hash", "Use Argon2id, bcrypt or scrypt. Never store plain or fast-hashed passwords.", False),
    ("auth_mfa", "Authentication", "high", "Multi-factor authentication is available for privileged accounts", "Require MFA for administrators and offer it to everyone.", False),
    ("auth_ratelimit", "Authentication", "high", "Login attempts are rate limited or locked out", "Throttle by account and by address, and alert on bursts of failures.", False),
    ("auth_reset", "Authentication", "medium", "Password reset links are single-use, short-lived and unguessable", "Use random tokens that expire quickly and are invalidated after use.", False),
    ("auth_session", "Authentication", "medium", "Sessions end on logout and are renewed at login", "Invalidate the server-side session on logout and issue a new ID at login.", False),
    ("iv_server", "Input Validation", "high", "All input is validated on the server", "Validate type, length and format on the server whatever the browser did.", False),
    ("iv_sql", "Input Validation", "critical", "Database queries are parameterized", "Never build queries by joining strings. Use parameters or an ORM safely.", False),
    ("iv_xss", "Input Validation", "high", "Output is escaped for its context", "Escape for HTML, attributes, JavaScript and URLs separately; prefer a templating engine that escapes by default.", False),
    ("iv_upload", "Input Validation", "high", "File uploads are restricted and stored safely", "Limit type and size, rename files, and store them outside the web root.", False),
    ("iv_csrf", "Input Validation", "high", "State-changing requests are protected against CSRF", "Use anti-CSRF tokens or SameSite cookies together with origin checks.", False),
    ("dep_audit", "Dependencies", "high", "Dependencies are checked for known vulnerabilities regularly", "Run an audit tool in CI and on a schedule.", False),
    ("dep_lock", "Dependencies", "medium", "Versions are pinned with a lockfile", "Commit the lockfile so builds are repeatable.", False),
    ("dep_update", "Dependencies", "medium", "Security updates are applied promptly", "Agree a time limit for critical fixes and track it.", False),
    ("dep_unused", "Dependencies", "low", "Unused packages are removed", "Every dependency is attack surface; remove what you do not use.", False),
    ("sec_repo", "Secrets Management", "critical", "No secrets are committed to version control", "Scan history for secrets and rotate any that were committed.", False),
    ("sec_env", "Secrets Management", "high", "Secrets come from the environment or a secrets manager", "Keep them out of code and images.", False),
    ("sec_rotate", "Secrets Management", "medium", "Secrets can be rotated and are rotated after exposure", "Document how to rotate each secret and practise it.", False),
    ("sec_least", "Secrets Management", "medium", "API keys have the least privilege needed", "Create narrowly scoped keys per service.", False),
    ("log_auth", "Logging", "medium", "Authentication events are logged", "Record sign-ins, failures and privilege changes with time and source.", False),
    ("log_nosecret", "Logging", "high", "Logs never contain passwords, tokens or card numbers", "Mask sensitive fields before they reach the log.", False),
    ("log_retention", "Logging", "low", "Logs are retained and protected from tampering", "Ship logs off the host and restrict who can change them.", False),
    ("log_alert", "Logging", "medium", "Someone is alerted to suspicious activity", "Alert on repeated failures, new admin accounts and unusual errors.", False),
    ("bk_regular", "Backups", "high", "Backups run on a schedule", "Automate backups and alert when one fails.", False),
    ("bk_restore", "Backups", "high", "Restores have been tested", "Practise a full restore on a schedule; an untested backup is a hope.", False),
    ("bk_offsite", "Backups", "medium", "A copy is stored away from the main system", "Keep at least one copy that ransomware or a mistake cannot reach.", False),
    ("bk_encrypted", "Backups", "medium", "Backups are encrypted", "Encrypt backups and keep the keys separately.", False),
    ("ac_server", "Access Control", "critical", "Authorization is checked on the server for every request", "Never rely on hidden buttons or client checks.", False),
    ("ac_least", "Access Control", "high", "Users and services have least privilege", "Review roles regularly and remove access that is not needed.", False),
    ("ac_idor", "Access Control", "high", "Users cannot reach others' records by changing an ID", "Check ownership on every object lookup.", False),
    ("ac_admin", "Access Control", "high", "Admin interfaces are not openly exposed", "Restrict by network, VPN or strong authentication.", False),
    ("cfg_debug", "Configuration", "high", "Debug mode and verbose errors are off in production", "Use production settings and turn debug off.", False),
    ("cfg_banner", "Configuration", "low", "Server software and versions are not disclosed", "Remove version numbers from Server and X-Powered-By headers.", True),
    ("cfg_defaults", "Configuration", "high", "Default accounts and sample content are removed", "Delete or change every default login and sample page.", False),
    ("cfg_ports", "Configuration", "medium", "Only required ports and services are exposed", "Close what you do not use and firewall the rest.", False),
    ("err_generic", "Error Handling", "medium", "Users see generic errors, never stack traces", "Log details server-side and show a short message with a reference.", False),
    ("err_closed", "Error Handling", "medium", "Failures deny access instead of granting it", "When a check errors, treat the request as not allowed.", False),
    ("err_central", "Error Handling", "low", "Unhandled errors are caught and logged centrally", "Add a global handler so nothing fails silently.", False),
]
ITEM_BY_ID = {i[0]: dict(id=i[0], category=i[1], severity=i[2], title=i[3], recommendation=i[4], auto=i[5]) for i in ITEMS}
ITEM_IDS = set(ITEM_BY_ID)
CATEGORIES = list(dict.fromkeys(i[1] for i in ITEMS))
STATUSES = ("pass", "fail", "na", "unanswered")
RANK = {"critical": 0, "high": 1, "medium": 2, "low": 3}


def validate_answers(raw):
    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        return "The answers must be valid JSON."
    if not isinstance(data, dict) or len(data) > 200:
        return "The answers must be an object keyed by item."
    for k, v in data.items():
        if k not in ITEM_IDS or not isinstance(v, dict) or v.get("status") not in STATUSES or len(str(v.get("notes", ""))) > 2000:
            return f"Invalid answer for '{k[:40]}'."
    return None


def web_checks(target, allow_private=False):
    host, is_ip, port = inspector.clean_target(target)
    out = {}
    https_url = f"https://{host}{':' + str(port) if port and port != 443 else ''}/"
    http_url = f"http://{host}{':' + str(port) if port and port != 80 else ''}/"
    # HTTP to HTTPS
    try:
        r = netutil.request(f"http://{host}/" if port in (None, 443, 80) else http_url, "GET", None, None, allow_private, 6)
        loc = netutil.header(r["headers"], "location") or ""
        if r["status"] in netutil.REDIRECTS and loc.lower().startswith("https://"):
            out["https_redirect"] = ("pass", f"HTTP answered {r['status']} and redirects to {loc[:80]}.")
        else:
            out["https_redirect"] = ("fail", f"HTTP answered {r['status']} without redirecting to HTTPS.")
    except netutil.NetError as e:
        out["https_redirect"] = ("na", f"Could not check plain HTTP: {e}")
    # TLS
    tls = inspector.tls_section(host, port, allow_private)
    if tls["ok"]:
        cert = tls.get("certificate") or {}
        days = cert.get("days_left")
        if tls.get("verified") and (days is None or days >= 14):
            out["tls_valid"] = ("pass", f"Verified; {days} days left." if days is not None else "Verified.")
        elif tls.get("verified"):
            out["tls_valid"] = ("fail", f"Verified but expires in {days} days.")
        else:
            out["tls_valid"] = ("fail", f"The certificate did not verify: {tls.get('error')}")
    else:
        out["tls_valid"] = ("na", tls["error"])
    # headers and cookies
    http = inspector.http_section(host, port, allow_private)
    if not http["ok"] or not http.get("final"):
        for i in ("hsts", "csp", "xcto", "framing", "referrer", "permissions", "cookie_secure", "cookie_httponly", "cookie_samesite", "cfg_banner"):
            out[i] = ("na", "The site could not be fetched.")
        return {"target": host, "results": {k: {"status": v[0], "note": v[1]} for k, v in out.items()}}
    final = http["final"]
    h = {k.lower(): v for k, v in final["headers"]}
    cookies = [v for k, v in final["headers"] if k.lower() == "set-cookie"]
    hsts = h.get("strict-transport-security")
    m = re.search(r"max-age=(\d+)", hsts or "", re.I)
    out["hsts"] = ("pass", hsts) if m and int(m.group(1)) >= 15552000 else ("fail", f"Present but short: {hsts}" if hsts else "Not set.")
    csp = h.get("content-security-policy")
    out["csp"] = ("fail", "Not set.") if not csp else ("pass", "Set." + (" It allows 'unsafe-inline', which weakens it." if "'unsafe-inline'" in csp else ""))
    out["xcto"] = ("pass", "nosniff") if h.get("x-content-type-options", "").strip().lower() == "nosniff" else ("fail", "Not set to nosniff.")
    out["framing"] = ("pass", "Restricted.") if "frame-ancestors" in (csp or "") or h.get("x-frame-options", "").upper() in ("DENY", "SAMEORIGIN") else ("fail", "No frame-ancestors or X-Frame-Options.")
    out["referrer"] = ("pass", h["referrer-policy"]) if "referrer-policy" in h else ("fail", "Not set.")
    out["permissions"] = ("pass", "Set.") if "permissions-policy" in h else ("fail", "Not set.")
    banner = [f"{n}: {h[n]}" for n in ("server", "x-powered-by") if n in h and re.search(r"\d", h[n])]
    out["cfg_banner"] = ("fail", "Discloses " + "; ".join(banner)) if banner else ("pass", "No version numbers disclosed.")
    if not cookies:
        for i in ("cookie_secure", "cookie_httponly", "cookie_samesite"):
            out[i] = ("na", "No cookies were set on this page. Check pages after sign-in by hand.")
    else:
        names = lambda flag: [c.split("=")[0] for c in cookies if flag not in c.lower()]
        for i, flag, label in (("cookie_secure", "secure", "Secure"), ("cookie_httponly", "httponly", "HttpOnly"), ("cookie_samesite", "samesite", "SameSite")):
            miss = names(flag)
            out[i] = ("fail", f"Missing {label}: {', '.join(miss)}") if miss else ("pass", f"All {len(cookies)} cookie(s) set {label}.")
    return {"target": host, "results": {k: {"status": v[0], "note": v[1]} for k, v in out.items()}}


def summarize(answers):
    counts = {s: 0 for s in STATUSES}
    for i in ITEM_IDS:
        counts[answers.get(i, {}).get("status", "unanswered")] += 1
    applicable = counts["pass"] + counts["fail"]
    return {"counts": counts, "score": round(100 * counts["pass"] / applicable) if applicable else None, "total": len(ITEM_IDS)}


def report_sections(name, target, answers):
    s = summarize(answers)
    fails = sorted([ITEM_BY_ID[i] | {"notes": answers[i].get("notes", "")} for i in ITEM_IDS if answers.get(i, {}).get("status") == "fail"], key=lambda x: (RANK[x["severity"]], x["category"]))
    sections = [{"title": "Summary", "paragraphs": [f"Assessment: {name}." + (f" Target: {target}." if target else ""),
                f"{s['counts']['pass']} passed, {s['counts']['fail']} failed, {s['counts']['na']} not applicable and {s['counts']['unanswered']} not yet checked out of {s['total']} items." + (f" Score on answered applicable items: {s['score']}%." if s["score"] is not None else "")]}]
    if fails:
        sections.append({"title": "Findings", "table": {"head": ["Severity", "Area", "Finding", "Recommendation", "Notes"], "rows": [[f["severity"].title(), f["category"], f["title"], f["recommendation"], f["notes"]] for f in fails]}})
    else:
        sections.append({"title": "Findings", "paragraphs": ["No failed items were recorded."]})
    rest = [i for i in ITEM_BY_ID.values() if answers.get(i["id"], {}).get("status", "unanswered") == "unanswered"]
    if rest:
        sections.append({"title": "Not yet checked", "items": [f"{i['category']}: {i['title']}" for i in rest]})
    return sections
