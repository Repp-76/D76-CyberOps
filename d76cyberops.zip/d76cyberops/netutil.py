"""Outbound HTTP for the API Workbench. Connects to the address it validated (no re-resolution),
blocks private/local targets unless the caller opts in, and caps what it reads."""
import http.client
import ipaddress
import socket
import ssl
import urllib.parse

REDIRECTS = (301, 302, 303, 307, 308)


class NetError(Exception):
    pass


def is_private(ip):
    addr = ipaddress.ip_address(ip)
    if addr.version == 6 and addr.ipv4_mapped:
        addr = addr.ipv4_mapped
    return not addr.is_global


def resolve(host, port, allow_private):
    try:
        infos = socket.getaddrinfo(host, port, type=socket.SOCK_STREAM)
    except socket.gaierror as e:
        raise NetError(f"Could not resolve {host} ({e.strerror or e}).") from None
    ips = []
    for info in infos:
        ip = info[4][0].split("%")[0]
        if ip not in ips:
            ips.append(ip)
    if not ips:
        raise NetError(f"{host} has no address.")
    if allow_private:
        return ips[0]
    public = [ip for ip in ips if not is_private(ip)]
    if not public:
        raise NetError(f"{host} resolves to a private or local address ({ips[0]}). "
                       "Tick the local or lab target option if you are authorized to test it.")
    return public[0]


def _unverified():
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    return ctx


class _Secure(http.client.HTTPSConnection):
    def __init__(self, host, ip, port, timeout, context):
        super().__init__(host, port, timeout=timeout, context=context)
        self._ip = ip

    def connect(self):
        raw = socket.create_connection((self._ip, self.port), self.timeout)
        self.sock = self._context.wrap_socket(raw, server_hostname=self.host)
        # http.client drops the socket once the response is complete, so keep the TLS details now.
        self.tls_info = {"version": self.sock.version(), "cipher": (self.sock.cipher() or [None])[0]}


class _Plain(http.client.HTTPConnection):
    def __init__(self, host, ip, port, timeout):
        super().__init__(host, port, timeout=timeout)
        self._ip = ip

    def connect(self):
        self.sock = socket.create_connection((self._ip, self.port), self.timeout)


def header(headers, name):
    for k, v in headers:
        if k.lower() == name.lower():
            return v
    return None


def request(url, method="GET", headers=None, body=None, allow_private=False, timeout=10,
            verify=True, read_limit=0):
    parts = urllib.parse.urlsplit(url)
    if parts.scheme not in ("http", "https") or not parts.hostname:
        raise NetError("Only http:// and https:// URLs are supported.")
    host, secure = parts.hostname, parts.scheme == "https"
    try:
        port = parts.port or (443 if secure else 80)
    except ValueError:
        raise NetError("That URL has an invalid port.") from None
    ip = resolve(host, port, allow_private)
    path = (parts.path or "/") + ("?" + parts.query if parts.query else "")
    hdrs = {"User-Agent": "D76-CyberOps/0.3", "Accept": "*/*", "Accept-Encoding": "identity", "Connection": "close"}
    hdrs.update(headers or {})

    def attempt(ctx):
        conn = _Secure(host, ip, port, timeout, ctx) if secure else _Plain(host, ip, port, timeout)
        try:
            conn.request(method, path, body=body, headers=hdrs)
            resp = conn.getresponse()
            data = resp.read(read_limit + 1) if read_limit and method != "HEAD" else b""
            tls = dict(conn.tls_info) if secure and hasattr(conn, "tls_info") else None
            return {"status": resp.status, "reason": resp.reason, "headers": resp.getheaders(),
                    "http_version": "HTTP/1.1" if resp.version == 11 else "HTTP/1.0", "body": data, "tls": tls, "ip": ip}
        finally:
            conn.close()

    try:
        if not secure:
            return attempt(None)
        try:
            out = attempt(ssl.create_default_context() if verify else _unverified())
            out["tls"]["verified"] = bool(verify)
            return out
        except ssl.SSLCertVerificationError as e:
            reason = e.verify_message or str(e)
            out = attempt(_unverified())
            out["tls"].update(verified=False, error=reason)
            return out
    except ssl.SSLError as e:
        raise NetError(f"TLS handshake failed: {e.reason or e}") from None
    except socket.timeout:
        raise NetError(f"The server did not answer within {timeout} seconds.") from None
    except ConnectionRefusedError:
        raise NetError(f"Connection refused by {host}:{port}.") from None
    except http.client.HTTPException as e:
        raise NetError(f"The server sent an invalid HTTP response ({type(e).__name__}).") from None
    except OSError as e:
        raise NetError(f"Connection failed: {e.strerror or e}") from None



def tls_probe(host, port=443, allow_private=False, timeout=8, context=None):
    """Handshake with host:port and return protocol details and the decoded certificate."""
    import certs
    ip = resolve(host, port, allow_private)
    out = {"ip": ip, "port": port}

    def handshake(ctx):
        raw = socket.create_connection((ip, port), timeout)
        try:
            tls = ctx.wrap_socket(raw, server_hostname=host)
        except Exception:
            raw.close()
            raise
        with tls:
            return {"version": tls.version(), "cipher": (tls.cipher() or [None])[0], "alpn": tls.selected_alpn_protocol(), "der": tls.getpeercert(True)}

    try:
        try:
            info = handshake(context or ssl.create_default_context())
            out["verified"] = True
        except ssl.SSLCertVerificationError as e:
            out.update(verified=False, error=e.verify_message or str(e))
            info = handshake(_unverified())
        der = info.pop("der")
        out.update(info)
        if der:
            try:
                out["certificate"] = certs.parse_certificate(der)
            except (certs.DerError, ValueError, IndexError):
                out["certificate_error"] = "The certificate was received but could not be decoded."
    except ssl.SSLError as e:
        raise NetError(f"TLS handshake failed: {e.reason or e}") from None
    except socket.timeout:
        raise NetError(f"The server did not answer within {timeout} seconds.") from None
    except ConnectionRefusedError:
        raise NetError(f"Connection refused by {host}:{port}.") from None
    except OSError as e:
        raise NetError(f"Connection failed: {e.strerror or e}") from None
    return out
