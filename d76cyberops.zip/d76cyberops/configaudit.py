"""Audits configuration files for exposed secrets and risky settings. Secret values are never returned."""
import configparser
import json
import re

try:
    import tomllib
except ImportError:  # Python 3.9 and 3.10
    tomllib = None

MAX_BYTES = 2 * 1024 * 1024

SECRET_KEY = re.compile(r"(pass(word|wd)?|secret|token|api[_-]?key|apikey|private[_-]?key|access[_-]?key|auth[_-]?key|credential|client[_-]?secret|signing[_-]?key|encryption[_-]?key)", re.I)
NOT_SECRET = re.compile(r"(_file|_path|_url|_uri|_header|_name|_type|_length|_min|_max|expires?|ttl|timeout|policy|required|enabled|field|hint|reset|prompt|_ref|_arn|_id)$", re.I)
PLACEHOLDER = re.compile(r"^(|<.*>|\$\{.*\}|\$\(.*\)|%\(.*\)s|\{\{.*\}\}|x+|\*+|\.\.\.|your[-_ ].*|example.*|changeme|change[-_ ]me|replace[-_ ].*|todo|none|null|true|false|.*process\.env.*|.*os\.environ.*|.*getenv.*|env\(.*)$", re.I)
WEAK = {"password", "secret", "admin", "root", "123456", "12345678", "test", "default", "letmein", "qwerty", "password1", "admin123", "toor", "pass", "1234"}
TOKEN_PATTERNS = [
    ("AWS access key ID", re.compile(r"\bAKIA[0-9A-Z]{16}\b")), ("GitHub token", re.compile(r"\bgh[pousr]_[A-Za-z0-9]{36,}\b")),
    ("Slack token", re.compile(r"\bxox[baprs]-[A-Za-z0-9-]{10,}")), ("Google API key", re.compile(r"\bAIza[0-9A-Za-z_-]{35}\b")),
    ("Stripe live key", re.compile(r"\bsk_live_[0-9a-zA-Z]{20,}")), ("JSON Web Token", re.compile(r"\beyJ[\w-]{10,}\.[\w-]{10,}\.[\w-]{10,}")),
    ("Private key block", re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----")),
]
URL_CREDS = re.compile(r"\b[a-z][a-z0-9+.-]*://[^/\s:@]+:[^/\s@]+@", re.I)
ENV_LINE = re.compile(r"^\s*(?:export\s+)?([A-Za-z_][\w.-]*)\s*=\s*(.*)$")
JSON_LINE = re.compile(r'^\s*"([^"]+)"\s*:\s*(.*?),?\s*$')
YAML_LINE = re.compile(r"^\s*(?:-\s+)?([A-Za-z_][\w.-]*)\s*:\s*(.*)$")
TRUE = {"true", "1", "yes", "on", "enabled"}
FALSE = {"false", "0", "no", "off", "disabled"}


def mask(value):
    return f"[hidden, {len(value)} characters]"


def unquote(v):
    v = v.strip()
    if len(v) >= 2 and v[0] == v[-1] and v[0] in "\"'":
        return v[1:-1]
    return re.sub(r"\s+#.*$", "", v).strip()


def finding(sev, rule, line, key, detail, fix, value=None):
    return {"severity": sev, "rule": rule, "line": line, "key": key, "detail": detail, "value": value, "recommendation": fix}


def pairs_from(text, fmt):
    """Yields (line number or None, key, value) from the configuration text."""
    lines = text.splitlines()
    if fmt == "json":
        try:
            data = json.loads(text)
        except ValueError:
            data = None
        if data is not None:
            def walk(node, path):
                if isinstance(node, dict):
                    for k, v in node.items():
                        yield from walk(v, path + [str(k)])
                elif isinstance(node, list):
                    for i, v in enumerate(node):
                        yield from walk(v, path + [str(i)])
                elif node is not None and not isinstance(node, bool):
                    key = ".".join(path)
                    ln = next((i + 1 for i, l in enumerate(lines) if f'"{path[-1]}"' in l), None)
                    yield ln, key, str(node)
                elif isinstance(node, bool):
                    yield next((i + 1 for i, l in enumerate(lines) if f'"{path[-1]}"' in l), None), ".".join(path), str(node).lower()
            yield from walk(data, [])
            return
    for i, line in enumerate(lines, 1):
        s = line.strip()
        if not s or s.startswith(("#", ";", "//", "[")):
            continue
        for rx in (ENV_LINE, JSON_LINE, YAML_LINE):
            m = rx.match(line)
            if m:
                yield i, m.group(1), unquote(m.group(2).rstrip(","))
                break


def detect_format(name, text):
    low = name.lower()
    if low.endswith(".json"):
        return "json"
    if low.endswith((".ini", ".cfg", ".conf", ".toml", ".yml", ".yaml")):
        pass  # the extension decides below
    elif text.lstrip().startswith("{"):
        return "json"
    elif text.lstrip().startswith("["):
        try:
            json.loads(text)
            return "json"
        except ValueError:
            pass  # an INI or TOML section header, not JSON
    if low.endswith((".yml", ".yaml")):
        return "yaml"
    if low.endswith(".toml"):
        return "toml"
    if low.endswith((".ini", ".cfg", ".conf")):
        return "ini"
    if "env" in low:
        return "env"
    return "text"


def check_syntax(fmt, text):
    try:
        if fmt == "json":
            json.loads(text)
        elif fmt == "toml" and tomllib:
            tomllib.loads(text)
        elif fmt == "ini":
            configparser.ConfigParser(interpolation=None, allow_no_value=True, strict=False).read_string(text)
        elif fmt == "yaml":
            return {"ok": True, "message": "YAML is scanned line by line, not fully parsed."}
        elif fmt == "toml":
            return {"ok": True, "message": "TOML syntax was not validated on this Python version."}
        return {"ok": True, "message": None}
    except json.JSONDecodeError as e:
        return {"ok": False, "message": f"Invalid JSON at line {e.lineno}, column {e.colno}: {e.msg}."}
    except configparser.MissingSectionHeaderError:
        return {"ok": False, "message": "There are settings before the first [section] header, so this is not valid INI."}
    except Exception as e:  # tomllib and configparser raise several types
        # Never echo the library's message: some of them quote the offending line, which may hold a secret.
        m = re.search(r"line (\d+)", str(e), re.I)
        return {"ok": False, "message": f"The file does not parse as {fmt.upper()}" + (f" (around line {m.group(1)})." if m else ".")}


def audit_text(name, text):
    if len(text.encode("utf-8", "replace")) > MAX_BYTES:
        raise ValueError(f"{name} is larger than 2 MB.")
    fmt = detect_format(name, text)
    findings, seen = [], set()

    def add(f):
        k = (f["rule"], f["line"], f["key"])
        if k not in seen:
            seen.add(k)
            findings.append(f)

    for n, raw in enumerate(text.splitlines(), 1):
        for label, rx in TOKEN_PATTERNS:
            if rx.search(raw):
                add(finding("critical", "Known credential format", n, None, f"The line contains something shaped like a {label}.", "Revoke and replace it now. Removing it from the file does not make it safe if it was ever shared or committed."))
        if URL_CREDS.search(raw):
            add(finding("high", "Credentials inside a URL", n, None, "A connection URL contains a username and password.", "Move the password to a separate secret, and keep only host and database in the URL."))
    for ln, key, value in pairs_from(text, fmt):
        low_key, low_val = key.lower().rsplit(".", 1)[-1], value.lower()
        if SECRET_KEY.search(key) and not NOT_SECRET.search(key.rsplit(".", 1)[-1]) and value and not PLACEHOLDER.match(value):
            if low_val in WEAK:
                add(finding("high", "Weak or default credential", ln, key, f"The value for '{key}' is a well-known weak password.", "Use a long random value from a password manager or secrets store.", mask(value)))
            else:
                add(finding("high", "Plaintext credential", ln, key, f"'{key}' holds what looks like a real secret in plain text.", "Load it from an environment variable or a secrets manager, and keep this file out of version control.", mask(value)))
            if re.search(r"(secret_key|signing_key|jwt_secret|app_key|encryption_key)", low_key) and 0 < len(value) < 16:
                add(finding("high", "Short secret key", ln, key, f"'{key}' is only {len(value)} characters.", "Use at least 32 random characters.", mask(value)))
        if re.fullmatch(r"(debug|app_debug|flask_debug|django_debug|debug_mode|development_mode)", low_key) and low_val in TRUE:
            add(finding("medium", "Debug mode enabled", ln, key, "Debug mode can expose stack traces, configuration and sometimes an interactive console.", "Turn it off outside local development.", value))
        if re.fullmatch(r"(node_env|app_env|flask_env|environment|rails_env)", low_key) and low_val in ("development", "dev", "debug"):
            add(finding("low", "Development environment setting", ln, key, "The environment is set to development.", "Make sure production uses a production setting.", value))
        if re.search(r"(verify|ssl_verify|verify_ssl|strict_ssl|rejectunauthorized|check_hostname|tls_verify)", low_key) and low_val in FALSE:
            add(finding("high", "Certificate checking disabled", ln, key, "TLS certificate verification is switched off, which allows interception.", "Enable verification and trust the right CA instead.", value))
        elif re.fullmatch(r"(secure|cookie_secure|session_cookie_secure|ssl|tls|https|force_https)", low_key) and low_val in FALSE:
            add(finding("medium", "Secure transport setting disabled", ln, key, "A setting that protects traffic or cookies is off.", "Enable it so cookies and traffic use HTTPS only.", value))
        if re.search(r"httponly", low_key) and low_val in FALSE:
            add(finding("medium", "HttpOnly disabled", ln, key, "Cookies will be readable by page scripts.", "Enable HttpOnly for session cookies.", value))
        if re.search(r"(allow[_-]?origins?|cors[_-]?origins?|access-control-allow-origin|allowed[_-]?hosts)", low_key) and "*" in value:
            add(finding("medium", "Wildcard origin or host", ln, key, "Any origin or host is accepted.", "List the exact origins or hosts that need access.", value))
        if re.fullmatch(r"(host|bind|listen|bind_address|listen_address)", low_key) and value.strip() in ("0.0.0.0", "::", "[::]"):
            add(finding("low", "Listens on all interfaces", ln, key, "The service accepts connections from every network interface.", "Bind to 127.0.0.1 unless it must be reachable from other machines.", value))
        if re.match(r"http://(?!localhost|127\.|0\.0\.0\.0|\[::1\])", value, re.I) and not key.lower().startswith("xmlns") and "w3.org" not in value:
            add(finding("low", "Unencrypted http:// URL", ln, key, "A URL uses plain HTTP.", "Use https:// for anything beyond local development.", value[:80]))
    order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
    findings.sort(key=lambda f: (order[f["severity"]], f["line"] or 0))
    counts = {s: sum(f["severity"] == s for f in findings) for s in order}
    return {"name": name, "format": fmt, "lines": len(text.splitlines()), "syntax": check_syntax(fmt, text), "findings": findings, "counts": counts}
