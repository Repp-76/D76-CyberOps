import hashlib
import hmac
import json
import os
import secrets
import sys
from importlib.metadata import version as pkg_version

from flask import Flask, Response, abort, jsonify, render_template, request, session
from werkzeug.exceptions import HTTPException

import db
from resources import bp as resources_bp

VERSION = "0.1.0"
LOGO = "https://files.catbox.moe/f0npdt.jpg"
CURRENT_PHASE = 2

app = Flask(__name__)
app.secret_key = os.environ.get("D76_SECRET") or secrets.token_hex(32)
app.config.update(
    MAX_CONTENT_LENGTH=1024**3,
    SESSION_COOKIE_SAMESITE="Strict",
    SESSION_COOKIE_HTTPONLY=True,
)

# slug, name, group, icon, phase, summary
_TOOLS = [
    ("osint", "OSINT Explorer", "Intelligence", "eye", 2, "Research cases, entities and relationship maps built from your own input and public sources."),
    ("reconnote", "ReconNote", "Intelligence", "clipboard", 2, "Scope, observations and findings for authorized assessments."),
    ("threatintel", "Threat Intel", "Intelligence", "alert", 3, "Advisory, CVE and RSS feed aggregation with caching and bookmarks."),
    ("domain", "Domain Inspector", "Network", "globe", 3, "DNS records, TLS certificate, redirects and response headers."),
    ("password", "Password Auditor", "Security", "key", 1, "Strength analysis that runs entirely in your browser."),
    ("checklist", "Security Checklist", "Security", "list", 3, "Self-assessment across HTTPS, headers, cookies, secrets and more."),
    ("configaudit", "ConfigAudit", "Security", "bug", 3, "Finds exposed secrets and weak settings in your config files."),
    ("devkit", "DevKit", "Developer", "code", 1, "JSON, Base64, URL, hashes, UUIDs, timestamps, regex, diff and color tools."),
    ("terminal", "Terminal", "Developer", "terminal", 4, "Local command runner with an allowlist policy."),
    ("codevault", "CodeVault", "Developer", "folder", 2, "Snippet library with tags, search and import/export."),
    ("nova", "Nova CLI", "Developer", "spark", 4, "Command-line assistant for code, logs and security questions."),
    ("casevault", "CaseVault", "Forensics", "database", 2, "Cases and evidence records with SHA-256 integrity checks."),
    ("loganalyzer", "LogAnalyzer", "Forensics", "search", 3, "Parse, filter and summarize text logs."),
    ("filehash", "FileHash", "Forensics", "hash", 1, "SHA-256, SHA-512, SHA-1 and MD5 for files, with comparison and export."),
    ("backupguard", "BackupGuard", "Forensics", "archive", 4, "Local backups with change detection and checksum verification."),
    ("netwatch", "NetWatch", "Monitoring", "network", 4, "Latency, DNS and connectivity checks for hosts you configure."),
    ("reportgen", "ReportGen", "Reports", "report", 4, "HTML, Markdown and JSON reports from your cases and results."),
    ("kb", "Knowledge Base", "Knowledge Base", "book", 2, "Searchable articles on security, networking, Linux and privacy."),
    ("board", "Operations Board", "Operations", "board", 2, "Kanban board for projects and tasks."),
]
TOOLS = [
    dict(slug=s, name=n, group=g, icon=i, phase=p, summary=d, built=(p <= CURRENT_PHASE))
    for s, n, g, i, p, d in _TOOLS
]
TOOL_BY_SLUG = {t["slug"]: t for t in TOOLS}
GROUPS = []
for _t in TOOLS:
    if not GROUPS or GROUPS[-1][0] != _t["group"]:
        GROUPS.append((_t["group"], []))
    GROUPS[-1][1].append(_t)

SEARCH = {
    # key: label, table, title column, body column, tool, link-id column, link param, extra condition
    "cases": ("Cases", "cases", "title", "description", "casevault", "id", "case", "kind = 'case'"),
    "research": ("Research cases", "cases", "title", "description", "osint", "id", "case", "kind = 'research'"),
    "notes": ("Case notes", "notes", "title", "body", "casevault", "case_id", "case", None),
    "evidence": ("Evidence", "evidence", "title", "description", "casevault", "case_id", "case", None),
    "entities": ("OSINT entities", "entities", "label", "notes", "osint", "case_id", "case", None),
    "recon": ("ReconNote", "recon", "target", "observations", "reconnote", "id", "note", None),
    "snippets": ("Snippets", "snippets", "title", "body", "codevault", "id", "snippet", None),
    "kb": ("Knowledge Base", "kb_articles", "title", "body", "kb", "id", "article", None),
    "tasks": ("Tasks", "tasks", "title", "notes", "board", "project_id", "project", None),
    "reports": ("Reports", "reports", "title", "kind", "reportgen", "id", "report", None),
}
ALGOS = ("sha256", "sha512", "sha1", "md5")

db.init()
app.register_blueprint(resources_bp)


def seed_kb():
    if db.get_settings().get("kb_seeded") == "1":
        return
    from kb_seed import ARTICLES
    now = db.now()
    for title, category, tags, body in ARTICLES:
        db.run("INSERT INTO kb_articles (title, category, body, tags, created, updated) VALUES (?, ?, ?, ?, ?, ?)",
               (title, category, body, tags, now, now))
    db.set_settings({"kb_seeded": "1"})


seed_kb()


def human_size(n):
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024


def err(message, code=400):
    return jsonify(error=message), code


@app.before_request
def guard():
    allowed = {"127.0.0.1", "localhost", "[::1]"}
    allowed.update(h.strip() for h in os.environ.get("D76_ALLOWED_HOSTS", "").split(",") if h.strip())
    if request.host.rsplit(":", 1)[0] not in allowed and request.host not in allowed:
        abort(400, "Host not allowed. Add it to D76_ALLOWED_HOSTS if this is intentional.")
    if "csrf" not in session:
        session["csrf"] = secrets.token_hex(16)
    if request.method in ("POST", "PUT", "DELETE"):
        sent = request.headers.get("X-CSRF-Token", "")
        if not hmac.compare_digest(sent, session["csrf"]):
            abort(403, "Missing or invalid request token. Reload the page and try again.")


@app.after_request
def headers(resp):
    resp.headers["X-Content-Type-Options"] = "nosniff"
    resp.headers["X-Frame-Options"] = "DENY"
    resp.headers["Referrer-Policy"] = "no-referrer"
    resp.headers["Content-Security-Policy"] = (
        "default-src 'self'; img-src 'self' https://files.catbox.moe data:; "
        "frame-ancestors 'none'; base-uri 'none'; form-action 'self'"
    )
    return resp


@app.context_processor
def shared():
    return dict(settings=db.get_settings(), csrf=session.get("csrf", ""), groups=GROUPS,
                logo=LOGO, version=VERSION, phase=CURRENT_PHASE, active="")


@app.errorhandler(HTTPException)
def http_error(e):
    message = "File is too large for this server (limit 1 GB)." if e.code == 413 else e.description
    if request.path.startswith("/api/"):
        return err(message, e.code)
    return render_template("error.html", code=e.code, name=e.name, message=message), e.code


@app.errorhandler(Exception)
def crash(e):
    app.logger.exception(e)
    detail = f" ({type(e).__name__}: {e})" if db.get_settings().get("debug") == "1" else ""
    message = "Something went wrong on the server. Check the terminal for details." + detail
    if request.path.startswith("/api/"):
        return err(message, 500)
    return render_template("error.html", code=500, name="Server error", message=message), 500


@app.get("/")
def hub():
    row = db.query("SELECT COUNT(*) AS n FROM activity")[0]["n"]
    cases = db.query("SELECT COUNT(*) AS n FROM cases")[0]["n"]
    size = db.DB_PATH.stat().st_size if db.DB_PATH.exists() else 0
    return render_template(
        "hub.html", active="hub", tools=TOOLS,
        installed=sum(t["built"] for t in TOOLS) + 1, total=len(TOOLS) + 1,
        events=row, cases=cases, db_size=human_size(size), py=sys.version.split()[0],
        flask_version=pkg_version("flask"), data_dir=str(db.DATA_DIR),
        writable=os.access(db.DATA_DIR, os.W_OK),
        recent=db.query("SELECT ts, tool, event FROM activity ORDER BY id DESC LIMIT 8"),
    )


@app.get("/tools/<slug>")
def tool(slug):
    t = TOOL_BY_SLUG.get(slug)
    if not t:
        abort(404)
    if not t["built"]:
        return render_template("pending.html", active=slug, tool=t)
    db.log(t["name"], "Tool opened")
    return render_template(f"tool_{slug}.html", active=slug, tool=t)


@app.get("/search")
def search_page():
    return render_template("search.html", active="search", types=SEARCH)


@app.get("/activity")
def activity_page():
    tool_filter = request.args.get("tool", "")
    if tool_filter:
        rows = db.query("SELECT ts, tool, event FROM activity WHERE tool = ? ORDER BY id DESC LIMIT 200", (tool_filter,))
    else:
        rows = db.query("SELECT ts, tool, event FROM activity ORDER BY id DESC LIMIT 200")
    names = [r["tool"] for r in db.query("SELECT DISTINCT tool FROM activity ORDER BY tool")]
    return render_template("activity.html", active="activity", rows=rows, names=names, selected=tool_filter)


@app.get("/settings")
def settings_page():
    size = db.DB_PATH.stat().st_size if db.DB_PATH.exists() else 0
    return render_template("settings.html", active="settings", data_dir=str(db.DATA_DIR),
                           db_path=str(db.DB_PATH), db_size=human_size(size))


@app.get("/api/search")
def api_search():
    q = request.args.get("q", "").strip()
    kind = request.args.get("type", "all")
    if len(q) < 2:
        return err("Type at least 2 characters to search.")
    if kind != "all" and kind not in SEARCH:
        return err("Unknown content type.")
    like = "%" + q.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
    results = []
    for key, (label, table, title_col, body_col, slug, ref_col, param, extra) in SEARCH.items():
        if kind not in ("all", key):
            continue
        cond = f"({title_col} LIKE ? ESCAPE '\\' OR {body_col} LIKE ? ESCAPE '\\')" + (f" AND {extra}" if extra else "")
        rows = db.query(
            f"SELECT id, {title_col} AS title, substr({body_col}, 1, 160) AS excerpt, {ref_col} AS ref "
            f"FROM {table} WHERE {cond} ORDER BY id DESC LIMIT 25", (like, like))
        for r in rows:
            results.append(dict(r, type=label, tool=slug, param=param, built=TOOL_BY_SLUG[slug]["built"]))
    return jsonify(results=results, query=q)


@app.post("/api/hash")
def api_hash():
    files = request.files.getlist("files")
    algos = [a for a in request.form.getlist("algo") if a in ALGOS] or ["sha256"]
    if not files:
        return err("Choose at least one file to hash.")
    results = []
    for f in files:
        digests = {a: hashlib.new(a, usedforsecurity=False) for a in algos}
        size = 0
        while chunk := f.stream.read(1024 * 1024):
            size += len(chunk)
            for d in digests.values():
                d.update(chunk)
        results.append({
            "name": os.path.basename(f.filename or "unnamed")[:255],
            "size": size,
            "hashes": {a: d.hexdigest() for a, d in digests.items()},
        })
    db.log("FileHash", f"Hash calculated ({len(results)} file{'s' if len(results) != 1 else ''})")
    return jsonify(results=results, generated=db.now())


def clean_settings(data):
    out = {}
    if data.get("theme") in ("dark", "light"):
        out["theme"] = data["theme"]
    if "debug" in data:
        out["debug"] = "1" if data["debug"] in (True, 1, "1", "true") else "0"
    return out


@app.post("/api/settings")
def api_settings():
    values = clean_settings(request.get_json(silent=True) or {})
    if not values:
        return err("No valid settings were provided.")
    db.set_settings(values)
    db.log("Settings", "Settings updated")
    return jsonify(ok=True, settings=db.get_settings())


@app.get("/api/export")
def api_export():
    stamp = db.now()[:10]
    return Response(json.dumps(db.dump(), indent=2), mimetype="application/json",
                    headers={"Content-Disposition": f'attachment; filename="d76-export-{stamp}.json"'})


@app.post("/api/import")
def api_import():
    upload = request.files.get("file")
    if not upload:
        return err("Choose a D76 export file (.json) to import.")
    try:
        data = json.loads(upload.stream.read(50 * 1024 * 1024).decode("utf-8"))
    except (ValueError, UnicodeDecodeError):
        return err("That file is not valid JSON.")
    if not isinstance(data, dict):
        return err("That file is not a D76 export.")
    counts = db.restore(data)
    if isinstance(data.get("settings"), dict):
        db.set_settings(clean_settings(data["settings"]))
    db.log("Settings", "Data imported")
    return jsonify(ok=True, imported=counts)


@app.post("/api/reset")
def api_reset():
    body = request.get_json(silent=True) or {}
    if body.get("confirm") != "RESET":
        return err("Type RESET to confirm.")
    everything = body.get("scope") == "all"
    db.wipe(everything)
    if everything:
        seed_kb()
    if not everything:
        db.log("Settings", "Activity log cleared")
    return jsonify(ok=True)


if __name__ == "__main__":
    host = os.environ.get("D76_HOST", "127.0.0.1")
    port = int(os.environ.get("D76_PORT", "5076"))
    print(f"D76 CyberOps {VERSION} running at http://{host}:{port}")
    app.run(host=host, port=port, debug=False)
