# D76 CyberOps

D76 CyberOps is a local-first toolkit for authorized security research, analysis and administration. It runs on your own machine as a small Flask app with a SQLite database. No tool in it produces simulated results: when something cannot run (missing dependency, no permission, no network), the interface says so.

It is built in phases. **This package is phase 3** and includes everything from phases 1 and 2.

| Phase | Tools |
|---|---|
| 1 | Intelligence Hub, DevKit, Password Auditor, FileHash, Settings, Activity log, Global search |
| 2 | CaseVault, OSINT Explorer, ReconNote, CodeVault, Knowledge Base, Operations Board |
| 3 (this build) | HeaderLab, JWT Inspector, API Workbench, OpenAPI Auditor, Subnet Calculator, CipherBox, OTP Lab, Certificate Inspector, Redactor, Metadata Inspector, File Inspector, Mail Header Analyzer, IOC Extractor, Timestamp Decoder, Host Diagnostics, Admin Toolbox, Text Pipelines, DataLens, Docs Studio |
| Not built yet | Threat Intel, Domain Inspector, Security Checklist, ConfigAudit, Terminal, Nova CLI, LogAnalyzer, BackupGuard, NetWatch, ReportGen |

The last row is from the original specification. These ten appear under "Not installed yet" in the sidebar and in the directory, and open a page saying so. Nothing pretends they work.

Press **Ctrl K** (or use "Jump to tool") anywhere to open a tool by name. **All tools** lists every tool with a filter. Sidebar groups remember whether you left them open.

## Requirements

- Python 3.9 or newer
- Flask (the only dependency; see `requirements.txt`)

## Install and run

```bash
python3 -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:5076.

## Configuration

All optional, set as environment variables.

| Variable | Default | Purpose |
|---|---|---|
| `D76_HOST` | `127.0.0.1` | Interface to bind. Keep it on loopback unless you know why you are changing it. |
| `D76_PORT` | `5076` | Port. |
| `D76_DATA` | `./data` | Folder holding the SQLite database. |
| `D76_SECRET` | random per start | Session signing key. Set it if you want sessions to survive restarts. |
| `D76_ALLOWED_HOSTS` | none | Extra `Host` header values to accept (comma separated), for example a tunnel hostname. Requests with any other Host are rejected to block DNS-rebinding. |

## Architecture

```
d76cyberops/
  app.py          routes, JSON API, CSRF and host checks, tool registry
  db.py           SQLite schema and helpers
  templates/      Jinja pages (base layout, hub, one template per tool)
  static/         app.css and one small script per page
  data/           created on first run (d76.db)
```

- Server-rendered pages with plain JavaScript. No frontend framework, no CDN scripts or fonts.
- All state-changing requests need a per-session CSRF token sent in the `X-CSRF-Token` header.
- A Content-Security-Policy limits scripts and styles to the app itself. The only external resource is the D76 logo image.
- The schema for later phases (cases, notes, snippets, tasks, articles, reports) is already created so global search and export cover them as tools arrive.

## Database

`data/d76.db` (SQLite). Tables: `settings`, `activity`, `cases`, `notes`, `evidence`, `entities`, `relations`, `snippets`, `projects`, `tasks`, `task_history`, `kb_articles`, `recon`, `reports`. Databases created by phase 1 are upgraded automatically on start. Use Settings > Export to get a JSON copy, and Import to merge one back. Passwords are never stored. The activity log keeps the latest 2,000 events and records only tool names and event types.

## What is installed in phase 2

- **Intelligence Hub**: tool index, saved case count, recent activity, system status, quick actions, reference links.
- **DevKit**: JSON format/minify/validate, Base64, URL and HTML entity encoding, SHA-1/256/384/512 text hashes, UUID v4 and secure random IDs (rejection sampling, no modulo bias), timestamp converter, regex tester, line diff, color converter. All client-side.
- **Password Auditor**: length, character types, repetition, sequences and keyboard walks, common-password and leetspeak checks, entropy estimate. Runs in the browser; the password is never sent anywhere, saved or logged.
- **FileHash**: SHA-256, SHA-512, SHA-1 and MD5 for one or many files, comparison against a published checksum, JSON and CSV export. Files are streamed to your local server, hashed in 1 MB chunks and discarded. Nothing is written to disk or sent elsewhere. Upload limit is 1 GB per request.
- **CaseVault**: cases with status, investigator and tags; timestamped notes; evidence records with SHA-256. Choosing a file hashes it on your local server and discards it (nothing is stored or modified); you can also record a known hash. Verify later by selecting the file again: the result (match or mismatch) and the time are recorded. Export a case as Markdown, HTML or JSON.
- **OSINT Explorer**: research cases holding entities (person, organization, domain, website, username, URL, note) with source URL, evidence reference, tags, bookmarks, and relationships between entities, shown as a map. Filter by type, tag, text or bookmark; export CSV, Markdown, HTML or JSON. It never looks anything up for you; every entry is yours.
- **ReconNote**: structured notes (target, scope, date, authorization reference, observations, URLs, DNS findings, technology observations, file references). Scope and authorization are required. Markdown and JSON export.
- **CodeVault**: snippets with language (auto-detected or chosen), category, tags, favorites, search, copy, syntax highlighting for HTML, CSS, JavaScript, Python, JSON, SQL and Bash (Markdown and text are shown plain), JSON import and JSON/Markdown export. Snippets are never executed.
- **Knowledge Base**: 11 starter articles across 10 categories, Markdown rendering, search, bookmarks, read status, and your own articles. Starter articles are added once; deleting them does not bring them back (a full reset does).
- **Operations Board**: projects with a four-stage board (Backlog, In progress, Review, Completed), priorities, deadlines with overdue marking, tags, notes, progress, and a history of every task change.
- **Settings**: theme, developer mode, storage info, export/import, reset (requires typing RESET).
- **Activity** and **Search**: local history and search across cases, notes, snippets, articles, tasks and reports.

## What is installed in phase 3

Web security
- **HeaderLab**: paste response headers, a Content-Security-Policy or Set-Cookie lines. Gives a graded review with plain explanations. Nothing is fetched.
- **JWT Inspector**: decodes tokens, flags alg none, missing expiry, risky header fields, and verifies HS256/384/512 signatures against a secret you supply. It does not guess secrets.
- **API Workbench**: send requests to APIs you are authorized to test. Variables (`{{name}}`) live only in the page. Saved requests replace Authorization, Cookie, API-key headers and key-like URL parameters with placeholders; check bodies yourself. Outbound requests block private and local addresses unless you tick the local or lab option, connect to the address that was validated, and cap size and time.
- **OpenAPI Auditor**: static review of an OpenAPI 3 or Swagger 2 document (JSON only).

Cryptography
- **CipherBox**: AES-256-GCM with a PBKDF2-SHA256 key (600,000 iterations by default), in the browser. The header is authenticated; a wrong passphrase or any change is detected. There is no recovery if the passphrase is lost.
- **OTP Lab**: TOTP and HOTP, checked against the RFC 4226 and RFC 6238 test vectors. Verify codes with a drift window; read otpauth links.
- **Certificate Inspector**: decodes PEM certificates, CSRs and public keys with a built-in DER reader; private keys are detected but never decoded.

Privacy, forensics and network
- **Redactor**: masks emails, Malaysian IC numbers (date validated), payment cards (Luhn checked), phone numbers, IPv4 addresses and secrets; strips tracking parameters from links. Pattern based, so review the result.
- **Metadata Inspector**: EXIF (including GPS), XMP, PNG text chunks, PDF properties and Office or OpenDocument properties. JPEG and PNG can be saved as cleaned copies.
- **File Inspector**: real file type from signatures, entropy chart, ASCII and UTF-16 strings, hex view, PE section table and ELF headers. Files are read as bytes and never executed.
- **Mail Header Analyzer**: route and delays, SPF/DKIM/DMARC results, From, Reply-To and Return-Path mismatches. Nothing is looked up online.
- **IOC Extractor**: IPs, domains, URLs, emails, hashes, CVE and ATT&CK IDs, with refanging and defanged output.
- **Timestamp Decoder**: FILETIME, WebKit, Mac, HFS+, Excel, .NET and Unix formats side by side.
- **Subnet Calculator**: details, split, summarize, range to CIDR and membership for IPv4 and IPv6.

System, data and documents
- **Host Diagnostics**: CPU, memory, disks, largest processes and listening TCP ports on the machine running D76. CPU, memory, process and port views need Linux `/proc`; other systems show what is available and say what is not.
- **Admin Toolbox**: cron explainer with next run times (standard day-of-month/day-of-week rule), and chmod, symbolic and umask conversion.
- **Text Pipelines**: chained line transformations, saved to the database.
- **DataLens**: profiles CSV, TSV and JSON arrays (types, gaps, duplicates, possible personal data) and converts between CSV and JSON.
- **Docs Studio**: Markdown editor with templates, export to .md or .html, save to the Knowledge Base, and an RFC 9116 security.txt builder.

## External APIs and permissions

Phases 1 to 3 need no API keys and no elevated permissions. The only tool that makes outbound requests is API Workbench, and only when you press Send (apart from your browser loading the logo and any reference link you click). Later phases: Threat Intel and Domain Inspector need internet access; Nova CLI needs a provider key supplied through an environment variable; Terminal, BackupGuard and NetWatch act on your own machine with your own user permissions.

## Troubleshooting

- **"Host not allowed"**: you opened the app through a hostname other than localhost. Add it to `D76_ALLOWED_HOSTS`.
- **"Missing or invalid request token"**: the page is stale (for example after a server restart). Reload it.
- **Copy button does nothing**: browsers only allow clipboard access on localhost or HTTPS.
- **DevKit hashes say Web Crypto is unavailable**: same cause, open the app over localhost or HTTPS.
- **Port in use**: set `D76_PORT`.
- Turn on developer mode in Settings to see error details in the interface; the full traceback is always printed in the terminal.

## Security notes

- Use these tools only on systems you own or are authorized to assess.
- Bind to loopback. If you expose the app through a tunnel, put authentication in front of it first; the app itself has no login because it is designed for a single local user.
- The Terminal tool in phase 4 will run commands on the host and must never be exposed beyond your machine.
