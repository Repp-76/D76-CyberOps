"""Pure-Python analyzers for HTTP headers, CSP, cookies, JWTs and OpenAPI documents.
Everything works on text the user pastes. Nothing is fetched, stored or logged here."""
import base64
import hashlib
import hmac
import json
import re
from datetime import datetime, timezone


def finding(severity, message):
    return {"severity": severity, "message": message}


# ---------------------------------------------------------------- headers

def parse_headers(raw):
    """Returns (status_line, [(name, value)]). Handles folded lines and a leading status line."""
    lines = raw.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    status, pairs = None, []
    for line in lines:
        if not line.strip():
            continue
        if re.match(r"HTTP/\d", line):
            status = line.strip()
        elif line[0] in " \t" and pairs:
            pairs[-1] = (pairs[-1][0], pairs[-1][1] + " " + line.strip())
        elif ":" in line:
            name, value = line.split(":", 1)
            pairs.append((name.strip(), value.strip()))
    return status, pairs


def parse_csp(policy):
    directives = {}
    for part in policy.split(";"):
        tokens = part.strip().split()
        if tokens:
            directives.setdefault(tokens[0].lower(), tokens[1:])
    return directives


def analyze_csp(policy):
    d = parse_csp(policy)
    out = []
    if not d:
        return {"directives": {}, "findings": [finding("bad", "The policy is empty.")]}
    script = d.get("script-src", d.get("default-src"))
    strict = script is not None and any(t.startswith(("'nonce-", "'sha256-", "'sha384-", "'sha512-")) or t == "'strict-dynamic'" for t in script)
    if "default-src" not in d and "script-src" not in d:
        out.append(finding("bad", "No default-src or script-src, so scripts are not restricted."))
    if script is not None:
        if "'unsafe-inline'" in script and not strict:
            out.append(finding("bad", "script-src allows 'unsafe-inline', which defeats most of the protection against injected scripts. Use nonces or hashes."))
        if "'unsafe-eval'" in script:
            out.append(finding("warn", "script-src allows 'unsafe-eval' (eval and similar). Remove it if you can."))
        for t in script:
            if t in ("*", "https:", "http:", "data:"):
                out.append(finding("bad", f"script-src allows {t}, which lets scripts load from almost anywhere."))
            elif t.startswith("*.") or t.startswith("http://"):
                out.append(finding("warn", f"script-src includes {t}; wildcard and plain-http sources are weak."))
    if "object-src" not in d and not ("default-src" in d and d["default-src"] == ["'none'"]):
        out.append(finding("warn", "object-src is not set. Use object-src 'none'."))
    if "base-uri" not in d:
        out.append(finding("warn", "base-uri is not set. Use base-uri 'self' or 'none' to stop injected <base> tags."))
    if "frame-ancestors" not in d:
        out.append(finding("warn", "frame-ancestors is not set, so other sites may embed this page. Use frame-ancestors 'none' or 'self'."))
    if "form-action" not in d:
        out.append(finding("info", "form-action is not set; forms may post to any origin."))
    if "upgrade-insecure-requests" not in d and "block-all-mixed-content" not in d:
        out.append(finding("info", "Consider upgrade-insecure-requests to avoid mixed content."))
    if "report-uri" in d or "report-to" in d:
        out.append(finding("info", "Violation reporting is configured."))
    if not any(f["severity"] in ("bad", "warn") for f in out):
        out.insert(0, finding("good", "No major weaknesses found in this policy."))
    return {"directives": d, "findings": out}


SESSIONISH = re.compile(r"sess|auth|token|jwt|sid|login|csrf|xsrf", re.I)


def analyze_cookie(line):
    line = re.sub(r"^\s*set-cookie\s*:\s*", "", line, flags=re.I).strip()
    parts = [p.strip() for p in line.split(";")]
    name, _, value = parts[0].partition("=")
    attrs = {}
    for p in parts[1:]:
        k, _, v = p.partition("=")
        attrs[k.strip().lower()] = v.strip()
    f = []
    sensitive = bool(SESSIONISH.search(name))
    if "secure" not in attrs:
        f.append(finding("bad" if sensitive else "warn", "No Secure flag: the cookie can be sent over plain HTTP."))
    if "httponly" not in attrs:
        f.append(finding("bad" if sensitive else "warn", "No HttpOnly flag: page scripts can read this cookie."))
    ss = attrs.get("samesite")
    if ss is None:
        f.append(finding("warn", "No SameSite attribute. Browsers default to Lax, but set it explicitly."))
    elif ss.lower() == "none" and "secure" not in attrs:
        f.append(finding("bad", "SameSite=None requires Secure; browsers reject this cookie."))
    elif ss.lower() == "none":
        f.append(finding("info", "SameSite=None sends the cookie on cross-site requests. Make sure that is intended."))
    if name.startswith("__Host-"):
        if "secure" not in attrs or attrs.get("path") != "/" or "domain" in attrs:
            f.append(finding("bad", "The __Host- prefix requires Secure, Path=/ and no Domain attribute."))
    elif name.startswith("__Secure-") and "secure" not in attrs:
        f.append(finding("bad", "The __Secure- prefix requires the Secure flag."))
    elif sensitive and not name.startswith(("__Host-", "__Secure-")):
        f.append(finding("info", "Consider the __Host- name prefix for session cookies."))
    if "domain" in attrs:
        f.append(finding("info", f"Domain={attrs['domain']} makes the cookie available to subdomains."))
    if "max-age" not in attrs and "expires" not in attrs:
        f.append(finding("info", "Session cookie (no expiry); it is removed when the browser closes."))
    if not f:
        f.append(finding("good", "Flags look sound."))
    return {"name": name, "value": "[hidden]" if value else "", "attributes": attrs, "sensitive_name": sensitive, "findings": f}


def analyze_headers(raw):
    status, pairs = parse_headers(raw)
    if not pairs:
        raise ValueError("No headers found. Paste the response headers, one per line as Name: value.")
    h = {}
    for k, v in pairs:
        h.setdefault(k.lower(), []).append(v)
    first = lambda n: h[n][0] if n in h else None
    checks, score = [], 100

    def add(id_, name, sev, value, message, weight=0):
        nonlocal score
        checks.append({"id": id_, "name": name, "severity": sev, "value": value, "message": message})
        score -= weight if sev in ("bad", "warn") else 0

    v = first("strict-transport-security")
    if v is None:
        add("hsts", "Strict-Transport-Security", "bad", None, "Not set. Browsers will not be told to insist on HTTPS.", 15)
    else:
        m = re.search(r"max-age=(\d+)", v, re.I)
        age = int(m.group(1)) if m else 0
        if age < 15552000:
            add("hsts", "Strict-Transport-Security", "warn", v, f"max-age is {age} seconds. Aim for at least 15552000 (180 days), ideally 31536000.", 7)
        else:
            extra = "" if "includesubdomains" in v.lower() else " Add includeSubDomains once every subdomain supports HTTPS."
            add("hsts", "Strict-Transport-Security", "good", v, "Set with a long max-age." + extra)

    v = first("content-security-policy")
    csp = None
    if v is None:
        add("csp", "Content-Security-Policy", "bad", None, "Not set. This is the main browser defence against injected scripts.", 15)
    else:
        csp = analyze_csp(v)
        worst = "bad" if any(x["severity"] == "bad" for x in csp["findings"]) else "warn" if any(x["severity"] == "warn" for x in csp["findings"]) else "good"
        add("csp", "Content-Security-Policy", worst, v, f"{sum(x['severity'] in ('bad', 'warn') for x in csp['findings'])} issue(s) found. See the CSP tab for details." if worst != "good" else "Policy looks sound.", 10 if worst == "bad" else 4)

    v = first("x-content-type-options")
    if v and v.strip().lower() == "nosniff":
        add("xcto", "X-Content-Type-Options", "good", v, "nosniff stops browsers guessing content types.")
    else:
        add("xcto", "X-Content-Type-Options", "warn", v, "Set it to nosniff.", 7)

    fa = csp and "frame-ancestors" in csp["directives"]
    v = first("x-frame-options")
    if v and v.strip().upper() in ("DENY", "SAMEORIGIN") or fa:
        add("framing", "Clickjacking protection", "good", v or "frame-ancestors", "Framing is restricted.")
    else:
        add("framing", "Clickjacking protection", "warn", v, "Set X-Frame-Options or a CSP frame-ancestors directive.", 7)

    v = first("referrer-policy")
    if v is None:
        add("referrer", "Referrer-Policy", "warn", None, "Not set. Use strict-origin-when-cross-origin or stricter.", 4)
    elif v.strip().lower() in ("unsafe-url", "no-referrer-when-downgrade", "origin-when-cross-origin"):
        add("referrer", "Referrer-Policy", "warn", v, "This value leaks more of the URL than necessary.", 4)
    else:
        add("referrer", "Referrer-Policy", "good", v, "Limits what URL information leaves the site.")

    for id_, name in (("permissions-policy", "Permissions-Policy"),):
        v = first(id_)
        add(id_, name, "good" if v else "info", v, "Restricts browser features such as camera and geolocation." if v else "Not set. Consider disabling features the site does not use.")

    for id_, name in (("cross-origin-opener-policy", "Cross-Origin-Opener-Policy"), ("cross-origin-resource-policy", "Cross-Origin-Resource-Policy"), ("cross-origin-embedder-policy", "Cross-Origin-Embedder-Policy")):
        v = first(id_)
        add(id_, name, "good" if v else "info", v, "Set." if v else "Not set. Optional isolation header.")

    acao, acac = first("access-control-allow-origin"), first("access-control-allow-credentials")
    if acao:
        if acao.strip() == "*" and acac and acac.lower() == "true":
            add("cors", "CORS", "bad", f"Allow-Origin: {acao}, Allow-Credentials: {acac}", "A wildcard origin together with credentials is invalid and signals a misconfiguration.", 10)
        elif acao.strip() == "*":
            add("cors", "CORS", "info", acao, "Any origin may read responses. Fine for public data, wrong for anything user-specific.")
        else:
            add("cors", "CORS", "info", acao, "A specific origin is allowed.")

    for n in ("server", "x-powered-by", "x-aspnet-version", "x-aspnetmvc-version"):
        v = first(n)
        if v and re.search(r"\d", v):
            add("banner-" + n, n.title(), "warn", v, "Discloses software and version. Remove or generalise it.", 3)
        elif v:
            add("banner-" + n, n.title(), "info", v, "Reveals the technology in use.")

    for n, msg in (("x-xss-protection", "Deprecated; modern browsers ignore it. A strong CSP replaces it."),
                   ("expect-ct", "Deprecated; Certificate Transparency is now enforced by browsers."),
                   ("public-key-pins", "Removed from browsers. Remove this header.")):
        if first(n):
            add(n, n, "info", first(n), msg)

    cookies = [analyze_cookie(c) for c in h.get("set-cookie", [])]
    for c in cookies:
        if any(f["severity"] == "bad" for f in c["findings"]):
            score -= 8
        elif any(f["severity"] == "warn" for f in c["findings"]):
            score -= 3
    score = max(0, score)
    grade = "A" if score >= 90 else "B" if score >= 80 else "C" if score >= 65 else "D" if score >= 50 else "F"
    return {"status_line": status, "header_count": len(pairs), "checks": checks, "cookies": cookies,
            "score": score, "grade": grade,
            "note": "The grade is an indicative score from header presence and basic strength, not a security audit."}


# -------------------------------------------------------------------- JWT

def _b64url(part):
    pad = "=" * (-len(part) % 4)
    try:
        return base64.urlsafe_b64decode(part + pad)
    except Exception:
        raise ValueError("A token segment is not valid base64url.") from None


def _when(ts):
    try:
        d = datetime.fromtimestamp(float(ts), timezone.utc)
    except (TypeError, ValueError, OverflowError, OSError):
        return None
    return d.isoformat(timespec="seconds")


def inspect_jwt(token, secret=None, now=None):
    token = token.strip()
    if token.lower().startswith("bearer "):
        token = token[7:].strip()
    parts = token.split(".")
    if len(parts) not in (2, 3) or not all(parts[:2]):
        raise ValueError("A JWT has three dot-separated parts: header.payload.signature.")
    try:
        header = json.loads(_b64url(parts[0]))
        payload = json.loads(_b64url(parts[1]))
    except (json.JSONDecodeError, UnicodeDecodeError):
        raise ValueError("The header or payload is not valid JSON.") from None
    if not isinstance(header, dict) or not isinstance(payload, dict):
        raise ValueError("The header and payload must be JSON objects.")
    now = now or datetime.now(timezone.utc).timestamp()
    f, claims = [], []
    alg = str(header.get("alg", ""))
    if alg.lower() == "none":
        f.append(finding("bad", "alg is 'none': the token is unsigned and anyone can forge it. Servers must reject it."))
    elif alg.startswith("HS"):
        f.append(finding("info", f"{alg} is a shared-secret algorithm. The signing secret must be long and random."))
    elif not alg:
        f.append(finding("bad", "The header has no alg."))
    for k in ("jku", "x5u", "jwk"):
        if k in header:
            f.append(finding("warn", f"The header contains {k}. Servers must never trust a key location or key supplied by the token itself."))
    if "kid" in header and re.search(r"[/\\]|\.\.|'|;", str(header["kid"])):
        f.append(finding("warn", "kid contains path or injection-like characters. Servers must treat it strictly as an identifier."))
    for name in ("iss", "sub", "aud", "jti"):
        if name in payload:
            claims.append({"claim": name, "value": json.dumps(payload[name]) if not isinstance(payload[name], str) else payload[name]})
    for name in ("exp", "nbf", "iat"):
        if name in payload:
            iso = _when(payload[name])
            claims.append({"claim": name, "value": str(payload[name]), "time": iso})
    if "exp" not in payload:
        f.append(finding("warn", "No exp claim: the token never expires."))
    else:
        try:
            exp = float(payload["exp"])
            if exp < now:
                f.append(finding("info", f"Expired {int((now - exp) // 60)} minute(s) ago."))
            else:
                f.append(finding("good", f"Expires in {int((exp - now) // 60)} minute(s)."))
                if exp - now > 365 * 86400:
                    f.append(finding("warn", "The expiry is more than a year away; long-lived tokens are risky if stolen."))
        except (TypeError, ValueError):
            f.append(finding("warn", "exp is not a number."))
    try:
        if "nbf" in payload and float(payload["nbf"]) > now:
            f.append(finding("info", "nbf is in the future: the token is not valid yet."))
    except (TypeError, ValueError):
        pass
    if "aud" not in payload:
        f.append(finding("info", "No aud claim. Without audience checks a token may be accepted by the wrong service."))
    sig = {"present": len(parts) == 3 and bool(parts[2]), "verified": None, "message": None}
    if secret:
        hashes = {"HS256": hashlib.sha256, "HS384": hashlib.sha384, "HS512": hashlib.sha512}
        if alg in hashes and len(parts) == 3:
            mac = hmac.new(secret.encode(), f"{parts[0]}.{parts[1]}".encode(), hashes[alg]).digest()
            try:
                ok = hmac.compare_digest(mac, _b64url(parts[2]))
            except ValueError:
                ok = False
            sig.update(verified=ok, message="The signature is valid for the secret you entered." if ok else "The signature does not match the secret you entered.")
        else:
            sig["message"] = f"Signature verification is only supported for HS256, HS384 and HS512 (this token uses {alg or 'no algorithm'})."
    return {"header": header, "payload": payload, "claims": claims, "findings": f, "signature": sig}


# ---------------------------------------------------------------- OpenAPI

METHODS = ("get", "put", "post", "delete", "options", "head", "patch", "trace")


def audit_openapi(text):
    text = text.strip()
    if not text:
        raise ValueError("Paste an OpenAPI or Swagger document in JSON format.")
    if not text.startswith("{"):
        raise ValueError("This looks like YAML. Only JSON is supported; convert the document to JSON first.")
    try:
        spec = json.loads(text)
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON at line {e.lineno}, column {e.colno}: {e.msg}.") from None
    if "openapi" not in spec and "swagger" not in spec:
        raise ValueError("Not an OpenAPI document: neither an openapi nor a swagger field was found.")
    v3 = "openapi" in spec
    info = spec.get("info", {})
    schemes = spec.get("components", {}).get("securitySchemes", {}) if v3 else spec.get("securityDefinitions", {})
    servers = [s.get("url", "") for s in spec.get("servers", [])] if v3 else [f"{s}://{spec.get('host', '')}{spec.get('basePath', '')}" for s in spec.get("schemes", [])]
    f, ops, seen_ids = [], [], {}
    for s in servers:
        if s.startswith("http://") and not re.match(r"http://(localhost|127\.|\[::1\])", s):
            f.append(finding("warn", f"Server {s} uses plain http."))
    if not schemes:
        f.append(finding("warn", "No security schemes are defined. Either the API is public or authentication is undocumented."))
    for name, s in schemes.items():
        t, loc = s.get("type"), s.get("in")
        if t == "apiKey" and loc == "query":
            f.append(finding("bad", f"Scheme '{name}' sends an API key in the query string. URLs end up in logs, history and referrers; use a header."))
        elif t == "http" and str(s.get("scheme", "")).lower() == "basic" or t == "basic":
            f.append(finding("info", f"Scheme '{name}' uses HTTP Basic authentication; make sure it is only used over HTTPS."))
        elif t == "oauth2" and v3:
            flows = s.get("flows", {})
            if "implicit" in flows or "password" in flows:
                f.append(finding("warn", f"Scheme '{name}' enables the {'implicit' if 'implicit' in flows else 'password'} OAuth flow, which current guidance advises against."))
    global_sec = spec.get("security")
    for path, item in spec.get("paths", {}).items():
        if not isinstance(item, dict):
            continue
        for method in METHODS:
            op = item.get(method)
            if not isinstance(op, dict):
                continue
            sec = op["security"] if "security" in op else global_sec
            open_ = not sec or sec == [{}]
            responses = {str(k) for k in op.get("responses", {})}
            oid = op.get("operationId")
            if oid:
                seen_ids.setdefault(oid, []).append(f"{method.upper()} {path}")
            ops.append({"method": method.upper(), "path": path, "summary": op.get("summary", ""), "operation_id": oid or "",
                        "tags": op.get("tags", []), "authenticated": not open_, "has_body": "requestBody" in op or any(p.get("in") == "body" for p in op.get("parameters", []) if isinstance(p, dict)),
                        "documents_auth_errors": bool(responses & {"401", "403"})})
            if open_ and schemes and method in ("post", "put", "patch", "delete"):
                f.append(finding("bad", f"{method.upper()} {path} changes data but declares no security requirement."))
            elif open_ and schemes:
                f.append(finding("warn", f"{method.upper()} {path} declares no security requirement."))
    for oid, where in seen_ids.items():
        if len(where) > 1:
            f.append(finding("warn", f"operationId '{oid}' is used more than once ({', '.join(where)})."))
    open_count = sum(not o["authenticated"] for o in ops)
    if ops and not any(o["documents_auth_errors"] for o in ops) and schemes:
        f.append(finding("info", "No operation documents 401 or 403 responses."))
    if not f:
        f.append(finding("good", "No issues found by these checks."))
    return {"title": info.get("title", ""), "version": info.get("version", ""), "spec_version": spec.get("openapi") or spec.get("swagger"),
            "servers": servers, "security_schemes": [{"name": n, "type": s.get("type"), "scheme": s.get("scheme") or s.get("in") or s.get("flow", "")} for n, s in schemes.items()],
            "operations": ops, "summary": {"operations": len(ops), "without_security": open_count}, "findings": f,
            "note": "Static review of the document only. It cannot tell what the running API actually enforces."}
