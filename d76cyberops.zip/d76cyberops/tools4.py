"""API routes for the phase 4 tools."""
import io
import json
import os
import platform
import re
import shutil
import time

from flask import Blueprint, Response, abort, jsonify, request, session, stream_with_context

import backup
import checklist
import configaudit
import db
import inspector
import intel
import logparse
import netwatch
import nova
import reportgen
import terminal

bp = Blueprint("tools4", __name__)
LOOPBACK_HOSTS = {"127.0.0.1", "localhost", "[::1]", "::1"}


def err(message, code=400):
    return jsonify(error=message), code


def body():
    return request.get_json(silent=True) or {}


def upload(limit):
    f = request.files.get("file")
    if not f:
        raise ValueError("Choose a file first.")
    data = f.stream.read(limit + 1)
    if len(data) > limit:
        raise ValueError(f"The file is larger than the {limit // (1024 * 1024)} MB limit.")
    return f.filename or "", data


def local_only():
    """Tools that touch this machine only answer to a browser on this machine, never through a proxy or tunnel."""
    host = request.host.rsplit(":", 1)[0] if not request.host.startswith("[") else request.host.split("]")[0] + "]"
    proxied = any(h in request.headers for h in ("X-Forwarded-For", "X-Forwarded-Host", "CF-Connecting-IP", "Forwarded", "X-Real-IP"))
    if host not in LOOPBACK_HOSTS or proxied:
        abort(403, "This tool runs commands or touches files on this machine, so it only works when D76 is opened directly at localhost, "
                   "not through a tunnel, proxy or another hostname.")


# ----------------------------------------------------------- Domain Inspector

@bp.post("/api/domain/inspect")
def domain_inspect():
    try:
        result = inspector.inspect_target(body())
    except ValueError as e:
        return err(str(e))
    db.log("Domain Inspector", "Target inspected")
    return jsonify(result)


# --------------------------------------------------------------- Threat Intel

@bp.get("/api/intel/status")
def intel_status():
    return jsonify(nvd_key=bool(os.environ.get("D76_NVD_API_KEY")), items=db.query("SELECT COUNT(*) n FROM intel_items")[0]["n"])


@bp.post("/api/intel/refresh")
def intel_refresh():
    b = body()
    res = intel.refresh(bool(b.get("force")), int(b["feed_id"]) if str(b.get("feed_id", "")).isdigit() else None)
    db.log("Threat Intel", "Feeds refreshed")
    return jsonify(results=res)


@bp.post("/api/intel/clear")
def intel_clear():
    db.run("DELETE FROM intel_items WHERE bookmarked = 0")
    db.run("UPDATE feeds SET last_fetch = NULL, last_status = ''")
    db.log("Threat Intel", "Cache cleared")
    return jsonify(ok=True)


# ---------------------------------------------------------------- LogAnalyzer

@bp.post("/api/logs/analyze")
def logs_analyze():
    try:
        name, data = upload(logparse.MAX_BYTES)
    except ValueError as e:
        return err(str(e))
    if not data.strip():
        return err("The file is empty.")
    result = logparse.analyze(data.decode("utf-8", "replace").splitlines())
    result["filename"] = name
    db.log("LogAnalyzer", "Log analyzed")
    return jsonify(result)


# ----------------------------------------------------------------- ConfigAudit

@bp.post("/api/config/audit")
def config_audit():
    results = []
    try:
        for f in request.files.getlist("files")[:10]:
            raw = f.stream.read(configaudit.MAX_BYTES + 1)
            if len(raw) > configaudit.MAX_BYTES:
                raise ValueError(f"{f.filename} is larger than 2 MB.")
            results.append(configaudit.audit_text(os.path.basename(f.filename or "file"), raw.decode("utf-8", "replace")))
        pasted = request.form.get("pasted", "")
        if pasted.strip():
            results.append(configaudit.audit_text((request.form.get("pasted_name") or "pasted.env").strip()[:80], pasted))
    except ValueError as e:
        return err(str(e))
    if not results:
        return err("Choose one or more files, or paste some configuration.")
    db.log("ConfigAudit", "Configuration checked")
    return jsonify(results=results, note="Matched secret values are never shown, stored or logged.")


# ------------------------------------------------------------ Security Checklist

@bp.get("/api/checklist/items")
def checklist_items():
    return jsonify(categories=checklist.CATEGORIES, items=list(checklist.ITEM_BY_ID.values()))


@bp.post("/api/checklists/<int:cid>/auto")
def checklist_auto(cid):
    b = body()
    if not db.query("SELECT 1 FROM checklists WHERE id = ?", (cid,)):
        return err("That assessment no longer exists.", 404)
    if not b.get("authorized"):
        return err("Confirm that you own this site or are authorized to check it.")
    try:
        res = checklist.web_checks(str(b.get("target", "")), bool(b.get("allow_private")))
    except ValueError as e:
        return err(str(e))
    db.log("Security Checklist", "Automatic checks run")
    return jsonify(res)


@bp.get("/api/checklists/<int:cid>/report")
def checklist_report(cid):
    row = db.query("SELECT name FROM checklists WHERE id = ?", (cid,))
    if not row:
        return err("That assessment no longer exists.", 404)
    model = reportgen.build({"title": f"Security checklist: {row[0]['name']}", "scope": "Self-assessment against the D76 security checklist.",
                             "methodology": "Each item was marked pass, fail or not applicable by the assessor. Items marked by the automatic web checks reflect what the site returned at the time of the check.",
                             "sources": [{"type": "checklist", "id": cid}]})
    return render_download(model, request.args.get("format", "md"), f"checklist-{cid}")


# --------------------------------------------------------------------- Terminal

def terminal_state():
    st = db.get_settings()
    return {"available": os.environ.get("D76_TERMINAL", "1") != "0", "enabled": st.get("terminal_enabled") == "1"}


def get_policy():
    try:
        return terminal.validate_policy(json.loads(db.get_settings().get("terminal_policy", "")))
    except (ValueError, terminal.PolicyError):
        return terminal.validate_policy(terminal.DEFAULT_POLICY)


@bp.get("/api/terminal/status")
def terminal_status():
    local_only()
    return jsonify(**terminal_state(), cwd=session.get("term_cwd") or os.path.expanduser("~"), platform=platform.system(), policy=get_policy(), builtins=terminal.BUILTINS)


@bp.post("/api/terminal/enable")
def terminal_enable():
    local_only()
    if not terminal_state()["available"]:
        return err("The terminal has been disabled by the server's D76_TERMINAL=0 setting.", 403)
    on = bool(body().get("enabled"))
    db.set_settings({"terminal_enabled": "1" if on else "0"})
    db.log("Terminal", "Enabled" if on else "Disabled")
    return jsonify(enabled=on)


@bp.route("/api/terminal/policy", methods=["PUT"])
def terminal_policy():
    local_only()
    try:
        policy = terminal.validate_policy(body())
    except terminal.PolicyError as e:
        return err(str(e))
    db.set_settings({"terminal_policy": json.dumps(policy)})
    db.log("Terminal", "Policy updated")
    return jsonify(policy=policy)


@bp.post("/api/terminal/policy/reset")
def terminal_policy_reset():
    local_only()
    db.set_settings({"terminal_policy": json.dumps(terminal.validate_policy(terminal.DEFAULT_POLICY))})
    db.log("Terminal", "Policy reset")
    return jsonify(policy=get_policy())


def ndjson(events):
    for e in events:
        yield json.dumps(e) + "\n"


@bp.post("/api/terminal/run")
def terminal_run():
    local_only()
    state = terminal_state()
    if not state["available"] or not state["enabled"]:
        return err("The terminal is switched off. Turn it on from the Terminal page first.", 403)
    command = str(body().get("command", ""))
    policy = get_policy()
    cwd = session.get("term_cwd") or os.path.expanduser("~")
    if not os.path.isdir(cwd):
        cwd = os.path.expanduser("~")
    try:
        kind, argv = terminal.parse(command, policy)
    except terminal.PolicyError as e:
        return Response(ndjson([{"t": "err", "d": str(e) + "\n"}, {"t": "exit", "code": 126, "ms": 0, "timeout": False, "truncated": False, "denied": True}]), mimetype="application/x-ndjson")
    if kind == "builtin":
        name, args = argv[0], argv[1:]
        events = []
        try:
            if name == "cd":
                cwd = terminal.change_dir(cwd, args[0] if args else "~")
                session["term_cwd"] = cwd
                events.append({"t": "cwd", "cwd": cwd})
            elif name == "pwd":
                events.append({"t": "out", "d": cwd + "\n"})
            elif name == "help":
                events.append({"t": "out", "d": "Built-in: cd, pwd, help, clear. Pipes (|) join allowed commands. Redirects, ;, && and background jobs are not supported.\nAllowed commands:\n  " + "  ".join(sorted(policy["commands"])) + "\n"})
            events.append({"t": "exit", "code": 0, "ms": 0, "timeout": False, "truncated": False})
        except terminal.PolicyError as e:
            events = [{"t": "err", "d": str(e) + "\n"}, {"t": "exit", "code": 1, "ms": 0, "timeout": False, "truncated": False}]
        return Response(ndjson(events), mimetype="application/x-ndjson")
    db.log("Terminal", "Command run")
    gen = terminal.run(argv, cwd, policy["timeout"])
    return Response(stream_with_context(ndjson(gen)), mimetype="application/x-ndjson", headers={"X-Accel-Buffering": "no", "Cache-Control": "no-store"})


# ------------------------------------------------------------------ BackupGuard

def backup_call(fn, *args):
    local_only()
    try:
        return jsonify(fn(*args))
    except backup.BackupError as e:
        return err(str(e))
    except PermissionError as e:
        return err(f"Permission denied: {e.filename or ''}".strip())
    except OSError as e:
        return err(f"File system error: {e.strerror or e}")


def excludes_of(b):
    return [x.strip() for x in str(b.get("excludes", "")).splitlines() if x.strip()][:50]


@bp.get("/api/backup/browse")
def backup_browse():
    return backup_call(backup.browse, request.args.get("path", ""))


@bp.post("/api/backup/preview")
def backup_preview():
    b = body()
    return backup_call(backup.preview, b.get("source", ""), b.get("dest", ""), b.get("name", ""), excludes_of(b))


@bp.post("/api/backup/run")
def backup_run():
    local_only()
    b = body()
    try:
        res = backup.run_backup(b.get("source", ""), b.get("dest", ""), b.get("name", ""), excludes_of(b))
        if res["created"]:
            db.run("INSERT INTO backups (name, source, dest, snapshot, created, files, bytes, changed) VALUES (?,?,?,?,?,?,?,?)",
                   (backup.safe_name(b["name"]), backup.real(b["source"]), backup.real(b["dest"], False), res["snapshot"], db.now(), res["files"], res["bytes"], res["counts"]["new"] + res["counts"]["changed"]))
            db.log("BackupGuard", "Backup completed")
        return jsonify(res)
    except backup.BackupError as e:
        return err(str(e))
    except OSError as e:
        return err(f"File system error: {e.strerror or e}")


@bp.get("/api/backups")
def backups_list():
    rows = db.query("SELECT * FROM backups ORDER BY id DESC LIMIT 300")
    for r in rows:
        r["present"] = os.path.isdir(os.path.join(backup.set_dir(r["dest"], r["name"]), r["snapshot"]))
        r["removable"] = r["present"] and backup.removable(backup.set_dir(r["dest"], r["name"]), r["snapshot"])
    return jsonify(items=rows)


def backup_row(bid):
    rows = db.query("SELECT * FROM backups WHERE id = ?", (bid,))
    if not rows:
        abort(404)
    return rows[0], backup.set_dir(rows[0]["dest"], rows[0]["name"])


@bp.post("/api/backups/<int:bid>/verify")
def backup_verify(bid):
    local_only()
    row, sdir = backup_row(bid)
    try:
        res = backup.verify(sdir, row["snapshot"])
    except backup.BackupError as e:
        return err(str(e))
    db.run("UPDATE backups SET verified_at = ?, verify_result = ? WHERE id = ?", (db.now(), "ok" if res["ok"] else f"{len(res['missing'])} missing, {len(res['corrupted'])} corrupted", bid))
    db.log("BackupGuard", "Backup verified")
    return jsonify(res)


@bp.post("/api/backups/<int:bid>/restore")
def backup_restore(bid):
    local_only()
    b = body()
    row, sdir = backup_row(bid)
    if b.get("overwrite") and b.get("confirm") != "OVERWRITE":
        return err("To overwrite existing files, type OVERWRITE to confirm.")
    try:
        res = backup.restore(sdir, row["snapshot"], b.get("target", ""), bool(b.get("overwrite")))
    except backup.BackupError as e:
        return err(str(e))
    except OSError as e:
        return err(f"File system error: {e.strerror or e}")
    db.log("BackupGuard", "Backup restored")
    return jsonify(res)


@bp.post("/api/backups/<int:bid>/delete")
def backup_delete(bid):
    local_only()
    if body().get("confirm") != "DELETE":
        return err("Type DELETE to confirm. This removes the backup copy; your original files are not touched.")
    row, sdir = backup_row(bid)
    try:
        if os.path.isdir(os.path.join(sdir, row["snapshot"])):
            backup.delete_snapshot(sdir, row["snapshot"])
    except backup.BackupError as e:
        return err(str(e))
    db.run("DELETE FROM backups WHERE id = ?", (bid,))
    db.log("BackupGuard", "Backup deleted")
    return jsonify(ok=True)


# ---------------------------------------------------------------------- NetWatch

def target_fields(b, partial=False):
    base = netwatch.validate_target(b) if not partial else {}
    name = str(b.get("name", "")).strip()
    if not name or len(name) > 100:
        raise ValueError("Give the target a name (up to 100 characters).")
    def num(key, lo, hi, default):
        try:
            return max(lo, min(hi, int(b.get(key, default))))
        except (TypeError, ValueError):
            raise ValueError(f"{key.replace('_', ' ').capitalize()} must be a number.") from None
    return {**base, "name": name, "path": str(b.get("path", "/"))[:200] or "/", "interval_sec": num("interval_sec", 10, 86400, 60), "timeout_sec": num("timeout_sec", 1, 30, 5),
            "enabled": 1 if b.get("enabled", True) else 0, "allow_private": 1 if b.get("allow_private") else 0, "alert_latency_ms": num("alert_latency_ms", 0, 60000, 0), "alert_failures": num("alert_failures", 1, 20, 3)}


@bp.get("/api/watch/overview")
def watch_overview():
    targets = db.query("SELECT * FROM watch_targets ORDER BY name COLLATE NOCASE")
    for t in targets:
        t["stats"] = netwatch.stats(t["id"], 24)
    return jsonify(targets=targets, active=netwatch.monitor.active(), open_alerts=db.query("SELECT COUNT(*) n FROM watch_alerts WHERE acknowledged = 0")[0]["n"])


@bp.post("/api/watch/targets")
def watch_create():
    try:
        f = target_fields(body())
    except ValueError as e:
        return err(str(e))
    now = db.now()
    tid = db.run("INSERT INTO watch_targets (name, kind, host, port, path, interval_sec, timeout_sec, enabled, allow_private, alert_latency_ms, alert_failures, created, updated) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                 (f["name"], f["kind"], f["host"], f["port"], f["path"], f["interval_sec"], f["timeout_sec"], f["enabled"], f["allow_private"], f["alert_latency_ms"], f["alert_failures"], now, now))
    db.log("NetWatch", "Target added")
    return jsonify(id=tid), 201


@bp.put("/api/watch/targets/<int:tid>")
def watch_update(tid):
    if not db.query("SELECT 1 FROM watch_targets WHERE id = ?", (tid,)):
        return err("That target no longer exists.", 404)
    try:
        f = target_fields(body())
    except ValueError as e:
        return err(str(e))
    db.run("UPDATE watch_targets SET name=?, kind=?, host=?, port=?, path=?, interval_sec=?, timeout_sec=?, enabled=?, allow_private=?, alert_latency_ms=?, alert_failures=?, updated=? WHERE id=?",
           (f["name"], f["kind"], f["host"], f["port"], f["path"], f["interval_sec"], f["timeout_sec"], f["enabled"], f["allow_private"], f["alert_latency_ms"], f["alert_failures"], db.now(), tid))
    return jsonify(ok=True)


@bp.delete("/api/watch/targets/<int:tid>")
def watch_delete(tid):
    db.run("DELETE FROM watch_targets WHERE id = ?", (tid,))
    db.log("NetWatch", "Target removed")
    return jsonify(ok=True)


@bp.post("/api/watch/targets/<int:tid>/check")
def watch_check(tid):
    try:
        res = netwatch.check_now(tid)
    except ValueError as e:
        return err(str(e), 404)
    return jsonify(res)


@bp.get("/api/watch/targets/<int:tid>/history")
def watch_history(tid):
    try:
        hours = max(1, min(336, int(request.args.get("hours", 24))))
    except ValueError:
        hours = 24
    return jsonify(netwatch.stats(tid, hours))


@bp.post("/api/watch/monitor")
def watch_monitor():
    on = bool(body().get("active"))
    db.set_settings({"watch_active": "1" if on else "0"})
    netwatch.monitor.start() if on else netwatch.monitor.stop()
    db.log("NetWatch", "Monitoring started" if on else "Monitoring stopped")
    return jsonify(active=on)


@bp.get("/api/watch/local")
def watch_local():
    return jsonify(netwatch.local_snapshot())


# --------------------------------------------------------------------- Nova CLI

def nova_stored():
    try:
        return json.loads(db.get_settings().get("nova_config", "{}"))
    except ValueError:
        return {}


@bp.get("/api/nova/status")
def nova_status():
    return jsonify({**nova.status(nova_stored()), "stored": nova_stored(), "tasks": {k: v[0] for k, v in nova.TASKS.items()}})


@bp.put("/api/nova/config")
def nova_config():
    b = body()
    cfg = {"provider": b.get("provider", ""), "model": str(b.get("model", "")).strip()[:100], "base_url": str(b.get("base_url", "")).strip()[:300], "max_tokens": b.get("max_tokens") or 1500}
    if cfg["provider"] not in ("anthropic", "openai"):
        return err("Choose a provider.")
    try:
        nova.get_config(cfg)
    except nova.NovaError as e:
        return err(str(e))
    db.set_settings({"nova_config": json.dumps(cfg)})
    db.log("Nova CLI", "Settings saved")
    return jsonify(status=nova.status(cfg), stored=cfg)


@bp.post("/api/nova/run")
def nova_run():
    b = body()
    try:
        res = nova.run_task(str(b.get("task", "")), str(b.get("text", "")), nova_stored(), b.get("mask", True) is not False, str(b.get("language", ""))[:30])
    except nova.NovaError as e:
        return err(str(e))
    db.log("Nova CLI", "Task run")
    return jsonify(res)


@bp.post("/api/nova/scaffold")
def nova_scaffold():
    try:
        files = nova.scaffold(str(body().get("description", "")), nova_stored())
    except nova.NovaError as e:
        return err(str(e))
    db.log("Nova CLI", "Scaffold generated")
    return jsonify(files=[{"path": p, "content": c} for p, c in files])


# --------------------------------------------------------------------- ReportGen

@bp.get("/api/reports/sources")
def report_sources():
    return jsonify(cases=db.query("SELECT id, title, kind, status FROM cases ORDER BY updated DESC LIMIT 200"),
                   checklists=db.query("SELECT id, name, target FROM checklists ORDER BY updated DESC LIMIT 100"),
                   saved=db.query("SELECT id, kind, title, created FROM saved_results ORDER BY id DESC LIMIT 200"),
                   netwatch=db.query("SELECT COUNT(*) n FROM watch_targets")[0]["n"])


def render_download(model, fmt, base):
    fmt = (fmt or "md").lower()
    if fmt == "json":
        return Response(json.dumps(model, indent=2), mimetype="application/json", headers={"Content-Disposition": f'attachment; filename="{base}.json"'})
    if fmt == "md":
        return Response(reportgen.to_markdown(model), mimetype="text/markdown", headers={"Content-Disposition": f'attachment; filename="{base}.md"'})
    if fmt == "pdf":
        return Response(reportgen.to_pdf(model), mimetype="application/pdf", headers={"Content-Disposition": f'attachment; filename="{base}.pdf"'})
    if fmt in ("html", "view"):
        from flask import render_template
        html = render_template("report.html", m=model, walk=reportgen.walk, logo=reportgen.LOGO)
        headers = {"Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'; img-src https://files.catbox.moe; base-uri 'none'; form-action 'none'"}
        if fmt == "html":
            headers["Content-Disposition"] = f'attachment; filename="{base}.html"'
        return Response(html, mimetype="text/html", headers=headers)
    return err("Unknown format.")


@bp.post("/api/reports")
def report_create():
    try:
        model = reportgen.build(body())
    except ValueError as e:
        return err(str(e))
    rid = db.run("INSERT INTO reports (title, kind, path, created) VALUES (?,?,?,?)", (model["title"], "report", "", db.now()))
    path = reportgen.reports_dir() / f"{rid}.json"
    path.write_text(json.dumps(model))
    db.run("UPDATE reports SET path = ? WHERE id = ?", (str(path), rid))
    db.log("ReportGen", "Report generated")
    return jsonify(id=rid), 201


def report_model(rid):
    rows = db.query("SELECT * FROM reports WHERE id = ?", (rid,))
    if not rows:
        abort(404)
    try:
        with open(reportgen.reports_dir() / f"{rid}.json") as fh:
            return rows[0], json.load(fh)
    except (OSError, ValueError):
        abort(404, "The saved report file is missing.")


@bp.get("/api/reports/list")
def report_list():
    return jsonify(items=db.query("SELECT id, title, created FROM reports WHERE kind = 'report' ORDER BY id DESC LIMIT 200"))


@bp.get("/api/reports/<int:rid>/download")
def report_download(rid):
    row, model = report_model(rid)
    return render_download(model, request.args.get("format", "pdf"), re.sub(r"[^A-Za-z0-9_-]+", "-", row["title"]).strip("-")[:50] or f"report-{rid}")


@bp.post("/api/reports/<int:rid>/delete")
def report_delete(rid):
    rows = db.query("SELECT id FROM reports WHERE id = ?", (rid,))
    if not rows:
        return err("That report no longer exists.", 404)
    try:
        os.remove(reportgen.reports_dir() / f"{rid}.json")
    except OSError:
        pass
    db.run("DELETE FROM reports WHERE id = ?", (rid,))
    db.log("ReportGen", "Report deleted")
    return jsonify(ok=True)


@bp.get("/api/saved")
def saved_list():
    kind = request.args.get("kind")
    sql, args = "SELECT id, kind, title, created FROM saved_results", ()
    if kind:
        sql, args = sql + " WHERE kind = ?", (kind,)
    return jsonify(items=db.query(sql + " ORDER BY id DESC LIMIT 200", args))
