"""NetWatch: checks against endpoints you configure, local network counters, history and alerts."""
import ipaddress
import os
import re
import shutil
import socket
import subprocess
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone

import db
import dnsclient
import inspector
import netutil

KINDS = ("tcp", "http", "https", "dns", "icmp")
KEEP_PER_TARGET = 2000
RETENTION_DAYS = 14
STATES = {"01": "ESTABLISHED", "02": "SYN_SENT", "03": "SYN_RECV", "04": "FIN_WAIT1", "05": "FIN_WAIT2", "06": "TIME_WAIT", "07": "CLOSE", "08": "CLOSE_WAIT", "09": "LAST_ACK", "0A": "LISTEN", "0B": "CLOSING"}


def resolve_ip(host, allow_private):
    return netutil.resolve(host, 0, allow_private)


def check_tcp(t):
    ip = resolve_ip(t["host"], t["allow_private"])
    t0 = time.perf_counter()
    with socket.create_connection((ip, t["port"]), t["timeout_sec"]):
        pass
    return {"ok": True, "latency_ms": round((time.perf_counter() - t0) * 1000, 1), "detail": f"Connected to {ip}:{t['port']}"}


def check_http(t):
    scheme = "https" if t["kind"] == "https" else "http"
    port = t["port"] or (443 if scheme == "https" else 80)
    path = t["path"] if str(t["path"]).startswith("/") else "/" + str(t["path"] or "")
    t0 = time.perf_counter()
    r = netutil.request(f"{scheme}://{t['host']}:{port}{path}", "GET", None, None, bool(t["allow_private"]), t["timeout_sec"], True)
    ms = round((time.perf_counter() - t0) * 1000, 1)
    ok = r["status"] < 400
    return {"ok": ok, "latency_ms": ms, "detail": f"HTTP {r['status']} {r['reason']}" + ("" if ok else " (an error status)")}


def check_dns(t):
    servers = dnsclient.system_resolvers()
    t0 = time.perf_counter()
    res = dnsclient.query(t["host"], "A", servers, t["timeout_sec"])
    ms = round((time.perf_counter() - t0) * 1000, 1)
    n = len([a for a in res["answers"] if a["type"] == "A"])
    return {"ok": res["rcode"] == 0 and n > 0, "latency_ms": ms, "detail": f"{n} address(es) from {res['resolver']}" if n else f"No answer (rcode {res['rcode']}) from {res['resolver']}"}


def parse_ping(out):
    loss = re.search(r"(\d+(?:\.\d+)?)%\s*(?:packet\s+)?loss", out, re.I)
    avg = re.search(r"=\s*[\d.]+/([\d.]+)/[\d.]+", out) or re.search(r"Average\s*=\s*(\d+)\s*ms", out, re.I)
    return (float(loss.group(1)) if loss else None), (float(avg.group(1)) if avg else None)


def check_icmp(t):
    exe = shutil.which("ping")
    if not exe:
        raise ValueError("The ping program is not available on this system. Use a TCP check instead.")
    resolve_ip(t["host"], t["allow_private"])
    count, tmo = 4, max(1, int(t["timeout_sec"]))
    argv = [exe, "-n", str(count), "-w", str(tmo * 1000), t["host"]] if os.name == "nt" else [exe, "-c", str(count), "-W", str(tmo), t["host"]]
    try:
        p = subprocess.run(argv, capture_output=True, text=True, timeout=count * (tmo + 1) + 5, stdin=subprocess.DEVNULL)
    except subprocess.TimeoutExpired:
        return {"ok": False, "latency_ms": None, "loss_pct": 100.0, "detail": "ping did not finish in time"}
    loss, avg = parse_ping(p.stdout + p.stderr)
    if loss is None:
        raise ValueError("ping ran but its output could not be read: " + (p.stderr or p.stdout).strip()[:120])
    return {"ok": loss < 100, "latency_ms": avg, "loss_pct": loss, "detail": f"{loss:g}% packet loss" + (f", average {avg:g} ms" if avg is not None else "")}


def run_check(t):
    try:
        res = {"tcp": check_tcp, "http": check_http, "https": check_http, "dns": check_dns, "icmp": check_icmp}[t["kind"]](t)
    except socket.timeout:
        res = {"ok": False, "latency_ms": None, "detail": f"Timed out after {t['timeout_sec']} s"}
    except ConnectionRefusedError:
        res = {"ok": False, "latency_ms": None, "detail": "Connection refused"}
    except (netutil.NetError, dnsclient.DnsError, ValueError) as e:
        res = {"ok": False, "latency_ms": None, "detail": str(e)[:200]}
    except OSError as e:
        res = {"ok": False, "latency_ms": None, "detail": f"{e.strerror or e}"[:200]}
    res.setdefault("loss_pct", None if t["kind"] != "tcp" else (0.0 if res["ok"] else 100.0))
    return res


def record(t, res):
    now = db.now()
    db.run("INSERT INTO watch_results (target_id, ts, ok, latency_ms, loss_pct, detail) VALUES (?,?,?,?,?,?)", (t["id"], now, int(res["ok"]), res["latency_ms"], res["loss_pct"], res["detail"]))
    evaluate(t, res)
    db.run("DELETE FROM watch_results WHERE target_id = ? AND (ts < ? OR id NOT IN (SELECT id FROM watch_results WHERE target_id = ? ORDER BY id DESC LIMIT ?))",
           (t["id"], (datetime.now(timezone.utc) - timedelta(days=RETENTION_DAYS)).isoformat(timespec="seconds"), t["id"], KEEP_PER_TARGET))


def alert(t, kind, message):
    db.run("INSERT INTO watch_alerts (target_id, ts, kind, message) VALUES (?,?,?,?)", (t["id"], db.now(), kind, message))
    db.log("NetWatch", "Alert raised")


def evaluate(t, res):
    need = max(1, int(t["alert_failures"] or 3))
    recent = db.query("SELECT ok FROM watch_results WHERE target_id = ? ORDER BY id DESC LIMIT ?", (t["id"], need + 1))
    open_down = db.query("SELECT 1 FROM watch_alerts WHERE target_id = ? AND kind = 'down' AND acknowledged = 0", (t["id"],))
    if not res["ok"] and len(recent) >= need and all(not r["ok"] for r in recent[:need]) and not open_down:
        alert(t, "down", f"{t['name']} failed {need} checks in a row. Last result: {res['detail']}")
    elif res["ok"] and len(recent) > need and all(not r["ok"] for r in recent[1:need + 1]) is False and open_down and recent[0]["ok"]:
        pass
    if res["ok"] and open_down and len(recent) >= 2 and not recent[1]["ok"]:
        alert(t, "recovered", f"{t['name']} is answering again.")
        db.run("UPDATE watch_alerts SET acknowledged = 1 WHERE target_id = ? AND kind = 'down' AND acknowledged = 0", (t["id"],))
    limit = int(t["alert_latency_ms"] or 0)
    if limit and res["ok"] and res["latency_ms"] and res["latency_ms"] > limit:
        cutoff = (datetime.now(timezone.utc) - timedelta(minutes=10)).isoformat(timespec="seconds")
        if not db.query("SELECT 1 FROM watch_alerts WHERE target_id = ? AND kind = 'slow' AND acknowledged = 0 AND ts > ?", (t["id"], cutoff)):
            alert(t, "slow", f"{t['name']} took {res['latency_ms']:g} ms, above your limit of {limit} ms.")


def check_now(target_id):
    rows = db.query("SELECT * FROM watch_targets WHERE id = ?", (target_id,))
    if not rows:
        raise ValueError("That target no longer exists.")
    res = run_check(rows[0])
    record(rows[0], res)
    return res


def stats(target_id, hours=24):
    since = (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat(timespec="seconds")
    rows = db.query("SELECT ts, ok, latency_ms, loss_pct, detail FROM watch_results WHERE target_id = ? AND ts >= ? ORDER BY id", (target_id, since))
    lat = [r["latency_ms"] for r in rows if r["ok"] and r["latency_ms"] is not None]
    last = rows[-1] if rows else None
    return {"checks": len(rows), "up_pct": round(100 * sum(r["ok"] for r in rows) / len(rows), 1) if rows else None,
            "avg_ms": round(sum(lat) / len(lat), 1) if lat else None, "min_ms": min(lat) if lat else None, "max_ms": max(lat) if lat else None,
            "last": last, "history": [{"ts": r["ts"], "ok": r["ok"], "ms": r["latency_ms"]} for r in rows[-60:]]}


# ------------------------------------------------------------------ background monitor

class Monitor:
    def __init__(self):
        self.thread, self.stop_event, self.running = None, threading.Event(), set()
        self.lock = threading.Lock()

    def active(self):
        return self.thread is not None and self.thread.is_alive()

    def start(self):
        if self.active():
            return
        self.stop_event.clear()
        self.thread = threading.Thread(target=self.loop, daemon=True, name="d76-netwatch")
        self.thread.start()

    def stop(self):
        self.stop_event.set()

    def due(self, t):
        last = db.query("SELECT ts FROM watch_results WHERE target_id = ? ORDER BY id DESC LIMIT 1", (t["id"],))
        if not last:
            return True
        age = datetime.now(timezone.utc) - datetime.fromisoformat(last[0]["ts"])
        return age.total_seconds() >= max(10, int(t["interval_sec"] or 60))

    def one(self, t):
        try:
            record(t, run_check(t))
        finally:
            with self.lock:
                self.running.discard(t["id"])

    def loop(self):
        with ThreadPoolExecutor(max_workers=4) as pool:
            while not self.stop_event.wait(3):
                try:
                    for t in db.query("SELECT * FROM watch_targets WHERE enabled = 1"):
                        with self.lock:
                            if t["id"] in self.running or not self.due(t):
                                continue
                            self.running.add(t["id"])
                        pool.submit(self.one, t)
                except Exception:  # keep monitoring alive whatever a single pass hits
                    pass


monitor = Monitor()


# -------------------------------------------------------------------- local network

def read(path):
    try:
        with open(path) as fh:
            return fh.read()
    except OSError:
        return None


def parse_net_dev(text):
    out = []
    for line in (text or "").splitlines()[2:]:
        if ":" not in line:
            continue
        name, data = line.split(":", 1)
        f = data.split()
        if len(f) >= 16:
            out.append({"name": name.strip(), "rx_bytes": int(f[0]), "rx_packets": int(f[1]), "rx_errors": int(f[2]), "rx_drops": int(f[3]),
                        "tx_bytes": int(f[8]), "tx_packets": int(f[9]), "tx_errors": int(f[10]), "tx_drops": int(f[11])})
    return out


def parse_route(text):
    for line in (text or "").splitlines()[1:]:
        f = line.split()
        if len(f) >= 3 and f[1] == "00000000":
            return {"interface": f[0], "gateway": str(ipaddress.IPv4Address(bytes.fromhex(f[2])[::-1]))}
    return None


def tcp_states():
    counts = {}
    for path in ("/proc/net/tcp", "/proc/net/tcp6"):
        text = read(path)
        for line in (text or "").splitlines()[1:]:
            f = line.split()
            if len(f) > 3:
                counts[STATES.get(f[3], f[3])] = counts.get(STATES.get(f[3], f[3]), 0) + 1
    return counts if read("/proc/net/tcp") is not None else None


def addresses():
    exe = shutil.which("ip")
    if not exe:
        return None
    try:
        import json
        p = subprocess.run([exe, "-j", "addr"], capture_output=True, text=True, timeout=4, stdin=subprocess.DEVNULL)
        data = json.loads(p.stdout)
    except (subprocess.SubprocessError, ValueError, OSError):
        return None
    return {i["ifname"]: {"state": i.get("operstate"), "mac": i.get("address"), "addrs": [f"{a['local']}/{a['prefixlen']}" for a in i.get("addr_info", [])]} for i in data}


def local_snapshot():
    dev = parse_net_dev(read("/proc/net/dev"))
    addr = addresses() or {}
    for d in dev:
        d.update(addr.get(d["name"], {"state": None, "mac": None, "addrs": []}))
    return {"ts": time.time(), "interfaces": dev or None, "gateway": parse_route(read("/proc/net/route")), "tcp_states": tcp_states(),
            "resolvers": dnsclient.system_resolvers(), "hostname": socket.gethostname()}


def validate_target(data):
    """Returns cleaned fields for a watch target, or raises ValueError."""
    kind = data.get("kind")
    if kind not in KINDS:
        raise ValueError("Choose a check type.")
    host, is_ip, port_in = inspector.clean_target(str(data.get("host", "")))
    port = data.get("port")
    port = int(port) if str(port or "").strip().isdigit() else port_in
    if kind == "tcp" and not port:
        raise ValueError("A TCP check needs a port.")
    if port is not None and not 1 <= int(port) <= 65535:
        raise ValueError("The port must be between 1 and 65535.")
    return {"kind": kind, "host": host, "port": port}
